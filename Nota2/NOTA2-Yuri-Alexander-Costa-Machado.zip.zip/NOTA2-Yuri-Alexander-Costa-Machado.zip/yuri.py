# Construir uma interface pro usuário inserrir um problema ede programacao linear (pl) e resolver usando a funcao simplex.
# retornar o rsultado tambem em uma interface usuárioUI nao pode ser linha de comando
# html e css

import numpy as np
from fpdf import FPDF

def carregar_problema(caminho_arquivo):
    try:
        with open(caminho_arquivo, 'r') as f:
            linhas = f.readlines()
            
        c = np.array([float(x) for x in linhas[0].strip().split()])
        
        A = []
        b = []
        for linha in linhas[1:]:
            if linha.strip():
                valores = [float(x) for x in linha.strip().split()]
                A.append(valores[:-1])
                b.append(valores[-1])
                
        return c, np.array(A), np.array(b)
    except Exception as e:
        print(f"Erro ao ler o arquivo: {e}")
        return None, None, None

def simplex(c, A, b):
    num_restricoes, num_variaveis = A.shape
    tableau = np.zeros((num_restricoes + 1, num_variaveis + num_restricoes + 1))
    
    tableau[:num_restricoes, :num_variaveis] = A
    tableau[:num_restricoes, -1] = b
    tableau[:num_restricoes, num_variaveis:num_variaveis + num_restricoes] = np.eye(num_restricoes)
    tableau[-1, :num_variaveis] = -c
    
    iteracao = 1
    while True:
        if np.all(np.round(tableau[-1, :-1], 10) >= 0):
            break
            
        coluna_pivo = np.argmin(tableau[-1, :-1])
        
        razoes = []
        for i in range(num_restricoes):
            if tableau[i, coluna_pivo] > 0:
                razao = tableau[i, -1] / tableau[i, coluna_pivo]
                razoes.append(razao)
            else:
                razoes.append(np.inf)
                
        linha_pivo = np.argmin(razoes)
        
        if razoes[linha_pivo] == np.inf:
            raise ValueError("O problema tem solucao ilimitada (regiao viavel nao e limitada).")
            
        elemento_pivo = tableau[linha_pivo, coluna_pivo]
        tableau[linha_pivo, :] /= elemento_pivo
        
        for i in range(num_restricoes + 1):
            if i != linha_pivo:
                fator = tableau[i, coluna_pivo]
                tableau[i, :] -= fator * tableau[linha_pivo, :]
                
        iteracao += 1
        
    solucao = np.zeros(num_variaveis)
    for j in range(num_variaveis):
        coluna = tableau[:-1, j]
        if np.count_nonzero(np.round(coluna, 10) == 1) == 1 and np.count_nonzero(np.round(coluna, 10) == 0) == num_restricoes - 1:
            linha_indice = np.where(np.round(coluna, 10) == 1)[0][0]
            solucao[j] = tableau[linha_indice, -1]
            
    valor_otimo = tableau[-1, -1]
    
    return solucao, valor_otimo, iteracao

def gerar_pdf(c, A, b, solucao, valor_otimo, iteracoes, nome_arquivo):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(200, 10, txt="Relatorio de Programacao Linear - Simplex", ln=True, align='C')
    pdf.ln(10)
    
    pdf.set_font("Arial", 'B', 14)
    pdf.cell(200, 10, txt="1. Problema (Input)", ln=True)
    pdf.set_font("Arial", size=12)
    
    pdf.cell(200, 10, txt="Funcao Objetivo (Maximizar):", ln=True)
    func_obj = "Z = " + " + ".join([f"{coef}*x_{i+1}" for i, coef in enumerate(c)])
    pdf.cell(200, 10, txt=func_obj, ln=True)
    
    pdf.ln(5)
    pdf.cell(200, 10, txt="Restricoes:", ln=True)
    for i in range(len(A)):
        restricao = " + ".join([f"{A[i][j]}*x_{j+1}" for j in range(len(A[i]))])
        restricao += f" <= {b[i]}"
        pdf.cell(200, 10, txt=restricao, ln=True)
        
    pdf.ln(10)
    
    pdf.set_font("Arial", 'B', 14)
    pdf.cell(200, 10, txt="2. Resultado da Execucao", ln=True)
    pdf.set_font("Arial", size=12)
    
    pdf.cell(200, 10, txt=f"Iteracoes realizadas: {iteracoes - 1}", ln=True)
    pdf.cell(200, 10, txt=f"Valor otimo (Z): {valor_otimo:.4f}", ln=True)
    pdf.ln(5)
    pdf.cell(200, 10, txt="Valores das variaveis de decisao:", ln=True)
    for i, val in enumerate(solucao):
        pdf.cell(200, 10, txt=f"x_{i+1} = {val:.4f}", ln=True)
        
    pdf.output(nome_arquivo)
    print(f"\nPDF '{nome_arquivo}' gerado com sucesso!")

if __name__ == "__main__":
    arquivo_txt = 'problema.txt'
    nome_aluno = "Yuri-Alexander-Costa-Machado"
    arquivo_pdf = f'simplex-primeiro-{nome_aluno}.PDF'
    
    print(f"Lendo dados de '{arquivo_txt}'...\n")
    c, A, b = carregar_problema(arquivo_txt)
    
    if c is not None:
        try:
            solucao, valor_otimo, iteracoes = simplex(c, A, b)
            
            print("=== SOLUCAO OBTIDA ===")
            print(f"Iteracoes realizadas: {iteracoes - 1}")
            print(f"Valor otimo (Z): {valor_otimo:.4f}")
            for i, val in enumerate(solucao):
                print(f"  x_{i+1} = {val:.4f}")
                
            gerar_pdf(c, A, b, solucao, valor_otimo, iteracoes, arquivo_pdf)
                
        except ValueError as erro:
            print(f"Erro na resolucao: {erro}")