from flask import Flask, render_template, request, jsonify
import numpy as np

app = Flask(__name__)

def simplex(c, A, b, tipo="max"):
    """Executa o algoritmo Simplex para maximização ou minimização na forma canônica."""
    num_restricoes, num_variaveis = A.shape
    passos = []

    if tipo == "min":
        c = -c

    tableau = np.zeros((num_restricoes + 1, num_variaveis + num_restricoes + 1))
    tableau[:num_restricoes, :num_variaveis] = A
    tableau[:num_restricoes, -1] = b
    tableau[:num_restricoes, num_variaveis:num_variaveis + num_restricoes] = np.eye(num_restricoes)
    tableau[-1, :num_variaveis] = -c

    variaveis_base = list(range(num_variaveis, num_variaveis + num_restricoes))
    nomes_var = [f"x{i+1}" for i in range(num_variaveis)] + [f"s{i+1}" for i in range(num_restricoes)]

    passos.append({
        "titulo": "Tableau Inicial",
        "tableau": tableau.tolist(),
        "variaveis_base": [nomes_var[v] for v in variaveis_base],
        "nomes_col": nomes_var + ["b"],
        "descricao": "Tableau inicial com variáveis de folga adicionadas."
    })

    iteracao = 0
    while True:
        if np.all(np.round(tableau[-1, :-1], 10) >= 0):
            break

        coluna_pivo = int(np.argmin(tableau[-1, :-1]))

        razoes = []
        for i in range(num_restricoes):
            if tableau[i, coluna_pivo] > 1e-10:
                razoes.append(tableau[i, -1] / tableau[i, coluna_pivo])
            else:
                razoes.append(np.inf)

        linha_pivo = int(np.argmin(razoes))

        if razoes[linha_pivo] == np.inf:
            raise ValueError("O problema tem solução ilimitada.")

        elemento_pivo = tableau[linha_pivo, coluna_pivo]
        variaveis_base[linha_pivo] = coluna_pivo

        tableau[linha_pivo, :] /= elemento_pivo
        for i in range(num_restricoes + 1):
            if i != linha_pivo:
                fator = tableau[i, coluna_pivo]
                tableau[i, :] -= fator * tableau[linha_pivo, :]

        iteracao += 1
        passos.append({
            "titulo": f"Iteração {iteracao}",
            "tableau": tableau.tolist(),
            "variaveis_base": [nomes_var[v] for v in variaveis_base],
            "nomes_col": nomes_var + ["b"],
            "coluna_pivo": coluna_pivo,
            "linha_pivo": linha_pivo,
            "descricao": f"Variável <b>{nomes_var[coluna_pivo]}</b> entra na base. Elemento pivô: {elemento_pivo:.4f}"
        })

    solucao = np.zeros(num_variaveis)
    for j in range(num_variaveis):
        coluna = tableau[:-1, j]
        if (np.count_nonzero(np.round(coluna, 10) == 1) == 1 and
                np.count_nonzero(np.round(coluna, 10) == 0) == num_restricoes - 1):
            linha_indice = int(np.where(np.round(coluna, 10) == 1)[0][0])
            solucao[j] = tableau[linha_indice, -1]

    valor_otimo = tableau[-1, -1]

    return solucao, valor_otimo, iteracao, passos


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/resolver", methods=["POST"])
def resolver():
    try:
        data = request.get_json()
        tipo = data.get("tipo", "max")
        num_var = int(data["num_variaveis"])
        num_rest = int(data["num_restricoes"])
        c = np.array([float(x) for x in data["c"]])        # <-- corrigido
        A = np.array([[float(v) for v in row] for row in data["A"]])  # <-- corrigido
        b = np.array([float(x) for x in data["b"]])        # <-- corrigido

        if len(c) != num_var:
            raise ValueError("Número de coeficientes da função objetivo não bate.")
        if A.shape != (num_rest, num_var):
            raise ValueError("Dimensões da matriz de restrições incorretas.")
        if len(b) != num_rest:
            raise ValueError("Número de limites incorreto.")
        if np.any(b < 0):
            raise ValueError("Todos os valores de b devem ser não-negativos (forma canônica).")

        solucao, valor_otimo, iteracoes, passos = simplex(c, A, b, tipo)

        return jsonify({
            "sucesso": True,
            "solucao": solucao.tolist(),
            "valor_otimo": float(valor_otimo),
            "iteracoes": iteracoes,
            "passos": passos,
            "tipo": tipo
        })
    except Exception as e:
        return jsonify({"sucesso": False, "erro": str(e)})


if __name__ == "__main__":
    app.run(debug=True)