# Solver Simplex — Interface Gráfica

## Requisitos
- Python 3.9+
- pip

## Instalação e Execução

1. Instale as dependências:
   ```
   pip install -r requirements.txt
   ```

2. Execute a aplicação:
   ```
   python app.py
   ```

3. Abra o navegador em: `http://localhost:5000`

## Exemplo Carregado por Padrão

MAX Z = 5x₁ + 4x₂
s.a.:
  6x₁ + 4x₂ ≤ 24
  x₁ + 2x₂ ≤ 6
  x₁, x₂ ≥ 0

**Solução ótima:** Z = 21, x₁ = 3, x₂ = 1.5
