document.addEventListener('DOMContentLoaded', () => {
    const fileUpload = document.getElementById('file-upload');
    const fileNameDisplay = document.getElementById('file-name');
    const problemInput = document.getElementById('problem-input');
    const solveBtn = document.getElementById('solve-btn');
    const resultSection = document.getElementById('result-section');
    const resultContent = document.getElementById('result-content');

    fileUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            fileNameDisplay.textContent = file.name;
            const reader = new FileReader();
            reader.onload = (event) => {
                problemInput.value = event.target.result;
            };
            reader.readAsText(file);
        } else {
            fileNameDisplay.textContent = 'Nenhum arquivo selecionado';
        }
    });

    solveBtn.addEventListener('click', async () => {
        const texto = problemInput.value.trim();
        
        if (!texto) {
            alert('Por favor, insira os dados do problema ou importe um arquivo .txt');
            return;
        }

        solveBtn.textContent = 'Resolvendo...';
        solveBtn.disabled = true;

        try {
            const response = await fetch('/resolver', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ texto })
            });

            const data = await response.json();
            
            resultSection.classList.remove('hidden');
            resultContent.innerHTML = '';

            if (data.sucesso) {
                let html = `
                    <div class="result-item">
                        <span class="result-label">Status</span>
                        <span class="result-value" style="color: var(--success-color)">Ótimo Encontrado</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Iterações</span>
                        <span class="result-value" style="color: var(--text-main)">${data.iteracoes}</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Valor Ótimo (Z)</span>
                        <span class="result-value" style="font-size: 1.2rem; color: #a78bfa">${data.valor_otimo.toFixed(4)}</span>
                    </div>
                    <h3 style="margin-top: 1.5rem; margin-bottom: 1rem; color: var(--text-muted); font-size: 1rem; font-weight: 500;">Variáveis de Decisão</h3>
                `;

                data.solucao.forEach((val, idx) => {
                    html += `
                        <div class="result-item">
                            <span class="result-label">x<sub>${idx + 1}</sub></span>
                            <span class="result-value" style="color: var(--text-main)">${val.toFixed(4)}</span>
                        </div>
                    `;
                });

                resultContent.innerHTML = html;
            } else {
                resultContent.innerHTML = `
                    <div class="error-message">
                        <strong>Erro:</strong> ${data.erro}
                    </div>
                `;
            }
        } catch (error) {
            resultSection.classList.remove('hidden');
            resultContent.innerHTML = `
                <div class="error-message">
                    <strong>Erro de conexão:</strong> Não foi possível comunicar com o servidor.
                </div>
            `;
        } finally {
            solveBtn.textContent = 'Resolver Problema';
            solveBtn.disabled = false;
        }
    });
});
