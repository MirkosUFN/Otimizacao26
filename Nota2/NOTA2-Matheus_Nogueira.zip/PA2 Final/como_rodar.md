# Como rodar o projeto

# Passo 1

> Crie um ambiente virtual e acesse ele com os comandos: python3 -m venv venv || ./venv/Scripts/activate (win) || source ./venv/bin/acivate (linux)

# Passo 2

> Baixe as dependências do requirements.txt com o comando: pip install -r requirements.txt, ou baixe elas manualmente cada uma com o comando: pip install Flask numpy

# Passo 3

> Inicie o projeto com o comando: python3 app.py 

> No terminal, irá aparecer uma url direcionando para o front, aperte CTRL + Click esquerdo do mouse, ou copie o link e cole no navegador para acessar a UI