import numpy as np

def carregar_problema_texto(texto):
    linhas = texto.strip().split('\n')
    c = np.array([float(x) for x in linhas[0].strip().split()])
    A = []
    b = []
    for linha in linhas[1:]:
        if linha.strip():
            valores = [float(x) for x in linha.strip().split()]
            A.append(valores[:-1])
            b.append(valores[-1])
    return c, np.array(A), np.array(b)

def simplex(c, A, b):
    num_restricoes, num_variaveis = A.shape
    tableau = np.zeros((num_restricoes + 1, num_variaveis + num_restricoes + 1))
    
    tableau[:num_restricoes, :num_variaveis] = A
    tableau[:num_restricoes, -1] = b
    tableau[:num_restricoes, num_variaveis:num_variaveis + num_restricoes] = np.eye(num_restricoes)
    tableau[-1, :num_variaveis] = -c
    
    iteracao = 1
    while True:
        if np.all(np.round(tableau[-1, :-1], 10) >= 0):
            break
            
        coluna_pivo = int(np.argmin(tableau[-1, :-1]))
        
        razoes = []
        for i in range(num_restricoes):
            if tableau[i, coluna_pivo] > 0:
                razao = tableau[i, -1] / tableau[i, coluna_pivo]
                razoes.append(razao)
            else:
                razoes.append(np.inf)
                
        linha_pivo = int(np.argmin(razoes))
        
        if razoes[linha_pivo] == np.inf:
            raise ValueError("O problema tem solução ilimitada.")
            
        elemento_pivo = tableau[linha_pivo, coluna_pivo]
        tableau[linha_pivo, :] /= elemento_pivo
        
        for i in range(num_restricoes + 1):
            if i != linha_pivo:
                fator = tableau[i, coluna_pivo]
                tableau[i, :] -= fator * tableau[linha_pivo, :]
                
        iteracao += 1
        
    solucao = np.zeros(num_variaveis)
    for j in range(num_variaveis):
        coluna = tableau[:-1, j]
        if np.count_nonzero(np.round(coluna, 10) == 1) == 1 and np.count_nonzero(np.round(coluna, 10) == 0) == num_restricoes - 1:
            linha_indice = int(np.where(np.round(coluna, 10) == 1)[0][0])
            solucao[j] = tableau[linha_indice, -1]
            
    valor_otimo = tableau[-1, -1]
    
    return solucao.tolist(), float(valor_otimo), iteracao
