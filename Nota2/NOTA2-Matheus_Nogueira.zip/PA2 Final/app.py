from flask import Flask, request, jsonify, render_template
from simplex import simplex, carregar_problema_texto

app = Flask(__name__, template_folder='UI/templates', static_folder='UI/static')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/resolver', methods=['POST'])
def resolver():
    try:
        dados = request.json
        texto = dados.get('texto', '')
        
        c, A, b = carregar_problema_texto(texto)
        solucao, valor_otimo, iteracoes = simplex(c, A, b)
        
        return jsonify({
            'sucesso': True,
            'solucao': solucao,
            'valor_otimo': valor_otimo,
            'iteracoes': iteracoes - 1
        })
    except Exception as e:
        return jsonify({
            'sucesso': False,
            'erro': str(e)
        })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
