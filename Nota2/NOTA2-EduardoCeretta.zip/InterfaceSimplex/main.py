import customtkinter as ctk
import numpy as np
from simplex import resolver_simplex

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

class AppSimplex(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Resolutor Simplex - Programação Linear")
        self.geometry("1000x600")

        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.entradas_restricoes = []

        self.frame_esquerdo = ctk.CTkFrame(self, fg_color="transparent")
        self.frame_esquerdo.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")

        self.label_titulo = ctk.CTkLabel(self.frame_esquerdo, text="Configuração do Modelo", font=ctk.CTkFont(size=22, weight="bold"))
        self.label_titulo.pack(pady=(0, 15), anchor="w")

        self.frame_c = ctk.CTkFrame(self.frame_esquerdo)
        self.frame_c.pack(fill="x", pady=(0, 15))

        self.lbl_c = ctk.CTkLabel(self.frame_c, text="Coeficientes da Função Objetivo (Z):", font=ctk.CTkFont(weight="bold"))
        self.lbl_c.pack(anchor="w", padx=10, pady=(10, 0))
        
        self.entry_c = ctk.CTkEntry(self.frame_c, placeholder_text="Ex: 3 5 (para 3x1 + 5x2)")
        self.entry_c.pack(fill="x", padx=10, pady=10)

        self.label_restr = ctk.CTkLabel(self.frame_esquerdo, text="Restrições (A e b):", font=ctk.CTkFont(weight="bold"))
        self.label_restr.pack(anchor="w")

        self.scroll_frame = ctk.CTkScrollableFrame(self.frame_esquerdo)
        self.scroll_frame.pack(fill="both", expand=True, pady=5)

        self.btn_frame = ctk.CTkFrame(self.frame_esquerdo, fg_color="transparent")
        self.btn_frame.pack(fill="x", pady=5)

        self.btn_add = ctk.CTkButton(self.btn_frame, text="+ Adicionar Restrição", command=self.add_linha_restricao, fg_color="green", hover_color="#006400")
        self.btn_add.pack(side="left", padx=(0, 5), expand=True, fill="x")

        self.btn_rem = ctk.CTkButton(self.btn_frame, text="- Remover Última Restrição", command=self.rem_linha_restricao, fg_color="red", hover_color="#8B0000")
        self.btn_rem.pack(side="left", padx=(5, 0), expand=True, fill="x")

        self.add_linha_restricao()
        self.add_linha_restricao()

        self.btn_resolver = ctk.CTkButton(self.frame_esquerdo, text="CALCULAR SOLUÇÃO ÓTIMA", font=ctk.CTkFont(size=16, weight="bold"), height=45, command=self.executar_calculo)
        self.btn_resolver.pack(fill="x", pady=(15, 0))

        self.frame_direito = ctk.CTkFrame(self)
        self.frame_direito.grid(row=0, column=1, padx=(0, 20), pady=20, sticky="nsew")

        self.label_res_titulo = ctk.CTkLabel(self.frame_direito, text="Painel de Resultados", font=ctk.CTkFont(size=22, weight="bold"))
        self.label_res_titulo.pack(pady=(15, 10), padx=20, anchor="w")

        self.txt_resultado = ctk.CTkTextbox(self.frame_direito, font=ctk.CTkFont(family="Consolas", size=14))
        self.txt_resultado.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        self.txt_resultado.insert("0.0", "Aguardando cálculo...\n\nInsira os dados no painel ao lado e clique em calcular.")
        self.txt_resultado.configure(state="disabled")

    def add_linha_restricao(self):
        row_idx = len(self.entradas_restricoes)
        frame = ctk.CTkFrame(self.scroll_frame)
        frame.pack(fill="x", pady=5)

        lbl = ctk.CTkLabel(frame, text=f"R{row_idx+1}:", width=30)
        lbl.pack(side="left", padx=5)

        entry_a = ctk.CTkEntry(frame, placeholder_text="A (Ex: 1 2)", width=150)
        entry_a.pack(side="left", padx=5, expand=True, fill="x")

        menu_sinal = ctk.CTkOptionMenu(frame, values=["<=", ">="], width=60)
        menu_sinal.pack(side="left", padx=5)

        entry_b = ctk.CTkEntry(frame, placeholder_text="b", width=60)
        entry_b.pack(side="left", padx=5)

        self.entradas_restricoes.append({
            "frame": frame, 
            "A": entry_a, 
            "sinal": menu_sinal, 
            "b": entry_b
        })

    def rem_linha_restricao(self):
        if len(self.entradas_restricoes) > 1:
            item = self.entradas_restricoes.pop()
            item["frame"].destroy()

    def mostrar_log(self, mensagem):
        self.txt_resultado.configure(state="normal")
        self.txt_resultado.delete("1.0", "end")
        self.txt_resultado.insert("0.0", mensagem)
        self.txt_resultado.configure(state="disabled")

    def executar_calculo(self):
        try:
            c_raw = self.entry_c.get().split()
            if not c_raw:
                raise Exception("A função objetivo não pode estar vazia.")
            c = np.array([float(x) for x in c_raw])

            A_list = []
            b_list = []
            for idx, item in enumerate(self.entradas_restricoes):
                a_str = item["A"].get().strip()
                b_str = item["b"].get().strip()
                
                if not a_str or not b_str:
                    raise Exception(f"Por favor, preencha todos os campos da restrição R{idx+1}.")
                
                a_vals = [float(x) for x in a_str.split()]
                b_val = float(b_str)
                sinal = item["sinal"].get()
                
                if len(a_vals) != len(c):
                    raise Exception(f"A restrição R{idx+1} possui {len(a_vals)} variáveis, mas a função objetivo possui {len(c)}.")
                
                if sinal == ">=":
                    a_vals = [-x for x in a_vals]
                    b_val = -b_val

                A_list.append(a_vals)
                b_list.append(b_val)

            A = np.array(A_list)
            b = np.array(b_list)

            solucao, z_otimo, iters = resolver_simplex(c, A, b)

            res_txt = "=== SUCESSO: SOLUÇÃO ENCONTRADA ===\n\n"
            res_txt += f"Iterações realizadas: {iters - 1}\n"
            res_txt += f"Valor ótimo (Z): {z_otimo:.4f}\n\n"
            res_txt += "Valores das variáveis de decisão:\n"
            for i, v in enumerate(solucao):
                res_txt += f"  x_{i+1} = {v:.4f}\n"
            
            self.mostrar_log(res_txt)

        except ValueError:
            self.mostrar_log("ERRO: Verifique se todos os campos contêm apenas números separados por espaço.")
        except Exception as e:
            self.mostrar_log(f"ERRO: {str(e)}")

if __name__ == "__main__":
    app = AppSimplex()
    app.mainloop()