# Resolutor Simplex - Programação Linear

Este projeto é uma Interface Gráfica de Usuário (UI) desenvolvida em Python para resolver problemas de Programação Linear (Maximização) utilizando o algoritmo Simplex.

O projeto foi modularizado separando a interface gráfica (desenvolvida com `customtkinter`) da lógica matemática (implementada com `numpy`).

## Pré-requisitos

Certifique-se de ter o **Python 3.x** instalado em sua máquina.

## Como rodar o projeto

**1. Descompacte os arquivos**
Extraia todos os arquivos do `.zip` para uma pasta de sua preferência.

**2. Instale as dependências**
Abra o terminal (ou prompt de comando) dentro da pasta onde os arquivos foram extraídos e execute o comando abaixo para instalar as bibliotecas necessárias:
`pip install -r requirements.txt`

**3. Execute a aplicação**
Ainda no terminal, inicie a interface gráfica rodando o arquivo principal:
`python main.py`

## Estrutura do Projeto
* `main.py`: Responsável por renderizar a interface gráfica e capturar os dados do usuário.
* `simplex.py`: Contém o motor matemático do algoritmo Simplex.
* `requirements.txt`: Lista de dependências externas (`numpy` e `customtkinter`).