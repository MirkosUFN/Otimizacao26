"""
Implementação do Método Simplex para Programação Linear.

Suporta:
- Maximização e Minimização
- Restrições do tipo ≤, ≥ e =
- Método Big-M para variáveis artificiais
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Tuple
from copy import deepcopy


@dataclass
class IteracaoSimplex:
    """Representa uma iteração do método Simplex."""
    numero: int
    tableau: np.ndarray
    variaveis_base: List[str]
    nomes_colunas: List[str]
    variavel_entrada: Optional[str] = None
    variavel_saida: Optional[str] = None
    pivo: Optional[Tuple[int, int]] = None


@dataclass
class ResultadoSimplex:
    """Resultado completo da resolução pelo Simplex."""
    status: str  # "otimo", "ilimitado", "inviavel", "erro"
    valor_otimo: Optional[float] = None
    solucao: Optional[dict] = None
    iteracoes: List[IteracaoSimplex] = field(default_factory=list)
    mensagem: str = ""


class Simplex:
    """
    Resolve problemas de Programação Linear usando o Método Simplex (Big-M).

    Forma padrão:
        Max/Min  Z = c1*x1 + c2*x2 + ... + cn*xn
        Sujeito a:
            a11*x1 + a12*x2 + ... + a1n*xn  (<=, >=, =)  b1
            a21*x1 + a22*x2 + ... + a2n*xn  (<=, >=, =)  b2
            ...
            xi >= 0 para todo i
    """

    BIG_M = 1e6  # Valor grande para o método Big-M

    def __init__(self, num_variaveis: int, num_restricoes: int):
        self.num_variaveis = num_variaveis
        self.num_restricoes = num_restricoes
        self.c = np.zeros(num_variaveis)
        self.A = np.zeros((num_restricoes, num_variaveis))
        self.b = np.zeros(num_restricoes)
        self.sinais = ['<=' for _ in range(num_restricoes)]
        self.tipo = 'max'

    def definir_objetivo(self, coeficientes: List[float], tipo: str = 'max'):
        """Define a função objetivo."""
        self.c = np.array(coeficientes, dtype=float)
        self.tipo = tipo.lower()

    def definir_restricao(self, indice: int, coeficientes: List[float],
                          sinal: str, rhs: float):
        """Define uma restrição individual."""
        self.A[indice] = np.array(coeficientes, dtype=float)
        self.sinais[indice] = sinal
        self.b[indice] = rhs

    def resolver(self) -> ResultadoSimplex:
        """Resolve o problema de PL pelo método Simplex."""
        try:
            return self._resolver_bigm()
        except Exception as e:
            return ResultadoSimplex(
                status="erro",
                mensagem=f"Erro durante a resolução: {str(e)}"
            )

    def _resolver_bigm(self) -> ResultadoSimplex:
        """Implementação do Simplex com método Big-M."""
        n = self.num_variaveis
        m = self.num_restricoes

        A = self.A.copy()
        b = self.b.copy()
        sinais = list(self.sinais)

        for i in range(m):
            if b[i] < 0:
                A[i] *= -1
                b[i] *= -1
                if sinais[i] == '<=':
                    sinais[i] = '>='
                elif sinais[i] == '>=':
                    sinais[i] = '<='

        num_folga = 0
        num_artificial = 0
        info_restricao = []

        for i in range(m):
            if sinais[i] == '<=':
                info_restricao.append(('folga', num_folga, None))
                num_folga += 1
            elif sinais[i] == '>=':
                info_restricao.append(('excesso_artificial', num_folga, num_artificial))
                num_folga += 1
                num_artificial += 1
            else:
                info_restricao.append(('artificial', None, num_artificial))
                num_artificial += 1

        total_vars = n + num_folga + num_artificial
        tableau = np.zeros((m + 1, total_vars + 1))

        nomes = [f"x{j + 1}" for j in range(n)]
        col_folga_inicio = n
        col_art_inicio = n + num_folga

        for j in range(num_folga):
            nomes.append(f"f{j + 1}")
        for j in range(num_artificial):
            nomes.append(f"a{j + 1}")

        nomes_colunas = nomes + ["RHS"]

        tableau[:m, :n] = A

        idx_f = 0
        idx_a = 0
        variaveis_base = []

        for i in range(m):
            if sinais[i] == '<=':
                col = col_folga_inicio + idx_f
                tableau[i, col] = 1.0
                variaveis_base.append(nomes[col])
                idx_f += 1
            elif sinais[i] == '>=':
                col_exc = col_folga_inicio + idx_f
                tableau[i, col_exc] = -1.0
                idx_f += 1
                col_a = col_art_inicio + idx_a
                tableau[i, col_a] = 1.0
                variaveis_base.append(nomes[col_a])
                idx_a += 1
            else:
                col_a = col_art_inicio + idx_a
                tableau[i, col_a] = 1.0
                variaveis_base.append(nomes[col_a])
                idx_a += 1

        tableau[:m, -1] = b

        c_obj = self.c.copy()
        if self.tipo == 'min':
            c_obj = -c_obj

        tableau[m, :n] = -c_obj

        for j in range(num_artificial):
            col_a = col_art_inicio + j
            tableau[m, col_a] = self.BIG_M

        for i in range(m):
            if variaveis_base[i].startswith('a'):
                tableau[m] -= self.BIG_M * tableau[i]

        iteracoes = []
        max_iter = 100

        for it in range(max_iter):
            iter_info = IteracaoSimplex(
                numero=it,
                tableau=tableau.copy(),
                variaveis_base=list(variaveis_base),
                nomes_colunas=list(nomes_colunas),
            )

            linha_z = tableau[m, :-1]

            if np.all(linha_z >= -1e-10):
                iteracoes.append(iter_info)
                break

            col_entrada = np.argmin(linha_z)
            iter_info.variavel_entrada = nomes[col_entrada]

            razoes = []
            for i in range(m):
                if tableau[i, col_entrada] > 1e-10:
                    razoes.append(tableau[i, -1] / tableau[i, col_entrada])
                else:
                    razoes.append(np.inf)

            if all(r == np.inf for r in razoes):
                iter_info.variavel_saida = "—"
                iteracoes.append(iter_info)
                return ResultadoSimplex(
                    status="ilimitado",
                    iteracoes=iteracoes,
                    mensagem="O problema é ilimitado (sem solução finita)."
                )

            linha_saida = int(np.argmin(razoes))
            iter_info.variavel_saida = variaveis_base[linha_saida]
            iter_info.pivo = (linha_saida, col_entrada)
            iteracoes.append(iter_info)

            pivo = tableau[linha_saida, col_entrada]
            tableau[linha_saida] /= pivo

            for i in range(m + 1):
                if i != linha_saida:
                    fator = tableau[i, col_entrada]
                    tableau[i] -= fator * tableau[linha_saida]

            variaveis_base[linha_saida] = nomes[col_entrada]
        else:
            return ResultadoSimplex(
                status="erro",
                iteracoes=iteracoes,
                mensagem="Número máximo de iterações atingido."
            )

        iter_final = IteracaoSimplex(
            numero=len(iteracoes),
            tableau=tableau.copy(),
            variaveis_base=list(variaveis_base),
            nomes_colunas=list(nomes_colunas),
        )
        iteracoes.append(iter_final)

        for i in range(m):
            if variaveis_base[i].startswith('a') and tableau[i, -1] > 1e-8:
                return ResultadoSimplex(
                    status="inviavel",
                    iteracoes=iteracoes,
                    mensagem="O problema é inviável (sem solução factível)."
                )

        solucao = {}
        for j in range(n):
            nome = f"x{j + 1}"
            if nome in variaveis_base:
                idx_base = variaveis_base.index(nome)
                solucao[nome] = round(tableau[idx_base, -1], 6)
            else:
                solucao[nome] = 0.0

        valor_otimo = round(tableau[m, -1], 6)
        if self.tipo == 'min':
            valor_otimo = -valor_otimo

        return ResultadoSimplex(
            status="otimo",
            valor_otimo=valor_otimo,
            solucao=solucao,
            iteracoes=iteracoes,
            mensagem="Solução ótima encontrada!"
        )
