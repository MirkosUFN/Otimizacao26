# 🔢 Otimizador Linear — Método Simplex

Interface gráfica para resolução de problemas de Programação Linear
utilizando o **Método Simplex** com técnica Big-M.

---

## Funcionalidades

- Maximização e Minimização
- Restrições com sinais ≤, ≥ e =
- Exibição da formulação do problema
- Exibição da solução ótima
- Passo a passo com tableaux de cada iteração
- Detecção de problemas ilimitados e inviáveis
- Problema de demonstração pré-carregado

---

## Como usar

### 1. Instalar dependências

```bash
pip install -r requirements.txt
```

### 2. Executar

```bash
python main.py
```

---

## Estrutura

```
├── main.py             # Ponto de entrada
├── app.py              # Interface gráfica
├── simplex.py          # Algoritmo Simplex
├── requirements.txt    # Dependências
└── README.md           # Documentação
```

---

## Tecnologias

- Python 3.8+
- CustomTkinter
- NumPy
