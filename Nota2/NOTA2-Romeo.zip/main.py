"""
Ponto de entrada principal do Otimizador Linear.
Execute este arquivo para iniciar a interface gráfica.
"""

from app import main

if __name__ == "__main__":
    main()
