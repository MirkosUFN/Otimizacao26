"""
Interface Gráfica para Resolução de Programação Linear — Método Simplex.

Utiliza CustomTkinter para uma interface limpa e moderna.
"""

import customtkinter as ctk
from tkinter import messagebox
import numpy as np
from simplex import Simplex, ResultadoSimplex


# ── Tema e cores ──────────────────────────────────────────────────────────
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# Paleta warm / light
COR_FUNDO = "#f8f6f2"
COR_CARD = "#ffffff"
COR_CARD_ALT = "#faf7f0"
COR_PRIMARIA = "#4f46e5"       # Indigo
COR_PRIMARIA_HOVER = "#4338ca"
COR_SECUNDARIA = "#e67e22"     # Laranja quente
COR_SECUNDARIA_HOVER = "#d35400"
COR_TITULO = "#1e1b4b"
COR_TEXTO = "#334155"
COR_TEXTO_LEVE = "#64748b"
COR_SUCESSO = "#059669"
COR_SUCESSO_BG = "#ecfdf5"
COR_ERRO_COR = "#dc2626"
COR_ERRO_BG = "#fef2f2"
COR_AVISO_COR = "#d97706"
COR_AVISO_BG = "#fffbeb"
COR_BORDA = "#e2e8f0"
COR_INPUT = "#f1f5f9"
COR_INPUT_BORDA = "#cbd5e1"
COR_DESTAQUE = "#7c3aed"
COR_TABLEAU_HEAD = "#eef2ff"
COR_TABLEAU_ZEBRA = "#f8fafc"


class ScrollableFrame(ctk.CTkScrollableFrame):
    """Frame rolável para conteúdo extenso."""
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)


class App(ctk.CTk):
    """Janela principal do Otimizador Linear."""

    def __init__(self):
        super().__init__()

        # ── Janela ──
        self.title("Otimizador Linear — Simplex")
        self.geometry("1220x850")
        self.minsize(1020, 720)
        self.configure(fg_color=COR_FUNDO)

        # Estado
        self.campos_obj = []
        self.campos_restricoes = []
        self.seletores_sinal = []
        self.campos_ld = []
        self.area_restricoes = None

        # Montar tudo
        self._montar_interface()

    # ══════════════════════════════════════════════════════════════════════
    #  LAYOUT
    # ══════════════════════════════════════════════════════════════════════

    def _montar_interface(self):
        """Constrói a interface completa."""
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)

        self._montar_topo()

        corpo = ctk.CTkFrame(self, fg_color="transparent")
        corpo.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))
        corpo.grid_columnconfigure(0, weight=2)
        corpo.grid_columnconfigure(1, weight=3)
        corpo.grid_rowconfigure(0, weight=1)

        self._montar_painel_esquerdo(corpo)
        self._montar_painel_direito(corpo)

    # ── Topo ──────────────────────────────────────────────────────────────

    def _montar_topo(self):
        """Barra superior com título."""
        barra = ctk.CTkFrame(self, fg_color=COR_CARD, corner_radius=0, height=68,
                             border_width=0)
        barra.grid(row=0, column=0, sticky="ew")
        barra.grid_propagate(False)
        barra.grid_columnconfigure(1, weight=1)

        # Faixa colorida no topo
        faixa = ctk.CTkFrame(barra, fg_color=COR_PRIMARIA, height=4, corner_radius=0)
        faixa.place(x=0, y=0, relwidth=1)

        titulo = ctk.CTkLabel(
            barra, text="🔢  Otimizador Linear",
            font=ctk.CTkFont(family="Segoe UI", size=22, weight="bold"),
            text_color=COR_TITULO,
        )
        titulo.grid(row=0, column=0, padx=28, pady=(14, 10), sticky="w")

        desc = ctk.CTkLabel(
            barra, text="Resolução de problemas de PL pelo Método Simplex",
            font=ctk.CTkFont(family="Segoe UI", size=12),
            text_color=COR_TEXTO_LEVE,
        )
        desc.grid(row=0, column=1, padx=8, pady=(14, 10), sticky="w")

    # ── Painel Esquerdo (Entrada) ─────────────────────────────────────────

    def _montar_painel_esquerdo(self, pai):
        """Painel de definição do problema."""
        painel = ctk.CTkFrame(pai, fg_color=COR_CARD, corner_radius=12,
                              border_width=1, border_color=COR_BORDA)
        painel.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        painel.grid_columnconfigure(0, weight=1)
        painel.grid_rowconfigure(4, weight=1)

        # Cabeçalho
        ctk.CTkLabel(
            painel, text="Definição do Problema",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=COR_TITULO,
        ).grid(row=0, column=0, padx=20, pady=(18, 6), sticky="w")

        # ── Config: variáveis, restrições, tipo ──
        caixa_cfg = ctk.CTkFrame(painel, fg_color=COR_CARD_ALT, corner_radius=10,
                                  border_width=1, border_color=COR_BORDA)
        caixa_cfg.grid(row=1, column=0, sticky="ew", padx=16, pady=6)

        # Linha 1 — Variáveis e Restrições
        ctk.CTkLabel(caixa_cfg, text="Nº de variáveis:", text_color=COR_TEXTO,
                     font=ctk.CTkFont(size=12)).grid(row=0, column=0, padx=(14, 4), pady=(10, 5))
        self.campo_nvars = ctk.CTkEntry(caixa_cfg, width=55, justify="center",
                                         fg_color=COR_INPUT, border_color=COR_INPUT_BORDA,
                                         text_color=COR_TEXTO, corner_radius=6)
        self.campo_nvars.insert(0, "2")
        self.campo_nvars.grid(row=0, column=1, padx=4, pady=(10, 5))

        ctk.CTkLabel(caixa_cfg, text="Nº de restrições:", text_color=COR_TEXTO,
                     font=ctk.CTkFont(size=12)).grid(row=0, column=2, padx=(18, 4), pady=(10, 5))
        self.campo_nrest = ctk.CTkEntry(caixa_cfg, width=55, justify="center",
                                         fg_color=COR_INPUT, border_color=COR_INPUT_BORDA,
                                         text_color=COR_TEXTO, corner_radius=6)
        self.campo_nrest.insert(0, "2")
        self.campo_nrest.grid(row=0, column=3, padx=4, pady=(10, 5))

        # Linha 2 — Tipo + botão atualizar
        ctk.CTkLabel(caixa_cfg, text="Objetivo:", text_color=COR_TEXTO,
                     font=ctk.CTkFont(size=12)).grid(row=1, column=0, padx=(14, 4), pady=(5, 10))
        self.seletor_tipo = ctk.CTkComboBox(
            caixa_cfg, values=["Maximizar", "Minimizar"], width=130,
            fg_color=COR_INPUT, border_color=COR_INPUT_BORDA, text_color=COR_TEXTO,
            button_color=COR_PRIMARIA, dropdown_fg_color=COR_CARD,
            dropdown_text_color=COR_TEXTO, state="readonly",
            corner_radius=6,
        )
        self.seletor_tipo.set("Maximizar")
        self.seletor_tipo.grid(row=1, column=1, columnspan=2, padx=4, pady=(5, 10), sticky="w")

        btn_atualizar = ctk.CTkButton(
            caixa_cfg, text="Atualizar campos", command=self._gerar_campos,
            fg_color=COR_PRIMARIA, hover_color=COR_PRIMARIA_HOVER,
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32, corner_radius=8, text_color="#ffffff",
        )
        btn_atualizar.grid(row=1, column=3, padx=(8, 14), pady=(5, 10), sticky="e")

        # ── Separador ──
        ctk.CTkFrame(painel, height=1, fg_color=COR_BORDA).grid(
            row=2, column=0, sticky="ew", padx=16, pady=6)

        # ── Info ──
        self.lbl_info = ctk.CTkLabel(
            painel, text="Configure as dimensões e clique em 'Atualizar campos'",
            font=ctk.CTkFont(size=11, slant="italic"),
            text_color=COR_TEXTO_LEVE,
        )
        self.lbl_info.grid(row=3, column=0, padx=20, pady=(2, 4), sticky="w")

        # ── Área rolável para FO + restrições ──
        self.scroll_entrada = ScrollableFrame(
            painel, fg_color=COR_CARD, corner_radius=0,
            scrollbar_button_color=COR_PRIMARIA,
        )
        self.scroll_entrada.grid(row=4, column=0, sticky="nsew", padx=4, pady=2)
        self.scroll_entrada.grid_columnconfigure(0, weight=1)

        # ── Botões ──
        caixa_btn = ctk.CTkFrame(painel, fg_color="transparent")
        caixa_btn.grid(row=5, column=0, sticky="ew", padx=16, pady=(10, 18))
        caixa_btn.grid_columnconfigure((0, 1, 2), weight=1)

        btn_resolver = ctk.CTkButton(
            caixa_btn, text="Calcular Solução", command=self._resolver,
            fg_color=COR_SECUNDARIA, hover_color=COR_SECUNDARIA_HOVER,
            text_color="#ffffff",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=44, corner_radius=10,
        )
        btn_resolver.grid(row=0, column=0, padx=(0, 5), sticky="ew")

        btn_demo = ctk.CTkButton(
            caixa_btn, text="Carregar Demo", command=self._carregar_demo,
            fg_color="transparent", hover_color=COR_CARD_ALT,
            border_width=2, border_color=COR_PRIMARIA,
            text_color=COR_PRIMARIA,
            font=ctk.CTkFont(size=12, weight="bold"),
            height=44, corner_radius=10,
        )
        btn_demo.grid(row=0, column=1, padx=5, sticky="ew")

        btn_reset = ctk.CTkButton(
            caixa_btn, text="Resetar", command=self._resetar,
            fg_color="transparent", hover_color="#fef2f2",
            border_width=2, border_color=COR_ERRO_COR,
            text_color=COR_ERRO_COR,
            font=ctk.CTkFont(size=12, weight="bold"),
            height=44, corner_radius=10,
        )
        btn_reset.grid(row=0, column=2, padx=(5, 0), sticky="ew")

        # Gerar campos iniciais
        self._gerar_campos()

    # ── Painel Direito (Saída) ────────────────────────────────────────────

    def _montar_painel_direito(self, pai):
        """Painel de exibição dos resultados."""
        painel = ctk.CTkFrame(pai, fg_color=COR_CARD, corner_radius=12,
                              border_width=1, border_color=COR_BORDA)
        painel.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        painel.grid_columnconfigure(0, weight=1)
        painel.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(
            painel, text="Resultado da Otimização",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=COR_TITULO,
        ).grid(row=0, column=0, padx=20, pady=(18, 6), sticky="w")

        self.scroll_saida = ScrollableFrame(
            painel, fg_color=COR_CARD, corner_radius=0,
            scrollbar_button_color=COR_SECUNDARIA,
        )
        self.scroll_saida.grid(row=1, column=0, sticky="nsew", padx=4, pady=(4, 18))
        self.scroll_saida.grid_columnconfigure(0, weight=1)

        # Mensagem inicial
        self.msg_vazia = ctk.CTkLabel(
            self.scroll_saida,
            text="Nenhum resultado ainda.\nDefina o problema e clique em \"Calcular Solução\".",
            font=ctk.CTkFont(size=13),
            text_color=COR_TEXTO_LEVE,
            justify="center",
        )
        self.msg_vazia.grid(row=0, column=0, pady=100)

    # ══════════════════════════════════════════════════════════════════════
    #  GERAÇÃO DE CAMPOS
    # ══════════════════════════════════════════════════════════════════════

    def _gerar_campos(self):
        """Gera dinamicamente os campos de entrada."""
        try:
            n = int(self.campo_nvars.get())
            m = int(self.campo_nrest.get())
            if n < 1 or m < 1:
                raise ValueError
            if n > 20 or m > 20:
                messagebox.showwarning("Atenção", "O limite é de 20 variáveis e 20 restrições.")
                return
        except ValueError:
            messagebox.showerror("Entrada inválida",
                                 "Informe números inteiros positivos para variáveis e restrições.")
            return

        # Limpar
        for w in self.scroll_entrada.winfo_children():
            w.destroy()

        self.campos_obj = []
        self.campos_restricoes = []
        self.seletores_sinal = []
        self.campos_ld = []

        # ── Função Objetivo ──
        ctk.CTkLabel(
            self.scroll_entrada, text="Função Objetivo",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COR_PRIMARIA,
        ).grid(row=0, column=0, padx=14, pady=(14, 4), sticky="w")

        caixa_fo = ctk.CTkFrame(self.scroll_entrada, fg_color=COR_CARD_ALT,
                                 corner_radius=8, border_width=1, border_color=COR_BORDA)
        caixa_fo.grid(row=1, column=0, sticky="ew", padx=14, pady=4)

        ctk.CTkLabel(caixa_fo, text="Z  =",
                     font=ctk.CTkFont(family="Consolas", size=14, weight="bold"),
                     text_color=COR_TITULO).grid(row=0, column=0, padx=(14, 6), pady=12)

        for j in range(n):
            if j > 0:
                ctk.CTkLabel(caixa_fo, text="+", text_color=COR_TEXTO_LEVE,
                             font=ctk.CTkFont(size=14)).grid(row=0, column=3 * j, padx=3, pady=12)

            entrada = ctk.CTkEntry(
                caixa_fo, width=52, justify="center",
                fg_color=COR_INPUT, border_color=COR_INPUT_BORDA,
                text_color=COR_TEXTO, placeholder_text="0",
                corner_radius=6,
            )
            entrada.grid(row=0, column=3 * j + 1, padx=2, pady=12)
            self.campos_obj.append(entrada)

            ctk.CTkLabel(caixa_fo, text=f"x{j + 1}",
                         text_color=COR_DESTAQUE,
                         font=ctk.CTkFont(family="Consolas", size=12, weight="bold")
                         ).grid(row=0, column=3 * j + 2, padx=(1, 5), pady=12)

        # ── Restrições ──
        ctk.CTkLabel(
            self.scroll_entrada, text="Restrições",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COR_PRIMARIA,
        ).grid(row=2, column=0, padx=14, pady=(18, 4), sticky="w")

        for i in range(m):
            caixa_r = ctk.CTkFrame(self.scroll_entrada, fg_color=COR_CARD_ALT,
                                    corner_radius=8, border_width=1, border_color=COR_BORDA)
            caixa_r.grid(row=3 + i, column=0, sticky="ew", padx=14, pady=3)

            # Número da restrição
            badge = ctk.CTkLabel(caixa_r, text=f"{i + 1}",
                                 font=ctk.CTkFont(size=10, weight="bold"),
                                 text_color="#ffffff", fg_color=COR_PRIMARIA,
                                 corner_radius=10, width=24, height=24)
            badge.grid(row=0, column=0, padx=(10, 6), pady=10)

            linha = []
            for j in range(n):
                if j > 0:
                    ctk.CTkLabel(caixa_r, text="+", text_color=COR_TEXTO_LEVE,
                                 font=ctk.CTkFont(size=13)).grid(row=0, column=4 * j, padx=2, pady=10)

                entrada = ctk.CTkEntry(
                    caixa_r, width=48, justify="center",
                    fg_color=COR_INPUT, border_color=COR_INPUT_BORDA,
                    text_color=COR_TEXTO, placeholder_text="0",
                    corner_radius=6,
                )
                entrada.grid(row=0, column=4 * j + 1, padx=2, pady=10)
                linha.append(entrada)

                ctk.CTkLabel(caixa_r, text=f"x{j + 1}",
                             text_color=COR_DESTAQUE,
                             font=ctk.CTkFont(family="Consolas", size=11, weight="bold")
                             ).grid(row=0, column=4 * j + 2, padx=(0, 4), pady=10)

            self.campos_restricoes.append(linha)

            # Seletor de sinal
            seletor = ctk.CTkComboBox(
                caixa_r, values=["≤", "≥", "="], width=62,
                fg_color=COR_INPUT, border_color=COR_INPUT_BORDA, text_color=COR_TEXTO,
                button_color=COR_SECUNDARIA, dropdown_fg_color=COR_CARD,
                dropdown_text_color=COR_TEXTO, state="readonly",
                corner_radius=6,
                font=ctk.CTkFont(size=13),
            )
            seletor.set("≤")
            seletor.grid(row=0, column=4 * n + 1, padx=5, pady=10)
            self.seletores_sinal.append(seletor)

            # Lado direito (b)
            campo_b = ctk.CTkEntry(
                caixa_r, width=58, justify="center",
                fg_color=COR_INPUT, border_color=COR_INPUT_BORDA,
                text_color=COR_TEXTO, placeholder_text="0",
                corner_radius=6,
            )
            campo_b.grid(row=0, column=4 * n + 2, padx=(4, 12), pady=10)
            self.campos_ld.append(campo_b)

        # Nota inferior
        ctk.CTkLabel(
            self.scroll_entrada, text="* Todas as variáveis são consideradas ≥ 0",
            font=ctk.CTkFont(size=10, slant="italic"),
            text_color=COR_TEXTO_LEVE,
        ).grid(row=3 + m, column=0, padx=14, pady=(8, 4), sticky="w")

        self.lbl_info.configure(text=f"Problema configurado: {n} variáveis, {m} restrições")

    # ══════════════════════════════════════════════════════════════════════
    #  RESOLVER
    # ══════════════════════════════════════════════════════════════════════

    def _resolver(self):
        """Coleta os dados, executa o Simplex e exibe os resultados."""
        try:
            n = int(self.campo_nvars.get())
            m = int(self.campo_nrest.get())
        except ValueError:
            messagebox.showerror("Erro", "Dimensões inválidas.")
            return

        # Função objetivo
        try:
            coefs = []
            for j in range(n):
                txt = self.campos_obj[j].get().strip()
                coefs.append(float(txt) if txt else 0.0)
        except (ValueError, IndexError):
            messagebox.showerror("Erro", "Coeficientes da função objetivo inválidos.")
            return

        tipo = 'max' if self.seletor_tipo.get() == "Maximizar" else 'min'

        # Montar o solver
        solver = Simplex(n, m)
        solver.definir_objetivo(coefs, tipo)

        try:
            for i in range(m):
                cs = []
                for j in range(n):
                    txt = self.campos_restricoes[i][j].get().strip()
                    cs.append(float(txt) if txt else 0.0)

                trad = {"≤": "<=", "≥": ">=", "=": "="}
                sinal = trad.get(self.seletores_sinal[i].get(), "<=")

                txt_b = self.campos_ld[i].get().strip()
                b = float(txt_b) if txt_b else 0.0

                solver.definir_restricao(i, cs, sinal, b)
        except (ValueError, IndexError) as e:
            messagebox.showerror("Erro", f"Dados inválidos nas restrições:\n{e}")
            return

        resultado = solver.resolver()
        self._mostrar_resultado(resultado, n, m, coefs, tipo, solver)

    # ══════════════════════════════════════════════════════════════════════
    #  EXIBIÇÃO DO RESULTADO
    # ══════════════════════════════════════════════════════════════════════

    def _mostrar_resultado(self, res: ResultadoSimplex, n, m, coefs, tipo, solver):
        """Renderiza o resultado no painel direito."""
        for w in self.scroll_saida.winfo_children():
            w.destroy()

        linha = 0

        # ── Card de status ──
        if res.status == "otimo":
            cor_borda_st = COR_SUCESSO
            fundo_st = COR_SUCESSO_BG
            icone = "✓"
            titulo_st = "SOLUÇÃO ÓTIMA ENCONTRADA"
        elif res.status == "ilimitado":
            cor_borda_st = COR_AVISO_COR
            fundo_st = COR_AVISO_BG
            icone = "!"
            titulo_st = "PROBLEMA ILIMITADO"
        elif res.status == "inviavel":
            cor_borda_st = COR_ERRO_COR
            fundo_st = COR_ERRO_BG
            icone = "✗"
            titulo_st = "PROBLEMA INVIÁVEL"
        else:
            cor_borda_st = COR_ERRO_COR
            fundo_st = COR_ERRO_BG
            icone = "✗"
            titulo_st = "ERRO"

        card_st = ctk.CTkFrame(self.scroll_saida, fg_color=fundo_st, corner_radius=10,
                                border_width=2, border_color=cor_borda_st)
        card_st.grid(row=linha, column=0, sticky="ew", padx=14, pady=(14, 8))
        card_st.grid_columnconfigure(1, weight=1)

        # Ícone circular
        badge_st = ctk.CTkLabel(card_st, text=icone,
                                 font=ctk.CTkFont(size=18, weight="bold"),
                                 text_color="#ffffff", fg_color=cor_borda_st,
                                 corner_radius=16, width=36, height=36)
        badge_st.grid(row=0, column=0, rowspan=2, padx=(14, 10), pady=14)

        ctk.CTkLabel(card_st, text=titulo_st,
                     font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=cor_borda_st, fg_color="transparent",
                     ).grid(row=0, column=1, padx=(0, 14), pady=(14, 0), sticky="w")

        ctk.CTkLabel(card_st, text=res.mensagem,
                     font=ctk.CTkFont(size=11),
                     text_color=COR_TEXTO_LEVE, fg_color="transparent",
                     ).grid(row=1, column=1, padx=(0, 14), pady=(0, 14), sticky="w")
        linha += 1

        # ── Formulação ──
        card_form = ctk.CTkFrame(self.scroll_saida, fg_color=COR_CARD_ALT, corner_radius=10,
                                  border_width=1, border_color=COR_BORDA)
        card_form.grid(row=linha, column=0, sticky="ew", padx=14, pady=6)
        card_form.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(card_form, text="Formulação",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=COR_PRIMARIA,
                     ).grid(row=0, column=0, padx=14, pady=(10, 4), sticky="w")

        # String da FO
        partes_fo = []
        for j in range(n):
            c = coefs[j]
            if c == 0:
                continue
            sinal = "+ " if c > 0 and partes_fo else ("" if c >= 0 else "")
            if c == 1:
                partes_fo.append(f"{sinal}x{j + 1}")
            elif c == -1:
                partes_fo.append(f"-x{j + 1}")
            elif c == int(c):
                partes_fo.append(f"{sinal}{int(c)}·x{j + 1}")
            else:
                partes_fo.append(f"{sinal}{c}·x{j + 1}")

        tipo_texto = "Max" if tipo == "max" else "Min"
        ctk.CTkLabel(card_form, text=f"{tipo_texto}  Z = {' '.join(partes_fo) if partes_fo else '0'}",
                     font=ctk.CTkFont(family="Consolas", size=12),
                     text_color=COR_TEXTO).grid(row=1, column=0, padx=22, pady=2, sticky="w")

        ctk.CTkLabel(card_form, text="Sujeito a:",
                     font=ctk.CTkFont(size=11),
                     text_color=COR_TEXTO_LEVE).grid(row=2, column=0, padx=22, pady=(4, 2), sticky="w")

        for i in range(m):
            partes_r = []
            for j in range(n):
                c = solver.A[i][j]
                if c == 0:
                    continue
                sinal = "+ " if c > 0 and partes_r else ("" if c >= 0 else "")
                if c == 1:
                    partes_r.append(f"{sinal}x{j + 1}")
                elif c == -1:
                    partes_r.append(f"-x{j + 1}")
                elif c == int(c):
                    partes_r.append(f"{sinal}{int(c)}·x{j + 1}")
                else:
                    partes_r.append(f"{sinal}{c}·x{j + 1}")

            sinal_bonito = {"<=": "≤", ">=": "≥", "=": "="}.get(solver.sinais[i], "≤")
            b = solver.b[i]
            b_str = str(int(b)) if b == int(b) else str(b)
            texto_r = f"    {' '.join(partes_r) if partes_r else '0'}  {sinal_bonito}  {b_str}"

            ctk.CTkLabel(card_form, text=texto_r,
                         font=ctk.CTkFont(family="Consolas", size=12),
                         text_color=COR_TEXTO).grid(row=3 + i, column=0, padx=22, pady=1, sticky="w")

        ctk.CTkLabel(card_form, text=f"    xᵢ ≥ 0  (i = 1, …, {n})",
                     font=ctk.CTkFont(family="Consolas", size=11),
                     text_color=COR_TEXTO_LEVE).grid(row=3 + m, column=0, padx=22, pady=(2, 10), sticky="w")
        linha += 1

        # ── Valores da Solução ──
        if res.status == "otimo" and res.solucao:
            card_sol = ctk.CTkFrame(self.scroll_saida, fg_color=COR_CARD, corner_radius=10,
                                     border_width=2, border_color=COR_SUCESSO)
            card_sol.grid(row=linha, column=0, sticky="ew", padx=14, pady=8)
            card_sol.grid_columnconfigure(0, weight=1)

            ctk.CTkLabel(card_sol, text="Valores Ótimos",
                         font=ctk.CTkFont(size=13, weight="bold"),
                         text_color=COR_SUCESSO,
                         ).grid(row=0, column=0, padx=14, pady=(12, 6), sticky="w")

            # Z*
            vo = res.valor_otimo
            vo_str = str(int(vo)) if vo == int(vo) else f"{vo:.4f}"

            frame_z = ctk.CTkFrame(card_sol, fg_color=COR_SUCESSO_BG, corner_radius=8)
            frame_z.grid(row=1, column=0, sticky="ew", padx=14, pady=4)

            ctk.CTkLabel(frame_z, text="Z* =",
                         font=ctk.CTkFont(family="Consolas", size=13),
                         text_color=COR_TEXTO).grid(row=0, column=0, padx=(14, 4), pady=10)
            ctk.CTkLabel(frame_z, text=vo_str,
                         font=ctk.CTkFont(family="Consolas", size=20, weight="bold"),
                         text_color=COR_SECUNDARIA).grid(row=0, column=1, padx=4, pady=10)

            # Variáveis
            frame_vars = ctk.CTkFrame(card_sol, fg_color="transparent")
            frame_vars.grid(row=2, column=0, sticky="ew", padx=14, pady=(4, 14))

            col = 0
            for nome, valor in res.solucao.items():
                v_str = str(int(valor)) if valor == int(valor) else f"{valor:.4f}"

                mini = ctk.CTkFrame(frame_vars, fg_color=COR_CARD_ALT, corner_radius=8,
                                     border_width=1, border_color=COR_BORDA)
                mini.grid(row=0, column=col, padx=(0, 8), pady=4)

                ctk.CTkLabel(mini, text=nome,
                             font=ctk.CTkFont(family="Consolas", size=11),
                             text_color=COR_TEXTO_LEVE).grid(row=0, column=0, padx=(10, 4), pady=(8, 2))
                ctk.CTkLabel(mini, text=v_str,
                             font=ctk.CTkFont(family="Consolas", size=15, weight="bold"),
                             text_color=COR_TITULO).grid(row=1, column=0, padx=10, pady=(0, 8))
                col += 1
            linha += 1

        # ── Iterações ──
        if res.iteracoes:
            ctk.CTkLabel(
                self.scroll_saida, text=f"Passo a passo — {len(res.iteracoes)} iterações",
                font=ctk.CTkFont(size=13, weight="bold"),
                text_color=COR_PRIMARIA,
            ).grid(row=linha, column=0, padx=14, pady=(14, 6), sticky="w")
            linha += 1

            for idx_it, it in enumerate(res.iteracoes):
                eh_final = (idx_it == len(res.iteracoes) - 1)

                card_it = ctk.CTkFrame(self.scroll_saida, fg_color=COR_CARD_ALT, corner_radius=8,
                                        border_width=1,
                                        border_color=COR_SUCESSO if eh_final and res.status == "otimo" else COR_BORDA)
                card_it.grid(row=linha, column=0, sticky="ew", padx=14, pady=3)
                card_it.grid_columnconfigure(0, weight=1)

                # Título da iteração
                titulo_it = f"Iteração {it.numero}"
                if it.variavel_entrada:
                    titulo_it += f"   →  entra {it.variavel_entrada}"
                if it.variavel_saida:
                    titulo_it += f" ,  sai {it.variavel_saida}"
                if eh_final and res.status == "otimo":
                    titulo_it += "   ● ÓTIMO"

                cor_tit_it = COR_SUCESSO if eh_final and res.status == "otimo" else COR_TEXTO

                ctk.CTkLabel(card_it, text=titulo_it,
                             font=ctk.CTkFont(size=11, weight="bold"),
                             text_color=cor_tit_it,
                             ).grid(row=0, column=0, padx=12, pady=(8, 4), sticky="w")

                # Tableau
                tab = it.tableau
                cols = it.nomes_colunas
                bases = it.variaveis_base
                nr, nc = tab.shape

                linhas_txt = []
                header = ["Base"] + cols
                larguras = [max(6, len(h) + 1) for h in header]

                for i in range(nr - 1):
                    cells = [bases[i]] + [self._fmt(tab[i, j]) for j in range(nc)]
                    for k, cell in enumerate(cells):
                        larguras[k] = max(larguras[k], len(cell) + 1)

                cells_z = ["Z"] + [self._fmt(tab[nr - 1, j]) for j in range(nc)]
                for k, cell in enumerate(cells_z):
                    larguras[k] = max(larguras[k], len(cell) + 1)

                linhas_txt.append("│".join(h.center(larguras[k]) for k, h in enumerate(header)))
                linhas_txt.append("─" * len(linhas_txt[0]))

                for i in range(nr - 1):
                    cells = [bases[i]] + [self._fmt(tab[i, j]) for j in range(nc)]
                    linhas_txt.append("│".join(cell.center(larguras[k]) for k, cell in enumerate(cells)))

                linhas_txt.append("─" * len(linhas_txt[0]))
                linhas_txt.append("│".join(cell.center(larguras[k]) for k, cell in enumerate(cells_z)))

                ctk.CTkLabel(card_it, text="\n".join(linhas_txt),
                             font=ctk.CTkFont(family="Consolas", size=11),
                             text_color=COR_TEXTO, justify="left", anchor="w",
                             ).grid(row=1, column=0, padx=12, pady=(2, 10), sticky="w")
                linha += 1

    # ══════════════════════════════════════════════════════════════════════
    #  UTILITÁRIOS
    # ══════════════════════════════════════════════════════════════════════

    @staticmethod
    def _fmt(v: float) -> str:
        """Formata número para o tableau."""
        if abs(v) < 1e-10:
            return "0"
        if abs(v - round(v)) < 1e-10:
            return str(int(round(v)))
        return f"{v:.3f}"

    def _carregar_demo(self):
        """Preenche um problema de demonstração."""
        self.campo_nvars.delete(0, "end")
        self.campo_nvars.insert(0, "2")
        self.campo_nrest.delete(0, "end")
        self.campo_nrest.insert(0, "3")
        self.seletor_tipo.set("Maximizar")
        self._gerar_campos()

        # Max Z = 3x1 + 2x2
        # s.a. 2x1 + x2 <= 18
        #      2x1 + 3x2 <= 42
        #      3x1 + x2 <= 24
        for j, v in enumerate([3, 2]):
            self.campos_obj[j].insert(0, str(v))

        dados = [
            ([2, 1], "≤", 18),
            ([2, 3], "≤", 42),
            ([3, 1], "≤", 24),
        ]
        for i, (cs, sn, b) in enumerate(dados):
            for j, v in enumerate(cs):
                self.campos_restricoes[i][j].insert(0, str(v))
            self.seletores_sinal[i].set(sn)
            self.campos_ld[i].insert(0, str(b))

    def _resetar(self):
        """Limpa tudo e volta ao estado inicial."""
        self.campo_nvars.delete(0, "end")
        self.campo_nvars.insert(0, "2")
        self.campo_nrest.delete(0, "end")
        self.campo_nrest.insert(0, "2")
        self.seletor_tipo.set("Maximizar")
        self._gerar_campos()

        for w in self.scroll_saida.winfo_children():
            w.destroy()
        self.msg_vazia = ctk.CTkLabel(
            self.scroll_saida,
            text="Nenhum resultado ainda.\nDefina o problema e clique em \"Calcular Solução\".",
            font=ctk.CTkFont(size=13),
            text_color=COR_TEXTO_LEVE,
            justify="center",
        )
        self.msg_vazia.grid(row=0, column=0, pady=100)


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
