# ⚡ Simplex Solver — Programação Linear

Interface gráfica moderna para resolução de problemas de Programação Linear
usando o **Método Simplex** (Big-M).

---

## 📋 Funcionalidades

- **Maximização e Minimização** de funções objetivo lineares
- **Restrições** com sinais `≤`, `≥` e `=`
- Exibição da **formulação completa** do problema
- Exibição da **solução ótima** (valor ótimo + valores das variáveis)
- Exibição de **todas as iterações** com tableaux detalhados
- Detecção de problemas **ilimitados** e **inviáveis**
- **Exemplo pré-carregado** para teste rápido
- Interface gráfica moderna com tema escuro

---

## 🚀 Como Executar

### 1. Instalar dependências

```bash
pip install -r requirements.txt
```

### 2. Executar a aplicação

```bash
python main.py
```

---

## 📦 Estrutura do Projeto

```
simplex-solver/
├── main.py             # Ponto de entrada
├── app.py              # Interface gráfica (CustomTkinter)
├── simplex.py          # Algoritmo Simplex (Big-M)
├── requirements.txt    # Dependências do projeto
└── README.md           # Este arquivo
```

---

## 🧮 Sobre o Algoritmo

O solver implementa o **Método Simplex Tabular** com a técnica **Big-M** para
lidar com variáveis artificiais. O fluxo é:

1. **Padronização**: Converte o problema para forma padrão
2. **Variáveis de folga/excesso**: Adicionadas conforme o tipo da restrição
3. **Variáveis artificiais**: Adicionadas para restrições `≥` e `=` com penalidade Big-M
4. **Pivoteamento**: Iterações até atingir a solução ótima ou detectar infactibilidade/ilimitação

---

## 📖 Exemplo

O botão **"📋 Exemplo"** carrega o seguinte problema:

```
Max  Z = 5x₁ + 4x₂
Sujeito a:
    6x₁ + 4x₂ ≤ 24
     x₁ + 2x₂ ≤ 6
     x₁ +  x₂ ≤ 5
    x₁, x₂ ≥ 0
```

**Solução ótima**: Z* = 21, x₁ = 3, x₂ = 3/2

---

## 🛠 Tecnologias

- **Python 3.8+**
- **CustomTkinter** — Interface gráfica moderna
- **NumPy** — Operações matriciais para o algoritmo Simplex
