"""
Ponto de entrada principal da aplicação Simplex Solver.
Execute este arquivo para iniciar a interface gráfica.
"""

from app import main

if __name__ == "__main__":
    main()
