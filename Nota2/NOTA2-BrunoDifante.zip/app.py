"""
Interface Gráfica para o Solver de Programação Linear (Simplex).

Utiliza CustomTkinter para uma interface moderna e responsiva.
"""

import customtkinter as ctk
from tkinter import messagebox, font as tkfont
import numpy as np
from simplex import Simplex, ResultadoSimplex


# ── Configuração do tema ──────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Paleta de cores
COR_BG_ESCURO = "#0f0f1a"
COR_BG_CARD = "#1a1a2e"
COR_BG_CARD2 = "#16213e"
COR_ACENTO = "#00d4aa"
COR_ACENTO2 = "#7c3aed"
COR_TEXTO = "#e2e8f0"
COR_TEXTO_DIM = "#94a3b8"
COR_SUCESSO = "#10b981"
COR_ERRO = "#ef4444"
COR_AVISO = "#f59e0b"
COR_BORDA = "#2d2d4a"
COR_INPUT_BG = "#0d1117"
COR_HEADER = "#6366f1"


class ScrollableFrame(ctk.CTkScrollableFrame):
    """Frame com scroll para conteúdo longo."""
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)


class App(ctk.CTk):
    """Aplicação principal do Solver Simplex."""

    def __init__(self):
        super().__init__()

        # ── Configuração da janela ──
        self.title("⚡ Simplex Solver — Programação Linear")
        self.geometry("1200x820")
        self.minsize(1000, 700)
        self.configure(fg_color=COR_BG_ESCURO)

        # Variáveis
        self.entries_obj = []
        self.entries_restricoes = []  # Lista de listas
        self.combos_sinais = []
        self.entries_rhs = []
        self.frame_restricoes_inner = None
        self.frame_obj_inner = None

        # ── Layout principal ──
        self._criar_layout()

    def _criar_layout(self):
        """Monta toda a interface."""
        # Container principal com 2 colunas
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)

        # ═══ Header ═══
        self._criar_header()

        # ═══ Corpo (entrada + resultado) ═══
        corpo = ctk.CTkFrame(self, fg_color="transparent")
        corpo.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 16))
        corpo.grid_columnconfigure(0, weight=2)
        corpo.grid_columnconfigure(1, weight=3)
        corpo.grid_rowconfigure(0, weight=1)

        # Painel esquerdo: Entrada
        self._criar_painel_entrada(corpo)

        # Painel direito: Resultado
        self._criar_painel_resultado(corpo)

    def _criar_header(self):
        """Cria o cabeçalho estilizado."""
        header = ctk.CTkFrame(self, fg_color=COR_BG_CARD, corner_radius=0, height=72)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        # Ícone + Título
        titulo = ctk.CTkLabel(
            header,
            text="⚡  SIMPLEX SOLVER",
            font=ctk.CTkFont(family="Segoe UI", size=24, weight="bold"),
            text_color=COR_ACENTO,
        )
        titulo.grid(row=0, column=0, padx=24, pady=16, sticky="w")

        subtitulo = ctk.CTkLabel(
            header,
            text="Resolva problemas de Programação Linear com o Método Simplex",
            font=ctk.CTkFont(family="Segoe UI", size=13),
            text_color=COR_TEXTO_DIM,
        )
        subtitulo.grid(row=0, column=1, padx=12, pady=16, sticky="w")

    def _criar_painel_entrada(self, parent):
        """Cria o painel de entrada de dados à esquerda."""
        painel = ctk.CTkFrame(parent, fg_color=COR_BG_CARD, corner_radius=14,
                              border_width=1, border_color=COR_BORDA)
        painel.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        painel.grid_columnconfigure(0, weight=1)
        painel.grid_rowconfigure(4, weight=1)

        # Título do painel
        ctk.CTkLabel(
            painel, text="📥  Entrada do Problema",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COR_TEXTO,
        ).grid(row=0, column=0, padx=20, pady=(16, 8), sticky="w")

        # ── Dimensões ──
        frame_dim = ctk.CTkFrame(painel, fg_color=COR_BG_CARD2, corner_radius=10)
        frame_dim.grid(row=1, column=0, sticky="ew", padx=16, pady=6)
        frame_dim.grid_columnconfigure((1, 3), weight=1)

        ctk.CTkLabel(frame_dim, text="Variáveis:", text_color=COR_TEXTO_DIM,
                     font=ctk.CTkFont(size=13)).grid(row=0, column=0, padx=(12, 4), pady=10)
        self.spin_vars = ctk.CTkEntry(frame_dim, width=60, justify="center",
                                       fg_color=COR_INPUT_BG, border_color=COR_BORDA,
                                       text_color=COR_TEXTO)
        self.spin_vars.insert(0, "2")
        self.spin_vars.grid(row=0, column=1, padx=4, pady=10, sticky="w")

        ctk.CTkLabel(frame_dim, text="Restrições:", text_color=COR_TEXTO_DIM,
                     font=ctk.CTkFont(size=13)).grid(row=0, column=2, padx=(16, 4), pady=10)
        self.spin_rest = ctk.CTkEntry(frame_dim, width=60, justify="center",
                                       fg_color=COR_INPUT_BG, border_color=COR_BORDA,
                                       text_color=COR_TEXTO)
        self.spin_rest.insert(0, "2")
        self.spin_rest.grid(row=0, column=3, padx=4, pady=10, sticky="w")

        # Tipo (Max / Min)
        ctk.CTkLabel(frame_dim, text="Tipo:", text_color=COR_TEXTO_DIM,
                     font=ctk.CTkFont(size=13)).grid(row=0, column=4, padx=(16, 4), pady=10)
        self.combo_tipo = ctk.CTkComboBox(
            frame_dim, values=["Maximizar", "Minimizar"], width=120,
            fg_color=COR_INPUT_BG, border_color=COR_BORDA, text_color=COR_TEXTO,
            button_color=COR_ACENTO2, dropdown_fg_color=COR_BG_CARD,
            dropdown_text_color=COR_TEXTO, state="readonly",
        )
        self.combo_tipo.set("Maximizar")
        self.combo_tipo.grid(row=0, column=5, padx=(4, 12), pady=10)

        # Botão gerar campos
        btn_gerar = ctk.CTkButton(
            painel, text="🔄  Gerar Campos", command=self._gerar_campos,
            fg_color=COR_ACENTO2, hover_color="#6d28d9",
            font=ctk.CTkFont(size=13, weight="bold"),
            height=36, corner_radius=8,
        )
        btn_gerar.grid(row=2, column=0, padx=16, pady=8, sticky="ew")

        # ── Separador ──
        sep = ctk.CTkFrame(painel, height=1, fg_color=COR_BORDA)
        sep.grid(row=3, column=0, sticky="ew", padx=16, pady=4)

        # ── Área scrollável para objetivo + restrições ──
        self.scroll_entrada = ScrollableFrame(
            painel, fg_color=COR_BG_CARD, corner_radius=0,
            scrollbar_button_color=COR_ACENTO2,
        )
        self.scroll_entrada.grid(row=4, column=0, sticky="nsew", padx=4, pady=4)
        self.scroll_entrada.grid_columnconfigure(0, weight=1)

        # ── Botões de ação ──
        frame_acoes = ctk.CTkFrame(painel, fg_color="transparent")
        frame_acoes.grid(row=5, column=0, sticky="ew", padx=16, pady=(8, 16))
        frame_acoes.grid_columnconfigure((0, 1, 2), weight=1)

        btn_resolver = ctk.CTkButton(
            frame_acoes, text="▶  RESOLVER", command=self._resolver,
            fg_color=COR_ACENTO, hover_color="#059669",
            text_color="#0f0f1a",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=42, corner_radius=10,
        )
        btn_resolver.grid(row=0, column=0, padx=(0, 4), sticky="ew")

        btn_exemplo = ctk.CTkButton(
            frame_acoes, text="📋 Exemplo", command=self._carregar_exemplo,
            fg_color=COR_BG_CARD2, hover_color="#1e3a5f",
            border_width=1, border_color=COR_BORDA,
            font=ctk.CTkFont(size=13),
            height=42, corner_radius=10,
        )
        btn_exemplo.grid(row=0, column=1, padx=4, sticky="ew")

        btn_limpar = ctk.CTkButton(
            frame_acoes, text="🗑 Limpar", command=self._limpar,
            fg_color=COR_BG_CARD2, hover_color="#3b1a1a",
            border_width=1, border_color=COR_BORDA,
            font=ctk.CTkFont(size=13),
            height=42, corner_radius=10,
        )
        btn_limpar.grid(row=0, column=2, padx=(4, 0), sticky="ew")

        # Gerar campos iniciais
        self._gerar_campos()

    def _criar_painel_resultado(self, parent):
        """Cria o painel de resultados à direita."""
        painel = ctk.CTkFrame(parent, fg_color=COR_BG_CARD, corner_radius=14,
                              border_width=1, border_color=COR_BORDA)
        painel.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        painel.grid_columnconfigure(0, weight=1)
        painel.grid_rowconfigure(1, weight=1)

        # Título
        ctk.CTkLabel(
            painel, text="📊  Resultado",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COR_TEXTO,
        ).grid(row=0, column=0, padx=20, pady=(16, 8), sticky="w")

        # Área de resultado com scroll
        self.scroll_resultado = ScrollableFrame(
            painel, fg_color=COR_BG_CARD, corner_radius=0,
            scrollbar_button_color=COR_ACENTO,
        )
        self.scroll_resultado.grid(row=1, column=0, sticky="nsew", padx=4, pady=(4, 16))
        self.scroll_resultado.grid_columnconfigure(0, weight=1)

        # Placeholder
        self.label_placeholder = ctk.CTkLabel(
            self.scroll_resultado,
            text="Insira um problema e clique em RESOLVER\npara ver o resultado aqui.",
            font=ctk.CTkFont(size=14),
            text_color=COR_TEXTO_DIM,
            justify="center",
        )
        self.label_placeholder.grid(row=0, column=0, pady=80)

    def _gerar_campos(self):
        """Gera os campos de entrada de acordo com nº de variáveis e restrições."""
        try:
            n = int(self.spin_vars.get())
            m = int(self.spin_rest.get())
            if n < 1 or m < 1:
                raise ValueError
            if n > 20 or m > 20:
                messagebox.showwarning("Aviso", "Limite: 20 variáveis e 20 restrições.")
                return
        except ValueError:
            messagebox.showerror("Erro", "Insira valores inteiros positivos para variáveis e restrições.")
            return

        # Limpar scroll
        for widget in self.scroll_entrada.winfo_children():
            widget.destroy()

        self.entries_obj = []
        self.entries_restricoes = []
        self.combos_sinais = []
        self.entries_rhs = []

        # ── Função Objetivo ──
        lbl_obj = ctk.CTkLabel(
            self.scroll_entrada, text="Função Objetivo",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COR_ACENTO,
        )
        lbl_obj.grid(row=0, column=0, padx=12, pady=(12, 4), sticky="w")

        frame_obj = ctk.CTkFrame(self.scroll_entrada, fg_color=COR_BG_CARD2, corner_radius=8)
        frame_obj.grid(row=1, column=0, sticky="ew", padx=12, pady=4)

        lbl_z = ctk.CTkLabel(frame_obj, text="Z =", font=ctk.CTkFont(size=13, weight="bold"),
                             text_color=COR_TEXTO)
        lbl_z.grid(row=0, column=0, padx=(12, 4), pady=10)

        for j in range(n):
            if j > 0:
                ctk.CTkLabel(frame_obj, text="+", text_color=COR_TEXTO_DIM,
                             font=ctk.CTkFont(size=13)).grid(row=0, column=2 * j, padx=2, pady=10)

            entry = ctk.CTkEntry(
                frame_obj, width=55, justify="center",
                fg_color=COR_INPUT_BG, border_color=COR_BORDA,
                text_color=COR_TEXTO, placeholder_text="0",
            )
            entry.grid(row=0, column=2 * j + 1, padx=2, pady=10)
            self.entries_obj.append(entry)

            ctk.CTkLabel(frame_obj, text=f"x{j + 1}", text_color=COR_ACENTO,
                         font=ctk.CTkFont(size=12)).grid(row=0, column=2 * j + 2, padx=(0, 6), pady=10)

        # ── Restrições ──
        lbl_rest = ctk.CTkLabel(
            self.scroll_entrada, text="Restrições",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COR_ACENTO,
        )
        lbl_rest.grid(row=2, column=0, padx=12, pady=(16, 4), sticky="w")

        for i in range(m):
            frame_r = ctk.CTkFrame(self.scroll_entrada, fg_color=COR_BG_CARD2, corner_radius=8)
            frame_r.grid(row=3 + i, column=0, sticky="ew", padx=12, pady=3)

            lbl_r = ctk.CTkLabel(frame_r, text=f"R{i + 1}:",
                                 font=ctk.CTkFont(size=12, weight="bold"),
                                 text_color=COR_TEXTO_DIM)
            lbl_r.grid(row=0, column=0, padx=(12, 4), pady=8)

            entries_row = []
            for j in range(n):
                if j > 0:
                    ctk.CTkLabel(frame_r, text="+", text_color=COR_TEXTO_DIM,
                                 font=ctk.CTkFont(size=12)).grid(row=0, column=3 * j, padx=1, pady=8)

                entry = ctk.CTkEntry(
                    frame_r, width=50, justify="center",
                    fg_color=COR_INPUT_BG, border_color=COR_BORDA,
                    text_color=COR_TEXTO, placeholder_text="0",
                )
                entry.grid(row=0, column=3 * j + 1, padx=1, pady=8)
                entries_row.append(entry)

                ctk.CTkLabel(frame_r, text=f"x{j + 1}", text_color=COR_ACENTO,
                             font=ctk.CTkFont(size=11)).grid(row=0, column=3 * j + 2, padx=(0, 3), pady=8)

            self.entries_restricoes.append(entries_row)

            # Sinal da restrição
            combo = ctk.CTkComboBox(
                frame_r, values=["≤", "≥", "="], width=65,
                fg_color=COR_INPUT_BG, border_color=COR_BORDA, text_color=COR_TEXTO,
                button_color=COR_ACENTO2, dropdown_fg_color=COR_BG_CARD,
                dropdown_text_color=COR_TEXTO, state="readonly",
                font=ctk.CTkFont(size=13),
            )
            combo.set("≤")
            combo.grid(row=0, column=3 * n + 1, padx=4, pady=8)
            self.combos_sinais.append(combo)

            # RHS
            entry_rhs = ctk.CTkEntry(
                frame_r, width=60, justify="center",
                fg_color=COR_INPUT_BG, border_color=COR_BORDA,
                text_color=COR_TEXTO, placeholder_text="0",
            )
            entry_rhs.grid(row=0, column=3 * n + 2, padx=(4, 12), pady=8)
            self.entries_rhs.append(entry_rhs)

    def _resolver(self):
        """Lê os dados e resolve o problema com o Simplex."""
        try:
            n = int(self.spin_vars.get())
            m = int(self.spin_rest.get())
        except ValueError:
            messagebox.showerror("Erro", "Valores inválidos para variáveis/restrições.")
            return

        # Ler função objetivo
        try:
            c = []
            for j in range(n):
                val = self.entries_obj[j].get().strip()
                c.append(float(val) if val else 0.0)
        except (ValueError, IndexError):
            messagebox.showerror("Erro", "Coeficientes da função objetivo inválidos.")
            return

        # Tipo
        tipo = 'max' if self.combo_tipo.get() == "Maximizar" else 'min'

        # Ler restrições
        simplex = Simplex(n, m)
        simplex.definir_objetivo(c, tipo)

        try:
            for i in range(m):
                coefs = []
                for j in range(n):
                    val = self.entries_restricoes[i][j].get().strip()
                    coefs.append(float(val) if val else 0.0)

                sinal_map = {"≤": "<=", "≥": ">=", "=": "="}
                sinal = sinal_map.get(self.combos_sinais[i].get(), "<=")

                val_rhs = self.entries_rhs[i].get().strip()
                rhs = float(val_rhs) if val_rhs else 0.0

                simplex.definir_restricao(i, coefs, sinal, rhs)
        except (ValueError, IndexError) as e:
            messagebox.showerror("Erro", f"Dados das restrições inválidos: {e}")
            return

        # Resolver
        resultado = simplex.resolver()

        # Exibir resultado
        self._exibir_resultado(resultado, n, m, c, tipo, simplex)

    def _exibir_resultado(self, resultado: ResultadoSimplex, n, m, c, tipo, simplex):
        """Exibe o resultado no painel direito."""
        # Limpar painel
        for widget in self.scroll_resultado.winfo_children():
            widget.destroy()

        row = 0

        # ═══ Status ═══
        if resultado.status == "otimo":
            cor_status = COR_SUCESSO
            icone = "✅"
            texto_status = "SOLUÇÃO ÓTIMA ENCONTRADA"
        elif resultado.status == "ilimitado":
            cor_status = COR_AVISO
            icone = "⚠️"
            texto_status = "PROBLEMA ILIMITADO"
        elif resultado.status == "inviavel":
            cor_status = COR_ERRO
            icone = "❌"
            texto_status = "PROBLEMA INVIÁVEL"
        else:
            cor_status = COR_ERRO
            icone = "❌"
            texto_status = "ERRO"

        frame_status = ctk.CTkFrame(self.scroll_resultado, fg_color=COR_BG_CARD2, corner_radius=10,
                                     border_width=2, border_color=cor_status)
        frame_status.grid(row=row, column=0, sticky="ew", padx=12, pady=(12, 8))
        frame_status.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            frame_status, text=f"{icone}  {texto_status}",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=cor_status,
        ).grid(row=0, column=0, padx=16, pady=(12, 4))

        ctk.CTkLabel(
            frame_status, text=resultado.mensagem,
            font=ctk.CTkFont(size=12),
            text_color=COR_TEXTO_DIM,
        ).grid(row=1, column=0, padx=16, pady=(2, 12))
        row += 1

        # ═══ Formulação ═══
        frame_form = ctk.CTkFrame(self.scroll_resultado, fg_color=COR_BG_CARD2, corner_radius=10)
        frame_form.grid(row=row, column=0, sticky="ew", padx=12, pady=4)
        frame_form.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            frame_form, text="📝  Formulação do Problema",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COR_HEADER,
        ).grid(row=0, column=0, padx=12, pady=(10, 4), sticky="w")

        # Montar string da FO
        termos = []
        for j in range(n):
            coef = c[j]
            if coef == 0:
                continue
            sinal = "+" if coef >= 0 and len(termos) > 0 else ""
            if coef == 1:
                termos.append(f"{sinal}x{j + 1}")
            elif coef == -1:
                termos.append(f"-x{j + 1}")
            elif coef == int(coef):
                termos.append(f"{sinal}{int(coef)}x{j + 1}")
            else:
                termos.append(f"{sinal}{coef}x{j + 1}")
        fo_str = f"{'Max' if tipo == 'max' else 'Min'}  Z = {' '.join(termos) if termos else '0'}"

        ctk.CTkLabel(frame_form, text=fo_str, font=ctk.CTkFont(family="Consolas", size=12),
                     text_color=COR_TEXTO).grid(row=1, column=0, padx=20, pady=2, sticky="w")

        ctk.CTkLabel(frame_form, text="Sujeito a:", font=ctk.CTkFont(size=12),
                     text_color=COR_TEXTO_DIM).grid(row=2, column=0, padx=20, pady=(4, 2), sticky="w")

        for i in range(m):
            termos_r = []
            for j in range(n):
                coef = simplex.A[i][j]
                if coef == 0:
                    continue
                sinal = "+ " if coef >= 0 and len(termos_r) > 0 else ""
                if coef == 1:
                    termos_r.append(f"{sinal}x{j + 1}")
                elif coef == -1:
                    termos_r.append(f"-x{j + 1}")
                elif coef == int(coef):
                    termos_r.append(f"{sinal}{int(coef)}x{j + 1}")
                else:
                    termos_r.append(f"{sinal}{coef}x{j + 1}")

            sinal_map = {"<=": "≤", ">=": "≥", "=": "="}
            sinal = sinal_map.get(simplex.sinais[i], "≤")
            rhs = simplex.b[i]
            rhs_str = str(int(rhs)) if rhs == int(rhs) else str(rhs)

            rest_str = f"   {' '.join(termos_r) if termos_r else '0'}  {sinal}  {rhs_str}"
            ctk.CTkLabel(frame_form, text=rest_str,
                         font=ctk.CTkFont(family="Consolas", size=12),
                         text_color=COR_TEXTO).grid(row=3 + i, column=0, padx=20, pady=1, sticky="w")

        ctk.CTkLabel(frame_form, text=f"   x_i ≥ 0, i = 1,...,{n}",
                     font=ctk.CTkFont(family="Consolas", size=12),
                     text_color=COR_TEXTO_DIM).grid(row=3 + m, column=0, padx=20, pady=(1, 10), sticky="w")
        row += 1

        # ═══ Solução ═══
        if resultado.status == "otimo" and resultado.solucao:
            frame_sol = ctk.CTkFrame(self.scroll_resultado, fg_color=COR_BG_CARD2, corner_radius=10,
                                      border_width=1, border_color=COR_SUCESSO)
            frame_sol.grid(row=row, column=0, sticky="ew", padx=12, pady=8)
            frame_sol.grid_columnconfigure(0, weight=1)

            ctk.CTkLabel(
                frame_sol, text="🎯  Solução Ótima",
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color=COR_SUCESSO,
            ).grid(row=0, column=0, padx=12, pady=(12, 8), sticky="w")

            # Valor ótimo
            vo = resultado.valor_otimo
            vo_str = str(int(vo)) if vo == int(vo) else f"{vo:.4f}"
            ctk.CTkLabel(
                frame_sol, text=f"Z* = {vo_str}",
                font=ctk.CTkFont(family="Consolas", size=18, weight="bold"),
                text_color=COR_ACENTO,
            ).grid(row=1, column=0, padx=20, pady=4, sticky="w")

            # Variáveis
            sol_parts = []
            for nome, valor in resultado.solucao.items():
                v_str = str(int(valor)) if valor == int(valor) else f"{valor:.4f}"
                sol_parts.append(f"{nome} = {v_str}")

            ctk.CTkLabel(
                frame_sol, text="  |  ".join(sol_parts),
                font=ctk.CTkFont(family="Consolas", size=14),
                text_color=COR_TEXTO,
            ).grid(row=2, column=0, padx=20, pady=(4, 14), sticky="w")
            row += 1

        # ═══ Iterações do Simplex ═══
        if resultado.iteracoes:
            frame_iter_header = ctk.CTkFrame(self.scroll_resultado, fg_color="transparent")
            frame_iter_header.grid(row=row, column=0, sticky="ew", padx=12, pady=(12, 4))
            frame_iter_header.grid_columnconfigure(0, weight=1)

            ctk.CTkLabel(
                frame_iter_header, text=f"📋  Iterações do Simplex ({len(resultado.iteracoes)})",
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color=COR_HEADER,
            ).grid(row=0, column=0, sticky="w")
            row += 1

            for it_idx, iteracao in enumerate(resultado.iteracoes):
                frame_it = ctk.CTkFrame(self.scroll_resultado, fg_color=COR_BG_CARD2, corner_radius=8,
                                         border_width=1, border_color=COR_BORDA)
                frame_it.grid(row=row, column=0, sticky="ew", padx=12, pady=3)
                frame_it.grid_columnconfigure(0, weight=1)

                # Header da iteração
                header_text = f"Iteração {iteracao.numero}"
                if iteracao.variavel_entrada:
                    header_text += f"  │  Entra: {iteracao.variavel_entrada}"
                if iteracao.variavel_saida:
                    header_text += f"  │  Sai: {iteracao.variavel_saida}"

                is_final = (it_idx == len(resultado.iteracoes) - 1)
                cor_header_it = COR_SUCESSO if is_final and resultado.status == "otimo" else COR_TEXTO_DIM

                ctk.CTkLabel(
                    frame_it, text=header_text,
                    font=ctk.CTkFont(size=11, weight="bold"),
                    text_color=cor_header_it,
                ).grid(row=0, column=0, padx=10, pady=(8, 4), sticky="w")

                # Tableau como texto formatado
                tableau = iteracao.tableau
                nomes_col = iteracao.nomes_colunas
                bases = iteracao.variaveis_base
                n_rows, n_cols = tableau.shape

                # Construir tabela como string
                linhas_tab = []

                # Cabeçalho
                header_cells = ["Base"] + nomes_col
                col_widths = [max(6, len(h) + 1) for h in header_cells]

                # Calcular larguras
                for i in range(n_rows - 1):
                    cells = [bases[i]] + [self._formatar_num(tableau[i, j]) for j in range(n_cols)]
                    for k, c_val in enumerate(cells):
                        col_widths[k] = max(col_widths[k], len(c_val) + 1)
                # Linha Z
                cells_z = ["Z"] + [self._formatar_num(tableau[n_rows - 1, j]) for j in range(n_cols)]
                for k, c_val in enumerate(cells_z):
                    col_widths[k] = max(col_widths[k], len(c_val) + 1)

                # Montar texto
                linha_header = "│".join(h.center(col_widths[k]) for k, h in enumerate(header_cells))
                linhas_tab.append(linha_header)
                linhas_tab.append("─" * len(linha_header))

                for i in range(n_rows - 1):
                    cells = [bases[i]] + [self._formatar_num(tableau[i, j]) for j in range(n_cols)]
                    linha = "│".join(c_val.center(col_widths[k]) for k, c_val in enumerate(cells))
                    linhas_tab.append(linha)

                linhas_tab.append("─" * len(linha_header))
                linha_z = "│".join(c_val.center(col_widths[k]) for k, c_val in enumerate(cells_z))
                linhas_tab.append(linha_z)

                texto_tab = "\n".join(linhas_tab)

                ctk.CTkLabel(
                    frame_it, text=texto_tab,
                    font=ctk.CTkFont(family="Consolas", size=11),
                    text_color=COR_TEXTO,
                    justify="left",
                    anchor="w",
                ).grid(row=1, column=0, padx=10, pady=(2, 10), sticky="w")

                row += 1

    @staticmethod
    def _formatar_num(val: float) -> str:
        """Formata um número para exibição no tableau."""
        if abs(val) < 1e-10:
            return "0"
        if abs(val - round(val)) < 1e-10:
            return str(int(round(val)))
        return f"{val:.3f}"

    def _carregar_exemplo(self):
        """Carrega um exemplo clássico de PL."""
        # Limpar
        self.spin_vars.delete(0, "end")
        self.spin_vars.insert(0, "2")
        self.spin_rest.delete(0, "end")
        self.spin_rest.insert(0, "3")
        self.combo_tipo.set("Maximizar")
        self._gerar_campos()

        # Exemplo:
        # Max Z = 5x1 + 4x2
        # s.a.  6x1 + 4x2 <= 24
        #       x1 + 2x2 <= 6
        #       x1 + x2  <= 5
        coefs_obj = [5, 4]
        for j, val in enumerate(coefs_obj):
            self.entries_obj[j].insert(0, str(val))

        restricoes = [
            ([6, 4], "≤", 24),
            ([1, 2], "≤", 6),
            ([1, 1], "≤", 5),
        ]

        for i, (coefs, sinal, rhs) in enumerate(restricoes):
            for j, val in enumerate(coefs):
                self.entries_restricoes[i][j].insert(0, str(val))
            self.combos_sinais[i].set(sinal)
            self.entries_rhs[i].insert(0, str(rhs))

    def _limpar(self):
        """Limpa todos os campos e resultados."""
        self.spin_vars.delete(0, "end")
        self.spin_vars.insert(0, "2")
        self.spin_rest.delete(0, "end")
        self.spin_rest.insert(0, "2")
        self.combo_tipo.set("Maximizar")
        self._gerar_campos()

        # Limpar resultado
        for widget in self.scroll_resultado.winfo_children():
            widget.destroy()
        self.label_placeholder = ctk.CTkLabel(
            self.scroll_resultado,
            text="Insira um problema e clique em RESOLVER\npara ver o resultado aqui.",
            font=ctk.CTkFont(size=14),
            text_color=COR_TEXTO_DIM,
            justify="center",
        )
        self.label_placeholder.grid(row=0, column=0, pady=80)


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
