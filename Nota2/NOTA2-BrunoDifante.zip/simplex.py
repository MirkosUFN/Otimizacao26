"""
Implementação do Método Simplex para Programação Linear.

Suporta:
- Maximização e Minimização
- Restrições do tipo ≤, ≥ e =
- Método Big-M para variáveis artificiais
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Tuple
from copy import deepcopy


@dataclass
class IteracaoSimplex:
    """Representa uma iteração do método Simplex."""
    numero: int
    tableau: np.ndarray
    variaveis_base: List[str]
    nomes_colunas: List[str]
    variavel_entrada: Optional[str] = None
    variavel_saida: Optional[str] = None
    pivo: Optional[Tuple[int, int]] = None


@dataclass
class ResultadoSimplex:
    """Resultado completo da resolução pelo Simplex."""
    status: str  # "otimo", "ilimitado", "inviavel", "erro"
    valor_otimo: Optional[float] = None
    solucao: Optional[dict] = None
    iteracoes: List[IteracaoSimplex] = field(default_factory=list)
    mensagem: str = ""


class Simplex:
    """
    Resolve problemas de Programação Linear usando o Método Simplex (Big-M).

    Forma padrão:
        Max/Min  Z = c1*x1 + c2*x2 + ... + cn*xn
        Sujeito a:
            a11*x1 + a12*x2 + ... + a1n*xn  (<=, >=, =)  b1
            a21*x1 + a22*x2 + ... + a2n*xn  (<=, >=, =)  b2
            ...
            xi >= 0 para todo i
    """

    BIG_M = 1e6  # Valor grande para o método Big-M

    def __init__(self, num_variaveis: int, num_restricoes: int):
        self.num_variaveis = num_variaveis
        self.num_restricoes = num_restricoes
        self.c = np.zeros(num_variaveis)           # Coeficientes da função objetivo
        self.A = np.zeros((num_restricoes, num_variaveis))  # Matriz de coeficientes
        self.b = np.zeros(num_restricoes)           # Lado direito (RHS)
        self.sinais = ['<=' for _ in range(num_restricoes)]  # Sinais das restrições
        self.tipo = 'max'                            # 'max' ou 'min'

    def definir_objetivo(self, coeficientes: List[float], tipo: str = 'max'):
        """Define a função objetivo."""
        self.c = np.array(coeficientes, dtype=float)
        self.tipo = tipo.lower()

    def definir_restricao(self, indice: int, coeficientes: List[float],
                          sinal: str, rhs: float):
        """Define uma restrição individual."""
        self.A[indice] = np.array(coeficientes, dtype=float)
        self.sinais[indice] = sinal
        self.b[indice] = rhs

    def resolver(self) -> ResultadoSimplex:
        """Resolve o problema de PL pelo método Simplex."""
        try:
            return self._resolver_bigm()
        except Exception as e:
            return ResultadoSimplex(
                status="erro",
                mensagem=f"Erro durante a resolução: {str(e)}"
            )

    def _resolver_bigm(self) -> ResultadoSimplex:
        """Implementação do Simplex com método Big-M."""
        n = self.num_variaveis
        m = self.num_restricoes

        # Garantir que b >= 0 (multiplicar por -1 se necessário)
        A = self.A.copy()
        b = self.b.copy()
        sinais = list(self.sinais)

        for i in range(m):
            if b[i] < 0:
                A[i] *= -1
                b[i] *= -1
                if sinais[i] == '<=':
                    sinais[i] = '>='
                elif sinais[i] == '>=':
                    sinais[i] = '<='

        # Contar variáveis adicionais
        num_folga = 0
        num_artificial = 0
        info_restricao = []  # (tipo_extra, idx_folga, idx_artificial)

        for i in range(m):
            if sinais[i] == '<=':
                info_restricao.append(('folga', num_folga, None))
                num_folga += 1
            elif sinais[i] == '>=':
                info_restricao.append(('excesso_artificial', num_folga, num_artificial))
                num_folga += 1
                num_artificial += 1
            else:  # '='
                info_restricao.append(('artificial', None, num_artificial))
                num_artificial += 1

        # Dimensões do tableau
        total_vars = n + num_folga + num_artificial
        # Tableau: [A | I_folga | I_artificial | b]
        #          [c | 0       | -M          | 0]

        tableau = np.zeros((m + 1, total_vars + 1))

        # Nomes das variáveis
        nomes = []
        for j in range(n):
            nomes.append(f"x{j + 1}")
        idx_folga = 0
        idx_art = 0
        for j in range(m):
            if sinais[j] == '<=':
                nomes.append(f"f{idx_folga + 1}")
                idx_folga += 1
            elif sinais[j] == '>=':
                nomes.append(f"e{idx_folga + 1}")
                idx_folga += 1
            else:
                pass  # sem folga para =
        # Contar novamente para artificial separado
        # Na verdade, vamos reorganizar os nomes
        nomes = [f"x{j + 1}" for j in range(n)]

        col_folga_inicio = n
        col_art_inicio = n + num_folga

        # Nomes de folga/excesso
        for j in range(num_folga):
            nomes.append(f"f{j + 1}")
        for j in range(num_artificial):
            nomes.append(f"a{j + 1}")

        nomes_colunas = nomes + ["RHS"]

        # Preencher o tableau
        # Parte A
        tableau[:m, :n] = A

        # Variáveis de folga/excesso e artificiais
        idx_f = 0
        idx_a = 0
        variaveis_base = []

        for i in range(m):
            if sinais[i] == '<=':
                col = col_folga_inicio + idx_f
                tableau[i, col] = 1.0
                variaveis_base.append(nomes[col])
                idx_f += 1
            elif sinais[i] == '>=':
                col_exc = col_folga_inicio + idx_f
                tableau[i, col_exc] = -1.0
                idx_f += 1
                col_a = col_art_inicio + idx_a
                tableau[i, col_a] = 1.0
                variaveis_base.append(nomes[col_a])
                idx_a += 1
            else:  # '='
                col_a = col_art_inicio + idx_a
                tableau[i, col_a] = 1.0
                variaveis_base.append(nomes[col_a])
                idx_a += 1

        # RHS
        tableau[:m, -1] = b

        # Linha da função objetivo (última linha)
        c_obj = self.c.copy()
        if self.tipo == 'min':
            c_obj = -c_obj  # Converter min para max

        # Z - c1*x1 - c2*x2 - ... = 0  =>  linha Z tem -c
        tableau[m, :n] = -c_obj

        # Penalidade Big-M para variáveis artificiais
        for j in range(num_artificial):
            col_a = col_art_inicio + j
            tableau[m, col_a] = self.BIG_M

        # Ajustar a linha Z para eliminar artificiais da base
        for i in range(m):
            if variaveis_base[i].startswith('a'):
                tableau[m] -= self.BIG_M * tableau[i]

        # Guardar iterações
        iteracoes = []
        max_iter = 100

        for it in range(max_iter):
            # Salvar iteração atual
            iter_info = IteracaoSimplex(
                numero=it,
                tableau=tableau.copy(),
                variaveis_base=list(variaveis_base),
                nomes_colunas=list(nomes_colunas),
            )

            # Verificar otimalidade: todos os coeficientes da linha Z >= 0
            linha_z = tableau[m, :-1]

            if np.all(linha_z >= -1e-10):
                iteracoes.append(iter_info)
                break

            # Escolher variável de entrada (menor coeficiente negativo - regra de Bland)
            col_entrada = np.argmin(linha_z)
            iter_info.variavel_entrada = nomes[col_entrada]

            # Teste da razão mínima
            razoes = []
            for i in range(m):
                if tableau[i, col_entrada] > 1e-10:
                    razoes.append(tableau[i, -1] / tableau[i, col_entrada])
                else:
                    razoes.append(np.inf)

            if all(r == np.inf for r in razoes):
                iter_info.variavel_saida = "—"
                iteracoes.append(iter_info)
                return ResultadoSimplex(
                    status="ilimitado",
                    iteracoes=iteracoes,
                    mensagem="O problema é ilimitado (sem solução finita)."
                )

            linha_saida = int(np.argmin(razoes))
            iter_info.variavel_saida = variaveis_base[linha_saida]
            iter_info.pivo = (linha_saida, col_entrada)
            iteracoes.append(iter_info)

            # Pivoteamento
            pivo = tableau[linha_saida, col_entrada]
            tableau[linha_saida] /= pivo

            for i in range(m + 1):
                if i != linha_saida:
                    fator = tableau[i, col_entrada]
                    tableau[i] -= fator * tableau[linha_saida]

            variaveis_base[linha_saida] = nomes[col_entrada]
        else:
            return ResultadoSimplex(
                status="erro",
                iteracoes=iteracoes,
                mensagem="Número máximo de iterações atingido."
            )

        # Salvar iteração final
        iter_final = IteracaoSimplex(
            numero=len(iteracoes),
            tableau=tableau.copy(),
            variaveis_base=list(variaveis_base),
            nomes_colunas=list(nomes_colunas),
        )
        iteracoes.append(iter_final)

        # Verificar inviabilidade (variáveis artificiais na base com valor > 0)
        for i in range(m):
            if variaveis_base[i].startswith('a') and tableau[i, -1] > 1e-8:
                return ResultadoSimplex(
                    status="inviavel",
                    iteracoes=iteracoes,
                    mensagem="O problema é inviável (sem solução factível)."
                )

        # Extrair solução
        solucao = {}
        for j in range(n):
            nome = f"x{j + 1}"
            if nome in variaveis_base:
                idx_base = variaveis_base.index(nome)
                solucao[nome] = round(tableau[idx_base, -1], 6)
            else:
                solucao[nome] = 0.0

        valor_otimo = round(tableau[m, -1], 6)
        if self.tipo == 'min':
            valor_otimo = -valor_otimo

        return ResultadoSimplex(
            status="otimo",
            valor_otimo=valor_otimo,
            solucao=solucao,
            iteracoes=iteracoes,
            mensagem="Solução ótima encontrada!"
        )
