# Simplex method solver

To run the project:

```bash
npm install
npm run dev
```