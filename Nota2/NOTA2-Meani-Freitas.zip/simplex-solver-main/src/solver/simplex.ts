export type OptimizationType = 'maximize' | 'minimize';
export type ConstraintType = '<=' | '>=' | '=';

export interface Constraint {
  coefficients: number[];
  type: ConstraintType;
  rhs: number;
}

export interface LPProblem {
  optimizationType: OptimizationType;
  objectiveCoefficients: number[];
  constraints: Constraint[];
  numVariables: number;
}

export interface SimplexIteration {
  tableau: number[][];
  basicVariables: number[];
  pivotRow?: number;
  pivotCol?: number;
  description: string;
}

export interface SimplexResult {
  feasible: boolean;
  bounded: boolean;
  optimalValue: number;
  solution: number[];
  iterations: SimplexIteration[];
  message: string;
}

function cloneTableau(tableau: number[][]): number[][] {
  return tableau.map((row) => [...row]);
}

export function solveSimplex(problem: LPProblem): SimplexResult {
  const { optimizationType, objectiveCoefficients, constraints, numVariables } =
    problem;
  const iterations: SimplexIteration[] = [];

  const A: number[][] = [];
  const b: number[] = [];

  for (const c of constraints) {
    if (c.type === '<=') {
      A.push([...c.coefficients]);
      b.push(c.rhs);
    } else if (c.type === '>=') {
      // * -1 para converter em <=
      A.push(c.coefficients.map((v) => -v));
      b.push(-c.rhs);
    } else if (c.type === '=') {
      // divide em <= e >=
      A.push([...c.coefficients]);
      b.push(c.rhs);
      A.push(c.coefficients.map((v) => -v));
      b.push(-c.rhs);
    }
  }

  const numRestricoes = A.length;
  const numVariaveis = numVariables;

  const c = [...objectiveCoefficients];
  if (optimizationType === 'minimize') {
    for (let j = 0; j < numVariaveis; j++) {
      c[j] = -c[j];
    }
  }

  // usando como base o algoritmo do simplex da aula de 25/05
  // formato do tableau:
  // [ A | I | b ]
  // [-c | 0 | 0 ]
  const numRows = numRestricoes + 1;
  const numCols = numVariaveis + numRestricoes + 1;
  const tableau: number[][] = Array.from({ length: numRows }, () =>
    new Array(numCols).fill(0)
  );

  // Preencher a matriz A e vetor b
  for (let i = 0; i < numRestricoes; i++) {
    for (let j = 0; j < numVariaveis; j++) {
      tableau[i][j] = A[i][j];
    }
    tableau[i][numCols - 1] = b[i];
  }

  // Preencher a matriz identidade (representando as variáveis de folga)
  for (let i = 0; i < numRestricoes; i++) {
    tableau[i][numVariaveis + i] = 1;
  }

  // Preencher a linha da função objetivo (invertendo o sinal para max)
  for (let j = 0; j < numVariaveis; j++) {
    tableau[numRows - 1][j] = -c[j];
  }

  const getBasicVariables = (tab: number[][]): number[] => {
    const basic: number[] = new Array(numRestricoes).fill(-1);
    for (let i = 0; i < numRestricoes; i++) {
      for (let j = 0; j < numCols - 1; j++) {
        let countOne = 0;
        let countZero = 0;
        let uniqueOneRow = -1;
        for (let row = 0; row < numRestricoes; row++) {
          const val = Math.round(tab[row][j] * 1e10) / 1e10;
          if (val === 1) {
            countOne++;
            uniqueOneRow = row;
          } else if (val === 0) {
            countZero++;
          }
        }
        if (countOne === 1 && countZero === numRestricoes - 1 && uniqueOneRow === i) {
          basic[i] = j;
          break;
        }
      }
    }
    return basic;
  };

  iterations.push({
    tableau: cloneTableau(tableau),
    basicVariables: getBasicVariables(tableau),
    description: 'Initial tableau',
  });

  let iteracao = 1;
  const MAX_ITERATIONS = 200;

  try {
    while (true) {
      if (iteracao > MAX_ITERATIONS) {
        return {
          feasible: false,
          bounded: true,
          optimalValue: 0,
          solution: [],
          iterations,
          message: 'Maximum iterations reached. The problem may be degenerate or infeasible.',
        };
      }

      // 2. Condição de parada: Se todos os valores na última linha (exceto o resultado) forem >= 0, é ótimo.
      let isOptimal = true;
      for (let j = 0; j < numCols - 1; j++) {
        if (Math.round(tableau[numRows - 1][j] * 1e10) / 1e10 < 0) {
          isOptimal = false;
          break;
        }
      }

      if (isOptimal) {
        break;
      }

      // 3. Escolher a Coluna Pivô (variável que entra na base: o mais negativo da última linha)
      let colunaPivo = -1;
      let minVal = 0;
      for (let j = 0; j < numCols - 1; j++) {
        const val = tableau[numRows - 1][j];
        if (val < minVal) {
          minVal = val;
          colunaPivo = j;
        }
      }

      // 4. Escolher a Linha Pivô (variável que sai da base: teste da razão mínima)
      const razoes: number[] = [];
      for (let i = 0; i < numRestricoes; i++) {
        if (tableau[i][colunaPivo] > 0) {
          razoes.push(tableau[i][numCols - 1] / tableau[i][colunaPivo]);
        } else {
          razoes.push(Infinity);
        }
      }

      let linhaPivo = -1;
      let minRatio = Infinity;
      for (let i = 0; i < razoes.length; i++) {
        if (razoes[i] < minRatio) {
          minRatio = razoes[i];
          linhaPivo = i;
        }
      }

      // Se todas as razões forem infinitas, o problema é ilimitado
      if (linhaPivo === -1 || razoes[linhaPivo] === Infinity) {
        return {
          feasible: true,
          bounded: false,
          optimalValue: optimizationType === 'maximize' ? Infinity : -Infinity,
          solution: [],
          iterations,
          message: 'The problem is unbounded. The feasible region is not bounded.',
        };
      }

      // 5. Operações de pivoteamento de Gauss-Jordan
      const elementoPivo = tableau[linhaPivo][colunaPivo];

      // Divide a linha pivô pelo elemento pivô para que ele se torne 1
      for (let j = 0; j < numCols; j++) {
        tableau[linhaPivo][j] /= elementoPivo;
      }

      // Zera os outros elementos na coluna pivô
      for (let i = 0; i < numRows; i++) {
        if (i !== linhaPivo) {
          const fator = tableau[i][colunaPivo];
          for (let j = 0; j < numCols; j++) {
            tableau[i][j] -= fator * tableau[linhaPivo][j];
          }
        }
      }

      iterations.push({
        tableau: cloneTableau(tableau),
        basicVariables: getBasicVariables(tableau),
        pivotRow: linhaPivo,
        pivotCol: colunaPivo,
        description: `Iteration ${iteracao}: Pivot at R${linhaPivo + 1}, C${colunaPivo + 1}`,
      });

      iteracao++;
    }

    // 6. Extrair a solução do Tableau final
    const solucao = new Array(numVariaveis).fill(0);
    for (let j = 0; j < numVariaveis; j++) {
      let countOne = 0;
      let countZero = 0;
      let uniqueOneRow = -1;
      for (let row = 0; row < numRestricoes; row++) {
        const val = Math.round(tableau[row][j] * 1e10) / 1e10;
        if (val === 1) {
          countOne++;
          uniqueOneRow = row;
        } else if (val === 0) {
          countZero++;
        }
      }
      if (countOne === 1 && countZero === numRestricoes - 1) {
        solucao[j] = tableau[uniqueOneRow][numCols - 1];
      }
    }

    let valorOtimo = tableau[numRows - 1][numCols - 1];
    if (optimizationType === 'minimize') {
      valorOtimo = -valorOtimo;
    }

    return {
      feasible: true,
      bounded: true,
      optimalValue: Math.round(valorOtimo * 1e8) / 1e8,
      solution: solucao.map((v) => Math.round(v * 1e8) / 1e8),
      iterations,
      message: `Optimal solution found in ${iteracao - 1} iteration(s).`,
    };
  } catch (error: any) {
    return {
      feasible: false,
      bounded: true,
      optimalValue: 0,
      solution: [],
      iterations,
      message: error?.message || 'Error occurred while solving.',
    };
  }
}

export function getVariableName(
  index: number,
  numOriginal: number,
  numExtra: number
): string {
  if (index < numOriginal) return `x${index + 1}`;
  return `s${index - numOriginal + 1}`;
}
