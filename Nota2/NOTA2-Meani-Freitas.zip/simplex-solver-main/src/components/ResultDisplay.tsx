import { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from '@/components/ui/table';
import {
  Collapsible,
  CollapsibleTrigger,
  CollapsibleContent,
} from '@/components/ui/collapsible';
import type { SimplexResult, OptimizationType } from '@/solver/simplex';
import { getVariableName } from '@/solver/simplex';

interface ResultDisplayProps {
  result: SimplexResult;
  numVariables: number;
  optimizationType: OptimizationType;
}

function formatNumber(n: number): string {
  if (Math.abs(n) < 1e-10) return '0';
  const rounded = Math.round(n * 10000) / 10000;
  if (Number.isInteger(rounded)) return rounded.toString();
  return rounded.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');
}

export default function ResultDisplay({
  result,
  numVariables,
  optimizationType,
}: ResultDisplayProps) {
  const [showIterations, setShowIterations] = useState(false);

  const statusIcon = result.feasible ? (
    result.bounded ? (
      <CheckCircle2 className="h-5 w-5 text-emerald-500" />
    ) : (
      <AlertTriangle className="h-5 w-5 text-amber-500" />
    )
  ) : (
    <XCircle className="h-5 w-5 text-red-500" />
  );

  const statusText = result.feasible
    ? result.bounded
      ? 'Optimal solution found'
      : 'Unbounded problem'
    : 'Infeasible problem';

  const statusVariant = result.feasible && result.bounded ? 'outline' : 'destructive';

  return (
    <Card id="results">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {statusIcon}
            <div>
              <CardTitle className="text-lg">{statusText}</CardTitle>
              <CardDescription>{result.message}</CardDescription>
            </div>
          </div>
          <Badge variant={statusVariant as 'outline' | 'destructive'}>
            {result.iterations.length} step
            {result.iterations.length !== 1 ? 's' : ''}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {result.feasible && result.bounded && (
          <>
            <div className="rounded-lg border bg-muted/30 p-5">
              <div className="flex items-center gap-2 mb-1">
                {optimizationType === 'maximize' ? (
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-muted-foreground" />
                )}
                <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  {optimizationType === 'maximize' ? 'Maximum' : 'Minimum'}{' '}
                  Value (Z)
                </span>
              </div>
              <p className="text-3xl font-bold font-mono tracking-tight">
                {result.optimalValue}
              </p>
            </div>

            <Separator />

            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-3">
                Decision variables
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {result.solution.map((val, i) => (
                  <div
                    key={i}
                    className="rounded-lg border px-4 py-3 text-center transition-colors hover:bg-muted/50"
                  >
                    <div className="text-sm font-medium text-muted-foreground font-mono">
                      x<sub>{i + 1}</sub>
                    </div>
                    <div className="text-xl font-semibold font-mono mt-0.5">
                      {val}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {result.iterations.length > 0 && (
          <>
            <Separator />
            <Collapsible open={showIterations} onOpenChange={setShowIterations}>
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  className="w-full justify-between"
                  id="toggle-iterations"
                >
                  <span className="text-sm font-medium">
                    Tableaux
                  </span>
                  {showIterations ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </Button>
              </CollapsibleTrigger>

              <CollapsibleContent className="space-y-4 mt-4">
                {result.iterations.map((iteration, idx) => {
                  const tableau = iteration.tableau;
                  const numRows = tableau.length;
                  const numCols = tableau[0].length;
                  const totalVarCols = numCols - 1;
                  const numExtraVars = totalVarCols - numVariables;

                  const headers: string[] = [];
                  for (let j = 0; j < totalVarCols; j++) {
                    headers.push(
                      getVariableName(j, numVariables, numExtraVars)
                    );
                  }
                  headers.push('RHS');

                  return (
                    <div
                      key={idx}
                      className="rounded-lg border overflow-hidden"
                    >
                      <div className="px-4 py-2.5 bg-muted/30 border-b">
                        <span className="text-xs font-medium font-mono text-muted-foreground">
                          {iteration.description}
                        </span>
                      </div>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-center w-16">
                              Basis
                            </TableHead>
                            {headers.map((h, j) => (
                              <TableHead key={j} className="text-center font-mono">
                                {h}
                              </TableHead>
                            ))}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {tableau.map((row, i) => {
                            const isObjRow = i === numRows - 1;
                            return (
                              <TableRow
                                key={i}
                                className={
                                  isObjRow ? 'border-t-2 font-semibold' : ''
                                }
                              >
                                <TableCell className="text-center font-mono text-muted-foreground font-medium">
                                  {isObjRow
                                    ? 'Z'
                                    : getVariableName(
                                        iteration.basicVariables[i],
                                        numVariables,
                                        numExtraVars
                                      )}
                                </TableCell>
                                {row.map((val, j) => {
                                  const isPivot =
                                    iteration.pivotRow === i &&
                                    iteration.pivotCol === j;
                                  return (
                                    <TableCell
                                      key={j}
                                      className={`text-center font-mono ${
                                        isPivot
                                          ? 'bg-primary/10 font-bold text-foreground'
                                          : ''
                                      }`}
                                    >
                                      {formatNumber(val)}
                                    </TableCell>
                                  );
                                })}
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  );
                })}
              </CollapsibleContent>
            </Collapsible>
          </>
        )}
      </CardContent>
    </Card>
  );
}
