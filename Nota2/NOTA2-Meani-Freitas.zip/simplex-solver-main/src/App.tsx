import { useState, useCallback } from 'react';
import {
  Settings2,
  Target,
  ListChecks,
  Plus,
  Play,
  FileText,
  RotateCcw,
  X,
} from 'lucide-react';
import {
  solveSimplex,
  type LPProblem,
  type OptimizationType,
  type ConstraintType,
  type SimplexResult,
} from '@/solver/simplex';
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import ResultDisplay from '@/components/ResultDisplay';

interface ConstraintInput {
  id: number;
  coefficients: string[];
  type: ConstraintType;
  rhs: string;
}

let constraintIdCounter = 2;

export default function App() {
  const [numVars, setNumVars] = useState(2);
  const [optimizationType, setOptimizationType] =
    useState<OptimizationType>('maximize');
  const [objectiveCoeffs, setObjectiveCoeffs] = useState<string[]>(['', '']);
  const [constraints, setConstraints] = useState<ConstraintInput[]>([
    { id: 0, coefficients: ['', ''], type: '<=', rhs: '' },
    { id: 1, coefficients: ['', ''], type: '<=', rhs: '' },
  ]);
  const [result, setResult] = useState<SimplexResult | null>(null);
  const [error, setError] = useState('');

  const handleNumVarsChange = useCallback((newNum: number) => {
    if (newNum < 1 || newNum > 20) return;
    setNumVars(newNum);
    setObjectiveCoeffs((prev) => {
      const updated = [...prev];
      while (updated.length < newNum) updated.push('');
      return updated.slice(0, newNum);
    });
    setConstraints((prev) =>
      prev.map((c) => {
        const coeffs = [...c.coefficients];
        while (coeffs.length < newNum) coeffs.push('');
        return { ...c, coefficients: coeffs.slice(0, newNum) };
      })
    );
  }, []);

  const addConstraint = useCallback(() => {
    setConstraints((prev) => [
      ...prev,
      {
        id: constraintIdCounter++,
        coefficients: new Array(numVars).fill(''),
        type: '<=' as ConstraintType,
        rhs: '',
      },
    ]);
  }, [numVars]);

  const removeConstraint = useCallback((id: number) => {
    setConstraints((prev) => (prev.length <= 1 ? prev : prev.filter((c) => c.id !== id)));
  }, []);

  const updateObjCoeff = useCallback((index: number, value: string) => {
    setObjectiveCoeffs((prev) => {
      const updated = [...prev];
      updated[index] = value;
      return updated;
    });
  }, []);

  const updateConstraint = useCallback(
    (id: number, field: 'coefficients' | 'type' | 'rhs', value: string, coeffIndex?: number) => {
      setConstraints((prev) =>
        prev.map((c) => {
          if (c.id !== id) return c;
          if (field === 'coefficients' && coeffIndex !== undefined) {
            const coeffs = [...c.coefficients];
            coeffs[coeffIndex] = value;
            return { ...c, coefficients: coeffs };
          }
          if (field === 'type') return { ...c, type: value as ConstraintType };
          if (field === 'rhs') return { ...c, rhs: value };
          return c;
        })
      );
    },
    []
  );

  const loadExample = useCallback(() => {
    setNumVars(2);
    setOptimizationType('maximize');
    setObjectiveCoeffs(['5', '4']);
    setConstraints([
      { id: constraintIdCounter++, coefficients: ['6', '4'], type: '<=', rhs: '24' },
      { id: constraintIdCounter++, coefficients: ['1', '2'], type: '<=', rhs: '6' },
    ]);
    setResult(null);
    setError('');
  }, []);

  const clearAll = useCallback(() => {
    setObjectiveCoeffs(new Array(numVars).fill(''));
    setConstraints([
      {
        id: constraintIdCounter++,
        coefficients: new Array(numVars).fill(''),
        type: '<=',
        rhs: '',
      },
    ]);
    setResult(null);
    setError('');
  }, [numVars]);

  const handleSolve = useCallback(() => {
    setError('');
    setResult(null);

    const objCoeffs = objectiveCoeffs.map((v) => {
      const n = parseFloat(v);
      return isNaN(n) ? null : n;
    });

    if (objCoeffs.some((v) => v === null)) {
      setError('Input all objective function coefficients with valid numbers.');
      return;
    }

    for (let i = 0; i < constraints.length; i++) {
      const c = constraints[i];
      for (let j = 0; j < numVars; j++) {
        if (c.coefficients[j] === '' || isNaN(parseFloat(c.coefficients[j]))) {
          setError(`Constraint ${i + 1}: input all coefficients.`);
          return;
        }
      }
      if (c.rhs === '' || isNaN(parseFloat(c.rhs))) {
        setError(`Constraint ${i + 1}: enter a valid RHS value.`);
        return;
      }
    }

    const problem: LPProblem = {
      optimizationType,
      objectiveCoefficients: objCoeffs as number[],
      constraints: constraints.map((c) => ({
        coefficients: c.coefficients.map((v) => parseFloat(v)),
        type: c.type,
        rhs: parseFloat(c.rhs),
      })),
      numVariables: numVars,
    };

    try {
      setResult(solveSimplex(problem));
    } catch {
      setError('An error occurred while solving. Check your inputs.');
    }
  }, [objectiveCoeffs, constraints, numVars, optimizationType]);

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8 space-y-6">
        <header className="text-center space-y-2 pb-2">
          <h1 className="text-3xl font-bold tracking-tight">Simplex method</h1>
        </header>

        <Card>
          <CardHeader className="pb-4">
            <div className="flex items-center gap-2">
              <Settings2 className="h-4 w-4 text-muted-foreground" />
              <CardTitle className="text-base">Problem setup</CardTitle>
            </div>
            <CardDescription>
              Configure the number of decision variables and optimization type.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="space-y-2">
                <Label htmlFor="num-vars">Variables</Label>
                <Input
                  id="num-vars"
                  type="number"
                  className="w-24 font-mono"
                  value={numVars}
                  min={1}
                  max={20}
                  onChange={(e) => handleNumVarsChange(parseInt(e.target.value) || 1)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="opt-type">Optimization</Label>
                <Select
                  value={optimizationType}
                  onValueChange={(v) => setOptimizationType(v as OptimizationType)}
                >
                  <SelectTrigger id="opt-type" className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="maximize">Maximize</SelectItem>
                    <SelectItem value="minimize">Minimize</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-4">
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-muted-foreground" />
              <CardTitle className="text-base">Objective function</CardTitle>
            </div>
            <CardDescription>
              {optimizationType === 'maximize' ? 'Maximize' : 'Minimize'} Z
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-medium text-muted-foreground shrink-0">
                Z =
              </span>
              {objectiveCoeffs.map((coeff, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  {i > 0 && (
                    <span className="text-muted-foreground text-sm">+</span>
                  )}
                  <Input
                    id={`obj-coeff-${i}`}
                    type="number"
                    className="w-20 font-mono text-center"
                    value={coeff}
                    onChange={(e) => updateObjCoeff(i, e.target.value)}
                  />
                  <span className="text-sm text-muted-foreground font-mono">
                    x<sub>{i + 1}</sub>
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ListChecks className="h-4 w-4 text-muted-foreground" />
                <CardTitle className="text-base">Constraints</CardTitle>
              </div>
              <span className="text-xs text-muted-foreground">
                {constraints.length} constraint{constraints.length !== 1 ? 's' : ''}
              </span>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {constraints.map((constraint, idx) => (
              <div
                key={constraint.id}
                className="flex items-center gap-2 flex-wrap rounded-lg border p-3 transition-colors hover:bg-muted/30"
              >
                <span className="text-xs font-mono text-muted-foreground w-6 shrink-0">
                  {idx + 1}.
                </span>

                {constraint.coefficients.map((coeff, j) => (
                  <div key={j} className="flex items-center gap-1.5">
                    {j > 0 && (
                      <span className="text-muted-foreground text-sm">+</span>
                    )}
                    <Input
                      id={`c-${constraint.id}-${j}`}
                      type="number"
                      className="w-20 font-mono text-center"
                      value={coeff}
                      onChange={(e) =>
                        updateConstraint(constraint.id, 'coefficients', e.target.value, j)
                      }
                    />
                    <span className="text-sm text-muted-foreground font-mono">
                      x<sub>{j + 1}</sub>
                    </span>
                  </div>
                ))}

                <Select
                  value={constraint.type}
                  onValueChange={(v) => updateConstraint(constraint.id, 'type', v)}
                >
                  <SelectTrigger
                    id={`c-${constraint.id}-type`}
                    className="w-16 font-mono text-center"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="<=">≤</SelectItem>
                    <SelectItem value=">=">≥</SelectItem>
                    <SelectItem value="=">=</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  id={`c-${constraint.id}-rhs`}
                  type="number"
                  className="w-20 font-mono text-center"
                  value={constraint.rhs}
                  onChange={(e) =>
                    updateConstraint(constraint.id, 'rhs', e.target.value)
                  }
                />

                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-destructive shrink-0"
                  onClick={() => removeConstraint(constraint.id)}
                  aria-label={`Remove constraint ${idx + 1}`}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}

            <Separator />

            <div className="flex items-center justify-between flex-wrap gap-2">
              <Button variant="outline" size="sm" onClick={addConstraint}>
                <Plus className="h-3.5 w-3.5 mr-1.5" />
                Add constraint
              </Button>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" onClick={loadExample}>
                  <FileText className="h-3.5 w-3.5 mr-1.5" />
                  Load example
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearAll}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
                  Clear
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Button
          className="w-full h-11"
          size="lg"
          onClick={handleSolve}
          id="solve-button"
        >
          <Play className="h-4 w-4 mr-2" />
          Solve
        </Button>

        {error && (
          <p className="text-sm text-destructive text-center">{error}</p>
        )}

        {result && (
          <ResultDisplay
            result={result}
            numVariables={numVars}
            optimizationType={optimizationType}
          />
        )}
      </div>
    </div>
  );
}
