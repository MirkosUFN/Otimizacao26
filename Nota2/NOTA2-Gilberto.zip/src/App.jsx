import { useState } from 'react';
import { simplex, parseNumbers } from './simplex';
import './index.css';

const EXAMPLES = [
  {
    label: 'Exemplo Clássico',
    c: '5 4',
    rows: [
      { a: '6 4', b: '24' },
      { a: '1 2', b: '6' },
    ],
    objective: 'max',
  },
  {
    label: 'Produção 3 vars',
    c: '3 5 2',
    rows: [
      { a: '1 0 1', b: '4' },
      { a: '0 2 1', b: '6' },
      { a: '3 2 0', b: '12' },
    ],
    objective: 'max',
  },
  {
    label: 'Dieta 4 vars',
    c: '10 6 4 3',
    rows: [
      { a: '1 1 1 1', b: '10' },
      { a: '2 1 0 1', b: '14' },
      { a: '0 1 2 1', b: '12' },
    ],
    objective: 'max',
  },
];

function TableauDisplay({ history }) {
  const [activeIdx, setActiveIdx] = useState(history.length - 1);

  if (!history || history.length === 0) return null;

  const snap = history[activeIdx];
  const numRows = snap.data.length;
  const numCols = snap.data[0].length;
  const headers = [...snap.varLabels, 'b'];

  return (
    <div className="tableau-section">
      <div className="card-title">Tableau Simplex</div>

      <div className="tableau-tabs">
        {history.map((h, i) => (
          <button
            key={i}
            className={`tableau-tab${i === activeIdx ? ' active' : ''}`}
            onClick={() => setActiveIdx(i)}
          >
            {h.label}
          </button>
        ))}
      </div>

      <div className="tableau-wrapper">
        <table className="tableau-table">
          <thead>
            <tr>
              <th style={{ width: 80 }}>Linha</th>
              {headers.map((h, j) => (
                <th key={j} className={j === numCols - 2 ? 'rhs' : ''}>
                  {j === numCols - 1 ? 'b' : h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {snap.data.map((row, i) => {
              const isObjRow = i === numRows - 1;
              return (
                <tr key={i}>
                  <td style={{ color: 'var(--text-muted)', fontSize: '0.72rem' }}>
                    {isObjRow ? 'Z' : `R${i + 1}`}
                  </td>
                  {row.map((val, j) => (
                    <td
                      key={j}
                      className={j === numCols - 1 ? 'rhs' : ''}
                      style={isObjRow ? { color: 'var(--accent-light)', fontWeight: 600 } : {}}
                    >
                      {Math.abs(val) < 1e-9 ? '0' : parseFloat(val.toFixed(4))}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ResultsPanel({ result }) {
  if (!result) return null;

  if (result.status === 'unbounded') {
    return (
      <div className="results-section">
        <div className="error-banner">
          <span>⚠️</span>
          <span>{result.message}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="results-section">
      <div className="result-optimal-value">
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
          <span className="status-chip optimal">
            <span className="dot" />
            Solução Ótima
          </span>
        </div>
        <div className="result-label">Valor Ótimo Z*</div>
        <div className="result-z">{parseFloat(result.optimalValue.toFixed(6))}</div>
        <div className="result-iterations">
          Resolvido em
          <span>{result.iterations} {result.iterations === 1 ? 'iteração' : 'iterações'}</span>
        </div>
      </div>

      <div className="card-title">Variáveis de Decisão</div>
      <div className="variables-grid">
        {result.solution.map((val, i) => (
          <div key={i} className="var-card">
            <div className="var-name">x<sub>{i + 1}</sub></div>
            <div className="var-value">{parseFloat(val.toFixed(6))}</div>
          </div>
        ))}
      </div>

      <TableauDisplay history={result.tableauHistory} />
    </div>
  );
}

export default function App() {
  const [objective, setObjective] = useState('max');
  const [cStr, setCStr] = useState('');
  const [rows, setRows] = useState([
    { a: '', b: '' },
    { a: '', b: '' },
  ]);
  const [result, setResult] = useState(null);
  const [errors, setErrors] = useState({});
  const [globalError, setGlobalError] = useState('');
  const [loading, setLoading] = useState(false);

  const addRow = () => setRows((r) => [...r, { a: '', b: '' }]);
  const removeRow = (i) =>
    setRows((r) => r.length > 1 ? r.filter((_, idx) => idx !== i) : r);

  const updateRow = (i, field, val) =>
    setRows((r) => r.map((row, idx) => (idx === i ? { ...row, [field]: val } : row)));

  const loadExample = (ex) => {
    setObjective(ex.objective);
    setCStr(ex.c);
    setRows(ex.rows.map((r) => ({ a: r.a, b: r.b })));
    setResult(null);
    setErrors({});
    setGlobalError('');
  };

  const solve = () => {
    const newErrors = {};
    setGlobalError('');

    let c;
    try {
      c = parseNumbers(cStr);
      if (c.length === 0) throw new Error('Vazio');
    } catch {
      newErrors.c = true;
      setErrors(newErrors);
      setGlobalError('Insira os coeficientes da função objetivo.');
      return;
    }

    const n = c.length;
    let A = [], b = [];
    for (let i = 0; i < rows.length; i++) {
      try {
        const ai = parseNumbers(rows[i].a);
        if (ai.length !== n) throw new Error(`Restrição ${i + 1} deve ter ${n} coeficiente(s), mas tem ${ai.length}.`);
        A.push(ai);
      } catch (e) {
        newErrors[`a${i}`] = true;
        setErrors(newErrors);
        setGlobalError(e.message.startsWith('Restrição') ? e.message : `Restrição ${i + 1}: coeficientes inválidos.`);
        return;
      }
      try {
        const bi = parseNumbers(rows[i].b);
        if (bi.length !== 1) throw new Error();
        b.push(bi[0]);
      } catch {
        newErrors[`b${i}`] = true;
        setErrors(newErrors);
        setGlobalError(`Restrição ${i + 1}: valor b inválido.`);
        return;
      }
    }

    const cFinal = objective === 'min' ? c.map((v) => -v) : c;

    setErrors({});
    setLoading(true);
    setResult(null);

    setTimeout(() => {
      try {
        const res = simplex(cFinal, A, b);
        if (res.status === 'optimal' && objective === 'min') {
          res.optimalValue = -res.optimalValue;
        }
        setResult(res);
      } catch (e) {
        setGlobalError(e.message || 'Erro desconhecido.');
      } finally {
        setLoading(false);
      }
    }, 120);
  };

  return (
    <div className="app-wrapper">
      <div className="main-content">
        <header className="app-header">
          <div className="header-badge">
            <span>🔢</span> Otimização Computacional <span>·</span> Método Simplex
          </div>
          <h1>UI SIMPLEX</h1>
          <p>
            Insira sua função objetivo e restrições.
          </p>
        </header>

        <div className="examples-bar">
          <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', alignSelf: 'center', marginRight: 4 }}>
            Exemplos:
          </span>
          {EXAMPLES.map((ex) => (
            <button key={ex.label} className="example-chip" onClick={() => loadExample(ex)}>
              {ex.label}
            </button>
          ))}
        </div>

        <div className="card">
          <div className="card-title">Tipo de Objetivo</div>
          <div className="toggle-group">
            <button
              className={`toggle-btn${objective === 'max' ? ' active' : ''}`}
              onClick={() => setObjective('max')}
            >
              Maximizar
            </button>
            <button
              className={`toggle-btn${objective === 'min' ? ' active' : ''}`}
              onClick={() => setObjective('min')}
            >
              Minimizar
            </button>
          </div>

          <div className="card-title">Função Objetivo</div>
          <div className="form-group">
            <label className="form-label">
              {objective === 'max' ? 'Maximizar' : 'Minimizar'}{' '}
              <strong>Z = c₁x₁ + c₂x₂ + …</strong>
            </label>
            <input
              id="input-c"
              className={`form-input${errors.c ? ' error' : ''}`}
              placeholder="Ex: 5 4   ou   3, 5, 2"
              value={cStr}
              onChange={(e) => { setCStr(e.target.value); setErrors((er) => ({ ...er, c: false })); setGlobalError(''); }}
            />
            <div className="form-hint">
              Insira os coeficientes separados por espaço ou vírgula
            </div>
          </div>

          <div className="card-title">Restrições <span style={{ color: 'var(--text-muted)', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>(≤)</span></div>

          {rows.map((row, i) => (
            <div key={i} className="matrix-row">
              <input
                id={`input-a-${i}`}
                className={`form-input${errors[`a${i}`] ? ' error' : ''}`}
                placeholder={`a₁ a₂ … (linha ${i + 1})`}
                value={row.a}
                onChange={(e) => { updateRow(i, 'a', e.target.value); setErrors((er) => ({ ...er, [`a${i}`]: false })); setGlobalError(''); }}
              />
              <span className="rhs-divider">≤</span>
              <input
                id={`input-b-${i}`}
                className={`form-input rhs-input${errors[`b${i}`] ? ' error' : ''}`}
                placeholder="b"
                value={row.b}
                onChange={(e) => { updateRow(i, 'b', e.target.value); setErrors((er) => ({ ...er, [`b${i}`]: false })); setGlobalError(''); }}
              />
              <button
                className="row-btn"
                onClick={() => removeRow(i)}
                title="Remover restrição"
                aria-label="Remover restrição"
              >
                ×
              </button>
            </div>
          ))}

          <div className="add-row-container">
            <button className="btn-ghost row-btn add" onClick={addRow} title="Adicionar restrição">
              +
            </button>
          </div>

          <div className="section-gap" />

          {globalError && (
            <div className="error-banner">
              <span>⚠️</span>
              <span>{globalError}</span>
            </div>
          )}

          <button
            id="btn-solve"
            className="btn-primary"
            onClick={solve}
            disabled={loading}
          >
            {loading ? (
              <>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ animation: 'spin 0.8s linear infinite' }}>
                  <circle cx="12" cy="12" r="10" strokeOpacity="0.3"/>
                  <path d="M12 2a10 10 0 0 1 10 10" />
                </svg>
                Resolvendo…
              </>
            ) : (
              <>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M5 12l5 5L20 7"/>
                </svg>
                Resolver
              </>
            )}
          </button>
        </div>

        <ResultsPanel result={result} />
      </div>

      <footer className="app-footer">
        Gilberto Morales
      </footer>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
