export function simplex(c, A, b) {
  const numConstraints = A.length;
  const numVariables = c.length;
  const totalCols = numVariables + numConstraints + 1;
  const totalRows = numConstraints + 1;

  const tableau = Array.from({ length: totalRows }, () =>
    new Array(totalCols).fill(0)
  );

  for (let i = 0; i < numConstraints; i++) {
    for (let j = 0; j < numVariables; j++) {
      tableau[i][j] = A[i][j];
    }
    tableau[i][numVariables + i] = 1;
    tableau[i][totalCols - 1] = b[i];
  }

  for (let j = 0; j < numVariables; j++) {
    tableau[numConstraints][j] = -c[j];
  }

  const varLabels = [
    ...Array.from({ length: numVariables }, (_, i) => `x${i + 1}`),
    ...Array.from({ length: numConstraints }, (_, i) => `s${i + 1}`),
  ];

  const tableauHistory = [];
  const saveSnapshot = (label) => {
    tableauHistory.push({
      label,
      data: tableau.map((row) => [...row]),
      varLabels: [...varLabels],
    });
  };

  saveSnapshot("Tableau Inicial");

  let iteration = 1;

  while (true) {
    const objRow = tableau[numConstraints];
    const allNonNegative = objRow
      .slice(0, totalCols - 1)
      .every((v) => Math.round(v * 1e10) / 1e10 >= 0);

    if (allNonNegative) break;

    let pivotCol = 0;
    let minVal = objRow[0];
    for (let j = 1; j < totalCols - 1; j++) {
      if (objRow[j] < minVal) {
        minVal = objRow[j];
        pivotCol = j;
      }
    }

    const ratios = tableau.slice(0, numConstraints).map((row) => {
      if (row[pivotCol] > 0) return row[totalCols - 1] / row[pivotCol];
      return Infinity;
    });

    const pivotRow = ratios.indexOf(Math.min(...ratios));

    if (!isFinite(ratios[pivotRow])) {
      return {
        status: "unbounded",
        message: "O problema tem solução ilimitada (região viável não é limitada).",
      };
    }

    const pivotElement = tableau[pivotRow][pivotCol];

    for (let j = 0; j < totalCols; j++) {
      tableau[pivotRow][j] /= pivotElement;
    }

    for (let i = 0; i < totalRows; i++) {
      if (i !== pivotRow) {
        const factor = tableau[i][pivotCol];
        for (let j = 0; j < totalCols; j++) {
          tableau[i][j] -= factor * tableau[pivotRow][j];
        }
      }
    }

    varLabels[numVariables + pivotRow] = varLabels[pivotCol];

    saveSnapshot(
      `Iteração ${iteration} — Pivo: col ${pivotCol + 1} (${varLabels[pivotCol]}), linha ${pivotRow + 1}`
    );

    iteration++;
  }

  const solution = new Array(numVariables).fill(0);
  for (let j = 0; j < numVariables; j++) {
    const col = tableau.slice(0, numConstraints).map((row) => row[j]);
    const roundedCol = col.map((v) => Math.round(v * 1e10) / 1e10);
    const onesCount = roundedCol.filter((v) => v === 1).length;
    const zerosCount = roundedCol.filter((v) => v === 0).length;

    if (onesCount === 1 && zerosCount === numConstraints - 1) {
      const rowIdx = roundedCol.indexOf(1);
      solution[j] = tableau[rowIdx][totalCols - 1];
    }
  }

  const optimalValue = tableau[numConstraints][totalCols - 1];

  return {
    status: "optimal",
    solution,
    optimalValue,
    iterations: iteration - 1,
    tableauHistory,
    numVariables,
    numConstraints,
  };
}

export function parseNumbers(str) {
  return str
    .trim()
    .split(/[\s,]+/)
    .filter((s) => s !== "")
    .map((s) => {
      const n = parseFloat(s);
      if (isNaN(n)) throw new Error(`Valor inválido: "${s}"`);
      return n;
    });
}
