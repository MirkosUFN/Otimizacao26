# Grafo de Rotas Aéreas entre Capitais Brasileiras ✈️

## Problema Escolhido

**Rede de Rotas Aéreas do Brasil** — modelada como um **grafo não-direcionado ponderado**, onde:

- **Vértices (Nós):** 27 capitais estaduais brasileiras (aeroportos)
- **Arestas:** 83 rotas aéreas diretas entre as capitais
- **Pesos:** Distância em quilômetros entre os aeroportos

### Aplicações da Teoria dos Grafos

1. **Menor Caminho (Dijkstra):** Encontrar a rota mais curta entre dois aeroportos, considerando escalas
2. **Conectividade:** Verificar se todos os aeroportos são acessíveis a partir de qualquer outro
3. **Grau dos Vértices:** Identificar os aeroportos mais conectados (hubs)
4. **Densidade do Grafo:** Medir quão interconectada é a rede aérea
5. **Árvore Geradora Mínima:** Determinar a rede mínima para conectar todas as capitais

## Estrutura dos Dados

### Arquivo: `dados/rotas_aereas.json`

Base de dados em formato JSON contendo:

- **27 nós** com: código IATA, cidade, estado, coordenadas geográficas e volume de passageiros/ano
- **83 arestas** com: origem, destino, distância em km e número de voos diários

Dados baseados em informações públicas da ANAC (Agência Nacional de Aviação Civil) e Infraero.

## Visualização

### Arquivo: `index.html`

Visualização interativa em HTML utilizando a biblioteca **vis.js** com as seguintes funcionalidades:

- 🗺️ **Grafo interativo** com zoom, arraste e reorganização dos nós
- 🎨 **Codificação visual** por tamanho do aeroporto (passageiros/ano)
- 🔍 **Algoritmo de Dijkstra** integrado para busca do menor caminho
- 📊 **Estatísticas do grafo** (grau médio, densidade, etc.)
- ℹ️ **Painel de informações** ao clicar em cada aeroporto
- 🌙 **Design dark mode** premium

### Como visualizar

Basta abrir o arquivo `index.html` em qualquer navegador moderno (Chrome, Firefox, Edge).

## Tecnologias Utilizadas

- **HTML5 / CSS3 / JavaScript**
- **vis.js** (biblioteca de visualização de grafos)
- **Algoritmo de Dijkstra** (menor caminho)
- **Google Fonts (Inter)**

## Categorias dos Aeroportos

| Categoria     | Passageiros/Ano | Cor no Grafo |
|---------------|-----------------|--------------|
| Grande porte  | > 10M           | 🔵 Azul     |
| Médio porte   | 3M – 10M        | 🟢 Ciano    |
| Pequeno porte | < 3M            | 🟣 Roxo     |

## Autor

- **Nome:** [Nome do Aluno]
- **Disciplina:** Estrutura de Dados / Teoria dos Grafos
- **Data:** Junho de 2026
