import json
import networkx as nx
from pyvis.network import Network

dados_logistica = """
{
    "aeroportos": [
        {"id": "GRU", "label": "Guarulhos (SP)"},
        {"id": "VCP", "label": "Viracopos (SP)"},
        {"id": "BSB", "label": "Brasília (DF)"},
        {"id": "GIG", "label": "Galeão (RJ)"},
        {"id": "CNF", "label": "Confins (MG)"},
        {"id": "MAO", "label": "Manaus (AM)"},
        {"id": "REC", "label": "Recife (PE)"}
    ],
    "rotas": [
        {"origem": "GRU", "destino": "VCP", "distancia_km": 80},
        {"origem": "GRU", "destino": "BSB", "distancia_km": 870},
        {"origem": "GRU", "destino": "GIG", "distancia_km": 340},
        {"origem": "VCP", "destino": "CNF", "distancia_km": 490},
        {"origem": "BSB", "destino": "MAO", "distancia_km": 1930},
        {"origem": "BSB", "destino": "REC", "distancia_km": 1650},
        {"origem": "GIG", "destino": "CNF", "distancia_km": 360},
        {"origem": "REC", "destino": "GRU", "distancia_km": 2100},
        {"origem": "CNF", "destino": "BSB", "distancia_km": 620},
        {"origem": "MAO", "destino": "VCP", "distancia_km": 2600}
    ]
}
"""

data = json.loads(dados_logistica)

G = nx.Graph()

for aero in data["aeroportos"]:
    G.add_node(aero["id"], label=aero["label"])

for rota in data["rotas"]:
    G.add_edge(
        rota["origem"], 
        rota["destino"], 
        label=f"{rota['distancia_km']} km"
    )

net = Network(height="750px", width="100%", notebook=False, heading="Malha Logistica de Transportes")

net.from_nx(G)

net.barnes_hut(
    gravity=-8000, 
    central_gravity=0.3, 
    spring_length=200, 
    spring_strength=0.05, 
    damping=0.95
)

nome_arquivo = "malha.html"
net.write_html(nome_arquivo)

print(f"\n[SUCESSO] O arquivo HTML '{nome_arquivo}' foi gerado!")