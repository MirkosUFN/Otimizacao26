import 'dart:math';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import '../database/app_database.dart';

class GrafoRelacionamentoPage extends StatefulWidget {
  const GrafoRelacionamentoPage({super.key});

  @override
  State<GrafoRelacionamentoPage> createState() => _GrafoRelacionamentoPageState();
}

class _GrafoRelacionamentoPageState extends State<GrafoRelacionamentoPage> {
  final AppDatabase _db = AppDatabase();
  final TransformationController _transformationController = TransformationController();
  final TextEditingController _searchController = TextEditingController();

  List<OrdemComCliente> _todasAsOrdens = [];
  Map<int, List<OrdemComCliente>> _clientGroups = {};
  List<GraphNode> _nodes = [];
  List<GraphEdge> _edges = [];
  Map<String, GraphNode> _nodesMap = {};

  bool _carregando = true;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _carregarDados();
  }

  @override
  void dispose() {
    _transformationController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _carregarDados() async {
    setState(() {
      _carregando = true;
    });
    try {
      final ordens = await _db.listarOrdensComCliente();
      if (!mounted) return;

      // Agrupa ordens por cliente
      final Map<int, List<OrdemComCliente>> groups = {};
      for (var item in ordens) {
        groups.putIfAbsent(item.cliente.id, () => []).add(item);
      }

      setState(() {
        _todasAsOrdens = ordens;
        _clientGroups = groups;
        _calcularLayout();
        _carregando = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _carregando = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao carregar dados do grafo: $e')),
      );
    }
  }

  void _calcularLayout() {
    final List<GraphNode> nodesList = [];
    final List<GraphEdge> edgesList = [];
    final Map<String, GraphNode> map = {};

    if (_clientGroups.isEmpty) {
      _nodes = [];
      _edges = [];
      _nodesMap = {};
      return;
    }

    // Configuração de Grid para os clientes
    const int cols = 3;
    const double cellSize = 380.0; // Distância entre os centros de cada cluster

    final clientsList = _clientGroups.keys.toList();

    for (int i = 0; i < clientsList.length; i++) {
      final clientId = clientsList[i];
      final clientOrders = _clientGroups[clientId] ?? [];
      final firstOrder = clientOrders.first;
      final cliente = firstOrder.cliente;

      // Coordenadas do centro do cluster (Cliente)
      final int row = i ~/ cols;
      final int col = i % cols;
      final double cx = col * cellSize + cellSize / 2;
      final double cy = row * cellSize + cellSize / 2;
      final Offset clientPos = Offset(cx, cy);

      // Criar nó do cliente
      final String clientNodeId = 'c_$clientId';
      final GraphNode clientNode = GraphNode(
        id: clientNodeId,
        label: cliente.nome,
        sublabel: cliente.cpf,
        isCustomer: true,
        position: clientPos,
        data: cliente,
      );
      nodesList.add(clientNode);
      map[clientNodeId] = clientNode;

      // Criar nós das ordens de serviço (OS) em círculo ao redor do cliente
      final int k = clientOrders.length;
      const double radius = 135.0; // Raio das conexões satélites

      for (int j = 0; j < k; j++) {
        final item = clientOrders[j];
        final String osNodeId = 'os_${item.ordem.id}';

        // Distribui uniformemente os satélites ao redor do centro do cliente
        final double angle = j * (2 * pi / k) - pi / 2; // Inicia no topo (12 horas)
        final double ox = cx + radius * cos(angle);
        final double oy = cy + radius * sin(angle);
        final Offset osPos = Offset(ox, oy);

        final String isOrcamento = item.ordem.tipoRegistro.toLowerCase().contains('orç') || 
                                  item.ordem.tipoRegistro.toLowerCase().contains('orc')
                                      ? 'OC' : 'OS';

        final GraphNode osNode = GraphNode(
          id: osNodeId,
          label: '$isOrcamento #${item.ordem.id}',
          sublabel: item.ordem.marcaModelo,
          isCustomer: false,
          position: osPos,
          data: item,
        );
        nodesList.add(osNode);
        map[osNodeId] = osNode;

        // Aresta direcionada do Cliente para a OS
        edgesList.add(GraphEdge(
          fromId: clientNodeId,
          toId: osNodeId,
          from: clientPos,
          to: osPos,
        ));
      }
    }

    _nodes = nodesList;
    _edges = edgesList;
    _nodesMap = map;
  }

  bool _matchesSearch(GraphNode node) {
    if (_searchQuery.isEmpty) return true;
    final query = _searchQuery.toLowerCase();

    if (node.isCustomer) {
      if (node.label.toLowerCase().contains(query)) return true;

      // Verifica se alguma OS associada a este cliente bate com a busca
      final cliente = node.data as Cliente;
      final osList = _clientGroups[cliente.id] ?? [];
      return osList.any((item) {
        final matchesId = item.ordem.id.toString() == query || '#${item.ordem.id}' == query;
        final matchesModel = item.ordem.marcaModelo.toLowerCase().contains(query);
        return matchesId || matchesModel;
      });
    } else {
      final item = node.data as OrdemComCliente;
      final matchesId = item.ordem.id.toString() == query || '#${item.ordem.id}' == query;
      final matchesModel = item.ordem.marcaModelo.toLowerCase().contains(query);
      final matchesClient = item.cliente.nome.toLowerCase().contains(query);
      return matchesId || matchesModel || matchesClient;
    }
  }

  void _zoom(double factor) {
    final double currentZoom = _transformationController.value.getMaxScaleOnAxis();
    if (factor > 1 && currentZoom > 2.5) return; // Limite de zoom in
    if (factor < 1 && currentZoom < 0.3) return; // Limite de zoom out

    setState(() {
      _transformationController.value = _transformationController.value * Matrix4.diagonal3Values(factor, factor, 1.0);
    });
  }

  void _resetZoom() {
    setState(() {
      _transformationController.value = Matrix4.identity();
    });
  }

  void _mostrarDetalhesCliente(Cliente cliente) {
    final ordens = _clientGroups[cliente.id] ?? [];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(24),
              topRight: Radius.circular(24),
            ),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 26,
                    backgroundColor: const Color(0xFF1565C0).withValues(alpha: 0.1),
                    child: const Icon(Icons.person, color: Color(0xFF1565C0), size: 28),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          cliente.nome,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF2C3E50),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'CPF: ${cliente.cpf}  •  Tlf: ${cliente.telefone}',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const Divider(height: 32),
              Text(
                'Serviços Vinculados (${ordens.length})',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2C3E50),
                ),
              ),
              const SizedBox(height: 12),
              if (ordens.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: Text(
                    'Nenhum serviço registrado para este cliente.',
                    style: TextStyle(color: Colors.grey[500], fontSize: 13, fontStyle: FontStyle.italic),
                  ),
                )
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: ordens.length,
                    itemBuilder: (context, index) {
                      final item = ordens[index];
                      final isOrcamento = item.ordem.tipoRegistro.toLowerCase().contains('orç') || 
                                          item.ordem.tipoRegistro.toLowerCase().contains('orc');

                      Color statusColor;
                      switch (item.ordem.status.toLowerCase()) {
                        case 'pendente':
                        case 'aberta':
                          statusColor = const Color(0xFFE67E22);
                          break;
                        case 'em manutenção':
                        case 'em manutencao':
                          statusColor = const Color(0xFF2980B9);
                          break;
                        case 'aguardando retirada':
                        case 'aguardo de retirada':
                          statusColor = const Color(0xFF8E44AD);
                          break;
                        case 'concluído':
                        case 'concluida':
                        case 'concluido':
                          statusColor = const Color(0xFF27AE60);
                          break;
                        default:
                          statusColor = Colors.grey;
                      }

                      return Card(
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(color: Colors.grey.withValues(alpha: 0.15)),
                        ),
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        child: ListTile(
                          onTap: () {
                            Navigator.pop(context); // fecha sheet
                            Navigator.pushNamed(
                              context, 
                              '/detalhes-os', 
                              arguments: item,
                            ).then((_) => _carregarDados());
                          },
                          leading: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: isOrcamento ? const Color(0xFF00897B).withValues(alpha: 0.1) : const Color(0xFF1565C0).withValues(alpha: 0.1),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              isOrcamento ? Icons.assignment_outlined : Icons.build_outlined,
                              color: isOrcamento ? const Color(0xFF00897B) : const Color(0xFF1565C0),
                              size: 18,
                            ),
                          ),
                          title: Text(
                            item.ordem.marcaModelo,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                          subtitle: Text(
                            '${isOrcamento ? 'OC' : 'OS'} #${item.ordem.id}',
                            style: TextStyle(color: Colors.grey[500], fontSize: 11),
                          ),
                          trailing: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: statusColor.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              item.ordem.status,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: statusColor,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        );
  }

  String _gerarHtmlDinamico() {
    final StringBuffer nodesBuffer = StringBuffer();
    final StringBuffer edgesBuffer = StringBuffer();

    _clientGroups.forEach((clientId, clientOrders) {
      if (clientOrders.isNotEmpty) {
        final cliente = clientOrders.first.cliente;
        nodesBuffer.write("                { id: 'c_${cliente.id}', label: '${cliente.nome}', title: 'CPF: ${cliente.cpf}', shape: 'dot', size: 25, color: { background: '#1d4ed8', border: '#1e40af' }, font: { color: '#1e293b', size: 14, bold: true } },\n");

        for (var item in clientOrders) {
          final isOrcamento = item.ordem.tipoRegistro.toLowerCase().contains('orç') || 
                              item.ordem.tipoRegistro.toLowerCase().contains('orc');
          final isOC = isOrcamento ? 'OC' : 'OS';

          String background = '#f97316';
          String border = '#ea580c';
          switch (item.ordem.status.toLowerCase()) {
            case 'concluído':
            case 'concluida':
            case 'concluido':
              background = '#10b981';
              border = '#059669';
              break;
            case 'aguardando retirada':
            case 'aguardo de retirada':
              background = '#7c3aed';
              border = '#6d28d9';
              break;
          }

          nodesBuffer.write("                { id: 'os_${item.ordem.id}', label: '$isOC #${item.ordem.id}\\n${item.ordem.marcaModelo}', title: 'Status: ${item.ordem.status}\\nValor: R\$ ${item.ordem.valor?.toStringAsFixed(2) ?? "0.00"}', shape: 'box', color: { background: '$background', border: '$border' }, font: { color: '#ffffff', size: 12 } },\n");
          edgesBuffer.write("                { from: 'c_${cliente.id}', to: 'os_${item.ordem.id}', arrows: 'to', width: 2, color: { color: '#94a3b8', highlight: '#3b82f6' } },\n");
        }
      }
    });

    return r'''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Grafo de Relacionamentos - Telecell Mobile</title>
    
    <!-- Tailwind CSS para Estilização Premium -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Google Fonts: Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Vis.js Standalone CDN para renderizar o Grafo -->
    <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f1f5f9;
        }
        #network-container {
            width: 100%;
            height: 550px;
            border: 1px solid #cbd5e1;
            background-color: #ffffff;
            border-radius: 16px;
            box-shadow: inset 0 2px 4px 0 rgb(0 0 0 / 0.05);
        }
    </style>
</head>
<body class="p-6 md:p-12 max-w-7xl mx-auto">
    <!-- Cabeçalho -->
    <header class="bg-gradient-to-r from-blue-700 to-indigo-900 text-white rounded-2xl p-8 shadow-lg mb-8">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
                <span class="bg-blue-500 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">Trabalho Prático - Nota 2</span>
                <h1 class="text-3xl font-extrabold mt-2">Grafo de Relacionamento Clientes-OS/OC</h1>
                <p class="text-blue-100 text-sm mt-1">Mapeamento de relacionamentos 1:N e integridade referencial da assistência técnica Telecell Mobile</p>
            </div>
            <div class="mt-4 md:mt-0 text-right">
                <p class="text-xs text-blue-200">Aluno/Desenvolvedor:</p>
                <p class="text-lg font-bold">Arthur Guedes</p>
                <p class="text-xs text-blue-300">Teoria dos Grafos & Visualização Interativa</p>
            </div>
        </div>
    </header>

    <!-- Conteúdo Principal -->
    <main class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Coluna da Esquerda: Fundamentação e Dados -->
        <section class="lg:col-span-1 space-y-6">
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h2 class="text-lg font-bold text-slate-800 mb-3 flex items-center gap-2">
                    <span class="bg-blue-100 text-blue-700 p-1.5 rounded-lg">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path></svg>
                    </span>
                    Definição do Problema
                </h2>
                <p class="text-slate-600 text-sm leading-relaxed mb-4">
                    O problema consiste em modelar e analisar visualmente a integridade referencial de relacionamentos de uma assistência técnica de smartphones. 
                    Mapeamos a relação 1:N entre <strong>Clientes</strong> e suas respectivas <strong>Ordens de Serviço (OS)</strong> e <strong>Propostas de Orçamento (OC)</strong>.
                </p>
                <div class="bg-slate-50 p-4 rounded-xl text-xs space-y-2 border border-slate-100">
                    <p class="font-semibold text-slate-700">Abstração Matemática do Grafo G = (V, E):</p>
                    <ul class="list-disc list-inside space-y-1 text-slate-600">
                        <li><strong>Vértices (V):</strong> Divididos em dois subconjuntos disjuntos (Clientes e Serviços).</li>
                        <li><strong>Arestas (E):</strong> Conexões direcionadas (u, v) partindo do nó do Cliente u e apontando para o nó do serviço v (OS/OC correspondente).</li>
                    </ul>
                </div>
            </div>

            <!-- Painel de Métricas -->
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h2 class="text-lg font-bold text-slate-800 mb-4">Métricas do Grafo</h2>
                <div class="grid grid-cols-2 gap-4">
                    <div class="bg-blue-50/50 p-4 rounded-xl text-center">
                        <span class="text-2xl font-extrabold text-blue-700">3</span>
                        <p class="text-xs text-slate-500 font-semibold mt-1">Clientes (Hubs)</p>
                    </div>
                    <div class="bg-orange-50/50 p-4 rounded-xl text-center">
                        <span class="text-2xl font-extrabold text-orange-700">3</span>
                        <p class="text-xs text-slate-500 font-semibold mt-1">Serviços Ativos</p>
                    </div>
                    <div class="bg-emerald-50/50 p-4 rounded-xl text-center">
                        <span class="text-2xl font-extrabold text-emerald-700">1</span>
                        <p class="text-xs text-slate-500 font-semibold mt-1">Concluídos</p>
                    </div>
                    <div class="bg-purple-50/50 p-4 rounded-xl text-center">
                        <span class="text-2xl font-extrabold text-purple-700">1</span>
                        <p class="text-xs text-slate-500 font-semibold mt-1">Retiradas</p>
                    </div>
                </div>
            </div>

            <!-- Legenda das Cores -->
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h2 class="text-lg font-bold text-slate-800 mb-3">Legenda de Nós</h2>
                <div class="space-y-3">
                    <div class="flex items-center gap-3">
                        <span class="w-4 h-4 rounded-full bg-blue-600 block shadow-sm"></span>
                        <span class="text-xs font-semibold text-slate-700">Clientes (Vértice Principal)</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="w-4 h-4 rounded-sm bg-orange-500 block shadow-sm"></span>
                        <span class="text-xs font-semibold text-slate-700">Serviços Pendentes / Manutenção</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="w-4 h-4 rounded-sm bg-purple-600 block shadow-sm"></span>
                        <span class="text-xs font-semibold text-slate-700">Aguardando Retirada</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="w-4 h-4 rounded-sm bg-emerald-500 block shadow-sm"></span>
                        <span class="text-xs font-semibold text-slate-700">Histórico de Concluídos</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Coluna da Direita: Grafo Interativo -->
        <section class="lg:col-span-2 space-y-6">
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h2 class="text-xl font-bold text-slate-800">Visualizador Interativo</h2>
                        <p class="text-xs text-slate-500 mt-0.5">Use a roda do mouse para dar zoom, clique e arraste para mover o grafo ou nós</p>
                    </div>
                    <button onclick="resetarVisualizacao()" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 transition">
                        Resetar Grafo
                    </button>
                </div>
                
                <!-- Container do Grafo -->
                <div id="network-container"></div>
            </div>
        </section>
    </main>

    <footer class="text-center text-xs text-slate-500 mt-12 border-t border-slate-200 pt-6">
        <p>Desenvolvido por Arthur Guedes para a Assistência Técnica Telecell Mobile &copy; 2026</p>
    </footer>

    <!-- Script de Inicialização do Vis.js -->
    <script type="text/javascript">
        var network;

        function inicializarGrafo() {
            var container = document.getElementById('network-container');

            // Definição dos nós
            var nodes = new vis.DataSet([
''' + nodesBuffer.toString() + r'''
            ]);

            // Definição das conexões
            var edges = new vis.DataSet([
''' + edgesBuffer.toString() + r'''
            ]);

            var data = {
                nodes: nodes,
                edges: edges
            };

            // Opções Premium de Renderização do Grafo
            var options = {
                nodes: {
                    shadow: {
                        enabled: true,
                        color: 'rgba(0,0,0,0.15)',
                        size: 6,
                        x: 0,
                        y: 3
                    },
                    borderWidth: 2,
                    margin: 10
                },
                edges: {
                    shadow: {
                        enabled: true,
                        color: 'rgba(0,0,0,0.08)',
                        size: 4,
                        x: 0,
                        y: 2
                    },
                    smooth: {
                        type: 'cubicBezier',
                        forceDirection: 'none',
                        roundness: 0.5
                    }
                },
                physics: {
                    enabled: true,
                    solver: 'forceAtlas2Based',
                    forceAtlas2Based: {
                        gravitationalConstant: -100,
                        centralGravity: 0.015,
                        springLength: 150,
                        springConstant: 0.05,
                        damping: 0.4
                    },
                    stabilization: {
                        enabled: true,
                        iterations: 150,
                        updateInterval: 25
                    }
                },
                interaction: {
                    hover: true,
                    zoomView: true,
                    dragView: true,
                    dragNodes: true
                }
            };

            network = new vis.Network(container, data, options);
        }

        function resetarVisualizacao() {
            if (network) {
                network.fit({
                    animation: {
                        duration: 800,
                        easingFunction: 'easeInOutQuad'
                    }
                });
            }
        }

        // Inicializa o grafo ao carregar a página
        window.addEventListener('DOMContentLoaded', inicializarGrafo);
    </script>
</body>
</html>
''';
  }

  Future<void> _exportarGrafoHTML() async {
    try {
      final String html = _gerarHtmlDinamico();
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/grafo-arthurguedes.html');
      await file.writeAsString(html);

      if (!mounted) return;
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Relatório Exportado'),
          content: Text('O arquivo HTML interativo foi salvo com sucesso em:\n\n${file.path}\n\nVocê também encontrará o arquivo compactado "grafo-arthurguedes.zip" pronto para envio na pasta do projeto.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao exportar relatório HTML: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Calcula as dimensões do Canvas baseadas na quantidade de clientes
    const double cellSize = 380.0;
    const int cols = 3;
    final int clientCount = _clientGroups.length;
    final int rows = (clientCount / cols).ceil();

    final double canvasWidth = max(800.0, cols * cellSize);
    final double canvasHeight = max(600.0, rows * cellSize);

    return Scaffold(
      backgroundColor: const Color(0xFFECEFF1),
      appBar: AppBar(
        title: const Text('Grafo de Relacionamentos'),
        backgroundColor: const Color(0xFF1565C0),
        actions: [
          IconButton(
            icon: const Icon(Icons.file_download),
            onPressed: _exportarGrafoHTML,
            tooltip: 'Exportar Relatório HTML',
          ),
        ],
      ),
      body: _carregando
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Barra de pesquisa dinâmica
                Container(
                  padding: const EdgeInsets.all(12),
                  color: Colors.white,
                  child: TextField(
                    controller: _searchController,
                    onChanged: (val) {
                      setState(() {
                        _searchQuery = val;
                      });
                    },
                    decoration: InputDecoration(
                      hintText: 'Pesquisar Cliente ou OS no Grafo...',
                      hintStyle: TextStyle(color: Colors.grey[400], fontSize: 13),
                      prefixIcon: const Icon(Icons.search, color: Color(0xFF1565C0)),
                      suffixIcon: _searchQuery.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear, color: Colors.grey),
                              onPressed: () {
                                _searchController.clear();
                                setState(() {
                                  _searchQuery = '';
                                });
                              },
                            )
                          : null,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.2)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.15)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Color(0xFF1565C0), width: 1.5),
                      ),
                      contentPadding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                Expanded(
                  child: Stack(
                    children: [
                      // Área interativa de renderização do Grafo
                      InteractiveViewer(
                        transformationController: _transformationController,
                        boundaryMargin: const EdgeInsets.all(500),
                        minScale: 0.15,
                        maxScale: 3.0,
                        child: SizedBox(
                          width: canvasWidth,
                          height: canvasHeight,
                          child: Stack(
                            children: [
                              // 1. Linhas de Conexão (Arestas) desenhadas no CustomPainter
                              Positioned.fill(
                                child: CustomPaint(
                                  size: Size(canvasWidth, canvasHeight),
                                  painter: GraphPainter(
                                    edges: _edges,
                                    searchQuery: _searchQuery,
                                    nodesMap: _nodesMap,
                                  ),
                                ),
                              ),
                              // 2. Nós (Clientes e Ordens de Serviço)
                              ..._nodes.map((node) {
                                final isSelected = _matchesSearch(node);
                                // Aplica opacidade baixa para nós não correspondentes à busca
                                final double opacity = _searchQuery.isNotEmpty && !isSelected ? 0.15 : 1.0;

                                if (node.isCustomer) {
                                  // Nó do Cliente (Círculo Azul)
                                  final double circleSize = 78.0;
                                  return Positioned(
                                    left: node.position.dx - (150 / 2),
                                    top: node.position.dy - (circleSize / 2),
                                    child: Opacity(
                                      opacity: opacity,
                                      child: SizedBox(
                                        width: 150,
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            GestureDetector(
                                              onTap: () => _mostrarDetalhesCliente(node.data as Cliente),
                                              child: Container(
                                                width: circleSize,
                                                height: circleSize,
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  gradient: const LinearGradient(
                                                    begin: Alignment.topLeft,
                                                    end: Alignment.bottomRight,
                                                    colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
                                                  ),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: Colors.black.withValues(alpha: 0.25),
                                                      blurRadius: 8,
                                                      offset: const Offset(0, 4),
                                                    ),
                                                    if (_searchQuery.isNotEmpty && isSelected)
                                                      BoxShadow(
                                                        color: const Color(0xFFE67E22).withValues(alpha: 0.7),
                                                        blurRadius: 16,
                                                        spreadRadius: 4,
                                                      )
                                                  ],
                                                  border: Border.all(color: Colors.white, width: 2.5),
                                                ),
                                                child: const Icon(
                                                  Icons.person,
                                                  color: Colors.white,
                                                  size: 32,
                                                ),
                                              ),
                                            ),
                                            const SizedBox(height: 8),
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                              decoration: BoxDecoration(
                                                color: Colors.white.withValues(alpha: 0.9),
                                                borderRadius: BorderRadius.circular(6),
                                                border: Border.all(color: Colors.grey.withValues(alpha: 0.15)),
                                              ),
                                              child: Text(
                                                node.label,
                                                style: const TextStyle(
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.bold,
                                                  color: Color(0xFF2C3E50),
                                                ),
                                                textAlign: TextAlign.center,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                } else {
                                  // Nó de Ordem de Serviço (Retângulo Laranja)
                                  final double nodeWidth = 115.0;
                                  final double nodeHeight = 62.0;
                                  final item = node.data as OrdemComCliente;

                                  Color statusColor;
                                  switch (item.ordem.status.toLowerCase()) {
                                    case 'pendente':
                                    case 'aberta':
                                      statusColor = const Color(0xFFE67E22);
                                      break;
                                    case 'em manutenção':
                                    case 'em manutencao':
                                      statusColor = const Color(0xFF2980B9);
                                      break;
                                    case 'aguardando retirada':
                                    case 'aguardo de retirada':
                                      statusColor = const Color(0xFF8E44AD);
                                      break;
                                    case 'concluído':
                                    case 'concluida':
                                    case 'concluido':
                                      statusColor = const Color(0xFF27AE60);
                                      break;
                                    default:
                                      statusColor = Colors.grey;
                                  }

                                  return Positioned(
                                    left: node.position.dx - (nodeWidth / 2),
                                    top: node.position.dy - (nodeHeight / 2),
                                    child: Opacity(
                                      opacity: opacity,
                                      child: GestureDetector(
                                        onTap: () {
                                          Navigator.pushNamed(
                                            context, 
                                            '/detalhes-os', 
                                            arguments: item,
                                          ).then((_) => _carregarDados());
                                        },
                                        child: Container(
                                          width: nodeWidth,
                                          height: nodeHeight,
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                          decoration: BoxDecoration(
                                            gradient: const LinearGradient(
                                              begin: Alignment.topLeft,
                                              end: Alignment.bottomRight,
                                              colors: [Color(0xFFE67E22), Color(0xFFD35400)],
                                            ),
                                            borderRadius: BorderRadius.circular(12),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Colors.black.withValues(alpha: 0.18),
                                                blurRadius: 6,
                                                offset: const Offset(0, 3),
                                              ),
                                              if (_searchQuery.isNotEmpty && isSelected)
                                                BoxShadow(
                                                  color: Colors.white.withValues(alpha: 0.9),
                                                  blurRadius: 12,
                                                  spreadRadius: 3,
                                                )
                                            ],
                                            border: Border.all(
                                              color: Colors.white.withValues(alpha: 0.4),
                                              width: 1.5,
                                            ),
                                          ),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text(
                                                    node.label,
                                                    style: const TextStyle(
                                                      fontSize: 10,
                                                      fontWeight: FontWeight.w900,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 7,
                                                    height: 7,
                                                    decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      color: statusColor == const Color(0xFF27AE60) ? Colors.white : Colors.white60,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Text(
                                                node.sublabel,
                                                style: const TextStyle(
                                                  fontSize: 9,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white70,
                                                ),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }
                              }),
                            ],
                          ),
                        ),
                      ),

                      // Botão Flutuante de Instruções rápidas de navegação (legenda)
                      Positioned(
                        left: 12,
                        bottom: 12,
                        child: Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          color: Colors.white.withValues(alpha: 0.95),
                          elevation: 3,
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Row(
                                  children: [
                                    Container(width: 12, height: 12, decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF1565C0))),
                                    const SizedBox(width: 8),
                                    const Text('Cliente', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                Row(
                                  children: [
                                    Container(width: 12, height: 12, decoration: BoxDecoration(borderRadius: BorderRadius.circular(3), color: const Color(0xFFE67E22))),
                                    const SizedBox(width: 8),
                                    const Text('Ordem (OS/OC)', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                const Divider(height: 12),
                                const Text('Dica: Use gestos de pinça para Zoom e arraste para navegar', style: TextStyle(fontSize: 8, color: Colors.grey)),
                              ],
                            ),
                          ),
                        ),
                      ),

                      // Painel Flutuante de Controle de Zoom
                      Positioned(
                        right: 12,
                        bottom: 12,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            FloatingActionButton.small(
                              heroTag: 'zoom_in',
                              onPressed: () => _zoom(1.25),
                              backgroundColor: Colors.white,
                              foregroundColor: const Color(0xFF1565C0),
                              child: const Icon(Icons.add),
                            ),
                            const SizedBox(height: 6),
                            FloatingActionButton.small(
                              heroTag: 'zoom_out',
                              onPressed: () => _zoom(0.8),
                              backgroundColor: Colors.white,
                              foregroundColor: const Color(0xFF1565C0),
                              child: const Icon(Icons.remove),
                            ),
                            const SizedBox(height: 6),
                            FloatingActionButton.small(
                              heroTag: 'zoom_reset',
                              onPressed: _resetZoom,
                              backgroundColor: const Color(0xFF1565C0),
                              foregroundColor: Colors.white,
                              child: const Icon(Icons.center_focus_strong),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

class GraphNode {
  final String id;
  final String label;
  final String sublabel;
  final bool isCustomer;
  final Offset position;
  final dynamic data;

  GraphNode({
    required this.id,
    required this.label,
    required this.sublabel,
    required this.isCustomer,
    required this.position,
    required this.data,
  });
}

class GraphEdge {
  final String fromId;
  final String toId;
  final Offset from;
  final Offset to;

  GraphEdge({
    required this.fromId,
    required this.toId,
    required this.from,
    required this.to,
  });
}

class GraphPainter extends CustomPainter {
  final List<GraphEdge> edges;
  final String searchQuery;
  final Map<String, GraphNode> nodesMap;

  GraphPainter({required this.edges, required this.searchQuery, required this.nodesMap});

  @override
  void paint(Canvas canvas, Size size) {
    final defaultPaint = Paint()
      ..color = const Color(0xFF1565C0).withValues(alpha: 0.3)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final highlightedPaint = Paint()
      ..color = const Color(0xFFE67E22)
      ..strokeWidth = 3.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    for (var edge in edges) {
      final fromNode = nodesMap[edge.fromId];
      final toNode = nodesMap[edge.toId];
      if (fromNode == null || toNode == null) continue;

      bool isHighlighted = false;
      if (searchQuery.isNotEmpty) {
        final query = searchQuery.toLowerCase();

        // Se o nó de origem (Cliente) ou de destino (OS) bate diretamente com o termo digitado
        final matchesFrom = fromNode.label.toLowerCase().contains(query);

        final item = toNode.data as OrdemComCliente;
        final matchesToId = item.ordem.id.toString() == query || '#${item.ordem.id}' == query;
        final matchesToModel = item.ordem.marcaModelo.toLowerCase().contains(query);
        final matchesTo = matchesToId || matchesToModel;

        if (matchesFrom || matchesTo) {
          isHighlighted = true;
        }
      }

      final start = edge.from;
      final end = edge.to;

      if (isHighlighted) {
        canvas.drawLine(start, end, highlightedPaint);
        _drawArrow(canvas, start, end, const Color(0xFFE67E22));
      } else {
        canvas.drawLine(
          start, 
          end, 
          searchQuery.isNotEmpty 
              ? (Paint()..color = const Color(0xFF1565C0).withValues(alpha: 0.08)..strokeWidth = 1.2..style = PaintingStyle.stroke)
              : defaultPaint
        );
        _drawArrow(
          canvas, 
          start, 
          end, 
          searchQuery.isNotEmpty 
              ? const Color(0xFF1565C0).withValues(alpha: 0.1) 
              : const Color(0xFF1565C0).withValues(alpha: 0.4)
        );
      }
    }
  }

  void _drawArrow(Canvas canvas, Offset from, Offset to, Color color) {
    final dx = to.dx - from.dx;
    final dy = to.dy - from.dy;
    final distance = sqrt(dx * dx + dy * dy);
    if (distance < 50) return;

    // A OS é um retângulo, o raio até a borda externa é aproximadamente 35 pixels
    const shortenDistance = 37.0; 
    final ratio = (distance - shortenDistance) / distance;
    final arrowTip = Offset(from.dx + dx * ratio, from.dy + dy * ratio);

    final angle = atan2(dy, dx);
    const arrowSize = 7.0;
    const arrowAngle = 28.0 * pi / 180.0;

    final path = Path();
    path.moveTo(arrowTip.dx, arrowTip.dy);
    path.lineTo(
      arrowTip.dx - arrowSize * cos(angle - arrowAngle),
      arrowTip.dy - arrowSize * sin(angle - arrowAngle),
    );
    path.lineTo(
      arrowTip.dx - arrowSize * cos(angle + arrowAngle),
      arrowTip.dy - arrowSize * sin(angle + arrowAngle),
    );
    path.close();

    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant GraphPainter oldDelegate) {
    return oldDelegate.edges != edges || oldDelegate.searchQuery != searchQuery || oldDelegate.nodesMap != nodesMap;
  }
}
