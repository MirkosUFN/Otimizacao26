import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'dart:io';

part 'app_database.g.dart';

// =============================================================================
// TABELA: Clientes
// =============================================================================
class Clientes extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get nome => text()();
  TextColumn get telefone => text()();
  TextColumn get cpf => text()();
}

// =============================================================================
// TABELA: OrdensServico
// =============================================================================
@DataClassName('OrdemDeServico')
class OrdensServico extends Table {
  IntColumn get id => integer().autoIncrement()();

  // Chave estrangeira -> Clientes.id
  IntColumn get clienteId =>
      integer().references(Clientes, #id)();

  TextColumn get tipoRegistro => text()();
  DateTimeColumn get dataEntrada => dateTime()();
  TextColumn get marcaModelo => text()();
  TextColumn get imei => text()();
  TextColumn get senhaDesbloqueio => text()();
  BoolColumn get checkDisplay => boolean().withDefault(const Constant(false))();
  BoolColumn get checkTouch => boolean().withDefault(const Constant(false))();
  TextColumn get problemaRelatado => text()();
  TextColumn get servicoExecutado => text().nullable()();
  RealColumn get valor => real().nullable()();
  TextColumn get status => text().withDefault(const Constant('Aberta'))();
}

// =============================================================================
// CLASSE DO BANCO DE DADOS
// =============================================================================
@DriftDatabase(tables: [Clientes, OrdensServico])
class AppDatabase extends _$AppDatabase {
  static final AppDatabase _instance = AppDatabase._internal();

  factory AppDatabase() => _instance;

  AppDatabase._internal() : super(_abrirConexao());

  @override
  int get schemaVersion => 1;

  // ---------------------------------------------------------------------------
  // CLIENTES — CRUD
  // ---------------------------------------------------------------------------

  /// Insere um novo cliente e retorna o ID gerado.
  Future<int> inserirCliente(ClientesCompanion cliente) =>
      into(clientes).insert(cliente);

  /// Retorna todos os clientes ordenados por nome.
  Future<List<Cliente>> listarClientes() =>
      (select(clientes)..orderBy([(t) => OrderingTerm.asc(t.nome)])).get();

  /// Busca clientes pelo nome (busca parcial, case-insensitive).
  Future<List<Cliente>> buscarClientesPorNome(String nome) =>
      (select(clientes)
            ..where((t) => t.nome.lower().like('%${nome.toLowerCase()}%')))
          .get();

  /// Atualiza os dados de um cliente existente.
  Future<bool> atualizarCliente(Cliente cliente) =>
      update(clientes).replace(cliente);

  /// Exclui um cliente por ID.
  Future<int> excluirCliente(int id) =>
      (delete(clientes)..where((t) => t.id.equals(id))).go();

  // ---------------------------------------------------------------------------
  // ORDENS DE SERVIÇO — CRUD
  // ---------------------------------------------------------------------------

  /// Insere uma nova OS e retorna o ID gerado.
  Future<int> inserirOrdem(OrdensServicoCompanion ordem) =>
      into(ordensServico).insert(ordem);

  /// Atualiza uma OS existente.
  Future<bool> atualizarOrdem(OrdensServicoCompanion ordem) =>
      update(ordensServico).replace(ordem);

  /// Exclui uma OS por ID.
  Future<int> excluirOrdem(int id) =>
      (delete(ordensServico)..where((t) => t.id.equals(id))).go();

  // ---------------------------------------------------------------------------
  // ORDENS DE SERVIÇO — QUERIES COM JOIN
  // ---------------------------------------------------------------------------

  /// Retorna todas as OS com os dados do cliente (JOIN Clientes).
  Future<List<OrdemComCliente>> listarOrdensComCliente() async {
    final query = select(ordensServico).join([
      innerJoin(clientes, clientes.id.equalsExp(ordensServico.clienteId)),
    ])
      ..orderBy([OrderingTerm.desc(ordensServico.dataEntrada)]);

    final rows = await query.get();
    return rows
        .map((row) => OrdemComCliente(
              ordem: row.readTable(ordensServico),
              cliente: row.readTable(clientes),
            ))
        .toList();
  }

  /// Busca OS por nome do cliente ou por status.
  Future<List<OrdemComCliente>> buscarOrdens({
    String? nomeCliente,
    String? status,
  }) async {
    final query = select(ordensServico).join([
      innerJoin(clientes, clientes.id.equalsExp(ordensServico.clienteId)),
    ]);

    if (nomeCliente != null && nomeCliente.isNotEmpty) {
      query.where(
          clientes.nome.lower().like('%${nomeCliente.toLowerCase()}%'));
    }
    if (status != null && status.isNotEmpty) {
      query.where(ordensServico.status.equals(status));
    }

    query.orderBy([OrderingTerm.desc(ordensServico.dataEntrada)]);

    final rows = await query.get();
    return rows
        .map((row) => OrdemComCliente(
              ordem: row.readTable(ordensServico),
              cliente: row.readTable(clientes),
            ))
        .toList();
  }

  /// Retorna todas as OS de um cliente específico.
  Future<List<OrdemDeServico>> listarOrdensPorCliente(int clienteId) =>
      (select(ordensServico)
            ..where((t) => t.clienteId.equals(clienteId))
            ..orderBy([(t) => OrderingTerm.desc(t.dataEntrada)]))
          .get();

  // ---------------------------------------------------------------------------
  // INTELIGÊNCIA DE ESTOQUE — AGRUPAMENTO
  // ---------------------------------------------------------------------------

  /// Agrupa as OS por modelo e conta as ocorrências de cada um, ordenado decrescentemente.
  Future<List<ModeloVolume>> obterVolumePorModelo() async {
    final countExpr = ordensServico.id.count();
    final query = selectOnly(ordensServico)
      ..addColumns([ordensServico.marcaModelo, countExpr])
      ..groupBy([ordensServico.marcaModelo])
      ..orderBy([OrderingTerm.desc(countExpr)]);

    final rows = await query.get();
    return rows.map((row) {
      return ModeloVolume(
        marcaModelo: row.read(ordensServico.marcaModelo) ?? 'Desconhecido',
        volume: row.read(countExpr) ?? 0,
      );
    }).toList();
  }

  // ---------------------------------------------------------------------------
  // DADOS DE TESTE (SEED)
  // ---------------------------------------------------------------------------
  Future<void> inserirSeedData() async {
    // Insere Clientes
    final c1 = await inserirCliente(const ClientesCompanion(
      nome: Value('Arthur Guedes'),
      telefone: Value('(11) 98765-4321'),
      cpf: Value('123.456.789-00'),
    ));
    final c2 = await inserirCliente(const ClientesCompanion(
      nome: Value('Mariana Silva'),
      telefone: Value('(21) 99888-7766'),
      cpf: Value('987.654.321-11'),
    ));
    final c3 = await inserirCliente(const ClientesCompanion(
      nome: Value('Carlos Souza'),
      telefone: Value('(31) 97777-8899'),
      cpf: Value('456.789.123-22'),
    ));

    // Insere Ordens de Serviço
    final agora = DateTime.now();
    await inserirOrdem(OrdensServicoCompanion(
      clienteId: Value(c1),
      tipoRegistro: const Value('OS'),
      dataEntrada: Value(agora.subtract(const Duration(days: 2))),
      marcaModelo: const Value('iPhone 14 Pro Max'),
      imei: const Value('351759104829104'),
      senhaDesbloqueio: const Value('147852'),
      checkDisplay: const Value(true),
      checkTouch: const Value(true),
      problemaRelatado: const Value('Tela frontal totalmente quebrada e tampa traseira trincada após queda.'),
      status: const Value('Pendente'),
      valor: const Value(1650.0),
    ));

    await inserirOrdem(OrdensServicoCompanion(
      clienteId: Value(c1),
      tipoRegistro: const Value('OS'),
      dataEntrada: Value(agora.subtract(const Duration(hours: 18))),
      marcaModelo: const Value('iPad Air 5ª Gen'),
      imei: const Value('352840194829105'),
      senhaDesbloqueio: const Value('0,1,2,5,8'),
      checkDisplay: const Value(true),
      checkTouch: const Value(false),
      problemaRelatado: const Value('Touchscreen não responde em metade da tela.'),
      status: const Value('Em Manutenção'),
      valor: const Value(890.0),
    ));

    await inserirOrdem(OrdensServicoCompanion(
      clienteId: Value(c2),
      tipoRegistro: const Value('Orçamento'),
      dataEntrada: Value(agora.subtract(const Duration(days: 1))),
      marcaModelo: const Value('Galaxy S23 Ultra'),
      imei: const Value('354928104829206'),
      senhaDesbloqueio: const Value('L Padrão'),
      checkDisplay: const Value(false),
      checkTouch: const Value(false),
      problemaRelatado: const Value('Aparelho não liga e aquece muito ao conectar no carregador.'),
      status: const Value('Pendente'),
      valor: const Value(1200.0),
    ));

    await inserirOrdem(OrdensServicoCompanion(
      clienteId: Value(c3),
      tipoRegistro: const Value('OS'),
      dataEntrada: Value(agora.subtract(const Duration(days: 5))),
      marcaModelo: const Value('Xiaomi Redmi Note 12'),
      imei: const Value('356928104829307'),
      senhaDesbloqueio: const Value('7896'),
      checkDisplay: const Value(true),
      checkTouch: const Value(true),
      problemaRelatado: const Value('Substituição de lente de câmera traseira riscada.'),
      status: const Value('Concluído'),
      valor: const Value(220.0),
      servicoExecutado: const Value('Troca de lente traseira realizada com sucesso.'),
    ));

    await inserirOrdem(OrdensServicoCompanion(
      clienteId: Value(c3),
      tipoRegistro: const Value('Orçamento'),
      dataEntrada: Value(agora.subtract(const Duration(days: 3))),
      marcaModelo: const Value('Motorola Moto G54'),
      imei: const Value('358928104829408'),
      senhaDesbloqueio: const Value('Sem senha'),
      checkDisplay: const Value(true),
      checkTouch: const Value(true),
      problemaRelatado: const Value('Tampa traseira quebrada. Solicita orçamento para troca de tampa na cor azul.'),
      status: const Value('Aguardando Retirada'),
      valor: const Value(180.0),
      servicoExecutado: const Value('Troca de tampa traseira realizada.'),
    ));
  }
}

class ModeloVolume {
  final String marcaModelo;
  final int volume;

  ModeloVolume({required this.marcaModelo, required this.volume});
}

// =============================================================================
// DATA CLASS AUXILIAR — Ordem + Cliente (resultado do JOIN)
// =============================================================================
class OrdemComCliente {
  final OrdemDeServico ordem;
  final Cliente cliente;

  OrdemComCliente({required this.ordem, required this.cliente});
}

// =============================================================================
// CONEXÃO COM O BANCO
// =============================================================================
LazyDatabase _abrirConexao() {
  return LazyDatabase(() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'gestor_os.db');
    return NativeDatabase(File(path));
  });
}
