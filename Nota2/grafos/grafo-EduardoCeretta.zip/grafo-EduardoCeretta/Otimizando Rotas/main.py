import csv
import networkx as nx
from pyvis.network import Network

voos = [
    ("GRU - São Paulo",     "GIG - Rio de Janeiro",   360,  45),
    ("GRU - São Paulo",     "BSB - Brasília",          870,  30),
    ("GRU - São Paulo",     "SSA - Salvador",         1960,  18),
    ("GRU - São Paulo",     "FOR - Fortaleza",        2380,  14),
    ("GRU - São Paulo",     "CWB - Curitiba",          340,  22),
    ("GRU - São Paulo",     "POA - Porto Alegre",     1107,  20),
    ("GRU - São Paulo",     "REC - Recife",           2660,  12),
    ("GRU - São Paulo",     "MAN - Manaus",           2694,   8),
    ("GIG - Rio de Janeiro","BSB - Brasília",          930,  20),
    ("GIG - Rio de Janeiro","SSA - Salvador",         1652,  14),
    ("GIG - Rio de Janeiro","FOR - Fortaleza",        2815,   8),
    ("GIG - Rio de Janeiro","POA - Porto Alegre",     1557,  12),
    ("BSB - Brasília",      "FOR - Fortaleza",        1692,  10),
    ("BSB - Brasília",      "SSA - Salvador",         1061,  14),
    ("BSB - Brasília",      "MAN - Manaus",           2712,   6),
    ("BSB - Brasília",      "REC - Recife",           1653,  10),
    ("SSA - Salvador",      "REC - Recife",            839,  10),
    ("SSA - Salvador",      "FOR - Fortaleza",        1182,   8),
    ("FOR - Fortaleza",     "REC - Recife",            800,  10),
    ("CWB - Curitiba",      "POA - Porto Alegre",      552,  14),
    ("POA - Porto Alegre",  "FLN - Florianópolis",     456,  10),
    ("CWB - Curitiba",      "FLN - Florianópolis",     298,   8),
    ("MAN - Manaus",        "BEL - Belém",            1310,   6),
    ("BSB - Brasília",      "BEL - Belém",            1768,   6),
    ("GRU - São Paulo",     "BEL - Belém",            2524,   6),
]

nome_csv = 'dados_voos_brasil.csv'
with open(nome_csv, mode='w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['Origem', 'Destino', 'Distancia_km', 'Voos_por_dia'])
    writer.writerows(voos)

print(f"✓ Base de dados salva: {nome_csv}")

G = nx.Graph()

with open(nome_csv, mode='r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        G.add_edge(
            row['Origem'],
            row['Destino'],
            weight=int(row['Distancia_km']),
            voos=int(row['Voos_por_dia'])
        )

print(f"✓ Grafo criado: {G.number_of_nodes()} aeroportos, {G.number_of_edges()} rotas")

print("\n📊 ANÁLISE DE CENTRALIDADE (quais aeroportos são mais estratégicos):")
centralidade = nx.degree_centrality(G)
for aeroporto, valor in sorted(centralidade.items(), key=lambda x: -x[1])[:5]:
    print(f"  {aeroporto}: {valor:.3f}")

print("\n🔗 AEROPORTO MAIS CONECTADO (maior grau):")
graus = dict(G.degree())
mais_conectado = max(graus, key=graus.get)
print(f"  {mais_conectado} com {graus[mais_conectado]} conexões diretas")

print("\n📏 MENOR CAMINHO entre Porto Alegre e Fortaleza:")
try:
    caminho = nx.shortest_path(G, "POA - Porto Alegre", "FOR - Fortaleza", weight='weight')
    distancia_total = nx.shortest_path_length(G, "POA - Porto Alegre", "FOR - Fortaleza", weight='weight')
    print(f"  Rota: {' → '.join(caminho)}")
    print(f"  Distância total: {distancia_total} km")
except nx.NetworkXNoPath:
    print("  Sem caminho encontrado.")

# Cores por região
cores = {
    "GRU - São Paulo":      "#FF6B35",
    "GIG - Rio de Janeiro": "#FF6B35",
    "CWB - Curitiba":       "#FF6B35",
    "POA - Porto Alegre":   "#FF6B35",
    "FLN - Florianópolis":  "#FF6B35",
    "BSB - Brasília":       "#4ECDC4",
    "SSA - Salvador":       "#FFE66D",
    "REC - Recife":         "#FFE66D",
    "FOR - Fortaleza":      "#FFE66D",
    "MAN - Manaus":         "#95E1D3",
    "BEL - Belém":          "#95E1D3",
}

net = Network(
    height='850px',
    width='100%',
    bgcolor='#0d1117',
    font_color='white',
    notebook=False
)

net.barnes_hut(gravity=-8000, central_gravity=0.3, spring_length=200)

# Adicionar nós
for node in G.nodes():
    grau = G.degree(node)
    tamanho = 20 + grau * 8
    cor = cores.get(node, "#AAAAAA")
    net.add_node(
        node,
        label=node,
        color=cor,
        size=tamanho,
        title=f"<b>{node}</b><br>Conexões diretas: {grau}",
        font={'size': 13, 'color': 'white'}
    )

# Adicionar arestas
max_voos = max(v for _, _, v in G.edges(data='voos'))
for u, v, data in G.edges(data=True):
    dist = data.get('weight', 0)
    voos_dia = data.get('voos', 1)
    espessura = 1 + (voos_dia / max_voos) * 7
    net.add_edge(
        u, v,
        title=f"{dist} km | {voos_dia} voos/dia",
        label=f"{dist}km",
        width=espessura,
        color={'color': '#4ECDC4', 'opacity': 0.6},
        font={'size': 9, 'color': '#AAAAAA'}
    )

net.set_options("""
{
  "physics": {
    "enabled": true,
    "barnesHut": {
      "gravitationalConstant": -8000,
      "centralGravity": 0.3,
      "springLength": 200
    }
  },
  "interaction": {
    "hover": true,
    "tooltipDelay": 100
  }
}
""")

nome_html = 'grafo_aeroportos_brasil.html'
net.save_graph(nome_html)

with open(nome_html, 'r', encoding='utf-8') as f:
    html = f.read()

legenda = """
<style>
  body { margin: 0; font-family: 'Segoe UI', sans-serif; }
  #legenda {
    position: fixed; top: 15px; left: 15px; z-index: 999;
    background: rgba(13,17,23,0.92);
    border: 1px solid #30363d;
    border-radius: 10px;
    padding: 14px 18px;
    color: white;
    font-size: 13px;
    min-width: 210px;
  }
  #legenda h3 { margin: 0 0 10px 0; font-size: 15px; color: #4ECDC4; }
  .leg-item { display:flex; align-items:center; gap:8px; margin:5px 0; }
  .dot { width:13px; height:13px; border-radius:50%; flex-shrink:0; }
  #titulo {
    position: fixed; top: 15px; left: 50%; transform: translateX(-50%);
    z-index: 999;
    background: rgba(13,17,23,0.92);
    border: 1px solid #30363d;
    border-radius: 10px;
    padding: 10px 22px;
    color: white;
    font-size: 18px;
    font-weight: bold;
    letter-spacing: 1px;
  }
</style>
<div id="titulo">✈️ Malha Aérea Brasileira</div>
<div id="legenda">
  <h3>Regiões</h3>
  <div class="leg-item"><div class="dot" style="background:#FF6B35"></div> Sul / Sudeste</div>
  <div class="leg-item"><div class="dot" style="background:#4ECDC4"></div> Centro-Oeste</div>
  <div class="leg-item"><div class="dot" style="background:#FFE66D"></div> Nordeste</div>
  <div class="leg-item"><div class="dot" style="background:#95E1D3"></div> Norte</div>
  <hr style="border-color:#30363d; margin:10px 0">
  <b>Espessura da aresta</b><br>
  <span style="color:#aaa; font-size:12px">proporcional ao nº de voos/dia</span><br><br>
  <b>Tamanho do nó</b><br>
  <span style="color:#aaa; font-size:12px">proporcional ao nº de conexões</span>
</div>
"""

html = html.replace('<body>', '<body>' + legenda)
with open(nome_html, 'w', encoding='utf-8') as f:
    f.write(html)

print(f"\n✓ Grafo HTML salvo: {nome_html}")
print("\n✅ Concluído! Abra 'grafo_aeroportos_brasil.html' no navegador.")