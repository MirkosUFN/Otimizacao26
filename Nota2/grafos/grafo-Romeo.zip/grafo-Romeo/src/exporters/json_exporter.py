import json
import os


class JSONExporter:
    def __init__(self, output_path: str):
        self.output_path = output_path

    def export(self, rede):
        data = {
            "nodes": rede.get_nos(),
            "edges": rede.get_arestas(),
            "menores_caminhos": rede.menores_caminhos(),
            "metrics": rede.get_metricas(),
        }
        os.makedirs(os.path.dirname(self.output_path), exist_ok=True)
        with open(self.output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        print(f"Grafo exportado para '{self.output_path}'")
        return data
