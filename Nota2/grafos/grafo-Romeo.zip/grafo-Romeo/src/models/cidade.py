class Cidade:
    """Representa um no do grafo: uma cidade atendida pela distribuidora."""

    def __init__(self, cidade_id: str, nome: str, populacao: int,
                 x: float, y: float, hub: bool = False):
        self.cidade_id = cidade_id
        self.nome = nome
        self.populacao = populacao
        self.x = x            # coordenada para layout (longitude aproximada)
        self.y = y            # coordenada para layout (latitude aproximada)
        self.hub = hub        # True se for o centro de distribuicao

    def to_dict(self) -> dict:
        return {
            "id": self.cidade_id,
            "nome": self.nome,
            "populacao": self.populacao,
            "x": self.x,
            "y": self.y,
            "hub": self.hub,
        }

    def __repr__(self):
        return f"Cidade({self.nome})"
