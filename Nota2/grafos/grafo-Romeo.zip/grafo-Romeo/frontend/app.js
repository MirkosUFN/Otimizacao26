document.addEventListener('DOMContentLoaded', () => {

  // ----- alternar tema -----
  const themeBtn = document.getElementById('theme-toggle');
  themeBtn.addEventListener('click', () => {
    const root = document.documentElement;
    root.classList.toggle('light-theme');
    const isLight = root.classList.contains('light-theme');
    themeBtn.innerText = isLight ? '🌙 Modo Escuro' : '☀️ Modo Claro';
    if (window.networkInstance) {
      const c = getComputedStyle(document.body).getPropertyValue('--txt');
      window.networkInstance.setOptions({ nodes: { font: { color: c } } });
    }
  });

  // ----- carregar dados (arquivo externo OU embutido) -----
  async function carregar() {
    try {
      const resp = await fetch('../data/grafo_entregas.json');
      if (!resp.ok) throw new Error('sem servidor');
      return await resp.json();
    } catch (e) {
      if (window.GRAFO_DATA) return window.GRAFO_DATA;  // fallback embutido
      throw e;
    }
  }

  carregar().then(initGraph).catch(err => {
    document.getElementById('network-stats').innerHTML =
      `<span style="color:#ef4444">Erro ao carregar dados: ${err.message}</span>`;
  });

  function initGraph(data) {
    // estatisticas
    const m = data.metrics;
    document.getElementById('network-stats').innerHTML = `
      <div class="stat"><div class="v">${m.n_cidades}</div><div class="l">Cidades</div></div>
      <div class="stat"><div class="v">${m.n_trechos}</div><div class="l">Trechos</div></div>
      <div class="stat"><div class="v">${m.dist_media_km} km</div><div class="l">Dist. média</div></div>
      <div class="stat"><div class="v">${m.dist_max_km} km</div><div class="l">Mais distante</div></div>`;

    const nomes = {};
    data.nodes.forEach(n => nomes[n.id] = n.nome);

    // nos
    const nodes = data.nodes.map(n => {
      const d = data.menores_caminhos[n.id].distancia_km;
      return {
        id: n.id,
        label: `${n.nome}\n${d} km`,
        x: n.x * 120, y: -n.y * 120,
        value: Math.sqrt(n.populacao),
        color: n.hub
          ? { background: '#f59e0b', border: '#b45309' }
          : { background: '#b91c1c', border: '#7f1d1d' },
        font: { color: getComputedStyle(document.body).getPropertyValue('--txt'), size: 16 },
      };
    });

    // arestas
    const edges = data.edges.map(e => ({
      from: e.origem, to: e.destino,
      label: `${e.distancia} km`,
      font: { size: 11, color: '#94a3b8', strokeWidth: 0 },
      color: { color: '#64748b', highlight: '#f59e0b' },
      width: 1.5,
    }));

    const container = document.getElementById('mynetwork');
    const visData = { nodes: new vis.DataSet(nodes), edges: new vis.DataSet(edges) };
    const options = {
      physics: false,
      nodes: { shape: 'dot', scaling: { min: 12, max: 36 }, borderWidth: 2 },
      edges: { smooth: { type: 'continuous' } },
      interaction: { hover: true, tooltipDelay: 100 },
    };
    window.networkInstance = new vis.Network(container, visData, options);

    // clique -> detalhe + destaque da rota
    window.networkInstance.on('click', params => {
      if (!params.nodes.length) return;
      const id = params.nodes[0];
      const node = data.nodes.find(n => n.id === id);
      const info = data.menores_caminhos[id];
      const rota = info.rota.map(r => nomes[r]).join(' → ');

      document.getElementById('user-details').innerHTML = `
        <h2>Detalhes da cidade</h2>
        <div class="detail-card">
          <div class="name">${node.nome}${node.hub ? ' ⭐ (HUB)' : ''}</div>
          <div class="row"><span>População</span><span>${node.populacao.toLocaleString('pt-BR')}</span></div>
          <div class="row"><span>Menor distância do HUB</span><span class="badge">${info.distancia_km} km</span></div>
          <div class="route"><b>Rota ótima (Dijkstra):</b><br>${rota}</div>
        </div>`;

      // destacar arestas da rota
      const caminho = info.rota;
      const idsRota = new Set();
      for (let i = 0; i < caminho.length - 1; i++) {
        edges.forEach(ed => {
          if ((ed.from === caminho[i] && ed.to === caminho[i+1]) ||
              (ed.to === caminho[i] && ed.from === caminho[i+1]))
            idsRota.add(`${ed.from}-${ed.to}`);
        });
      }
      visData.edges.forEach(ed => {
        const onPath = idsRota.has(`${ed.from}-${ed.to}`);
        visData.edges.update({ id: ed.id,
          color: { color: onPath ? '#f59e0b' : '#64748b' },
          width: onPath ? 4 : 1.5 });
      });
    });
  }
});
