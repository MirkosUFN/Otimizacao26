```python
import json
import networkx as nx
import folium

# 1. Carregar os dados da fatura
with open('fatura_geo.json', 'r', encoding='utf-8') as f:
    dados = json.load(f)

cliente = dados["cliente"]
transacoes = dados["transacoes"]

# 2. Inicializar o Grafo Estrutural
G = nx.Graph()
G.add_node(cliente["id"], pos=(cliente["lat"], cliente["lon"]), tipo="cliente")

for t in transacoes:
    # Adiciona os estabelecimentos como nós
    G.add_node(t["id"], nome=t["nome"], pos=(t["lat"], t["lon"]), valor=t["valor_total"], qtd=t["qtd_transacoes"], tipo="estabelecimento")
    # Adiciona a relação de compra como aresta
    G.add_edge(cliente["id"], t["id"], weight=t["qtd_transacoes"])

# 3. Criar o Mapa Base centrado no Cliente
mapa = folium.Map(location=[cliente["lat"], cliente["lon"]], zoom_start=7, tiles="CartoDB dark_matter")

# 4. Plotar os Nós e Arestas no Mapa
# Plotar as arestas (linhas conectando o cliente aos gastos)
for origem, destino, dados_aresta in G.edges(data=True):
    pos_origem = G.nodes[origem]['pos']
    pos_destino = G.nodes[destino]['pos']
    peso = dados_aresta['weight']
    
    # A linha fica mais grossa dependendo de quantas transações foram feitas lá
    folium.PolyLine(
        locations=[pos_origem, pos_destino],
        color="#00ffcc",
        weight=peso * 1.5,
        opacity=0.6
    ).add_to(mapa)

# Plotar os nós (marcadores)
for no, dados_no in G.nodes(data=True):
    if dados_no["tipo"] == "cliente":
        folium.CircleMarker(
            location=dados_no['pos'],
            radius=10,
            color="white",
            fill=True,
            fill_color="white",
            popup="Sua Localização Base"
        ).add_to(mapa)
    else:
        # O tamanho do círculo reflete o valor total gasto
        raio = max(5, dados_no['valor'] / 50)
        folium.CircleMarker(
            location=dados_no['pos'],
            radius=raio,
            color="#ff0066",
            fill=True,
            fill_color="#ff0066",
            fill_opacity=0.7,
            popup=f"{dados_no['nome']}<br>Transações: {dados_no['qtd']}<br>Total: R$ {dados_no['valor']:.2f}"
        ).add_to(mapa)

# 5. Salvar o arquivo HTML
mapa.save('grafo_mapa_gastos.html')
print("Grafo geoespacial gerado! Abra o arquivo 'grafo_mapa_gastos.html' no navegador.")