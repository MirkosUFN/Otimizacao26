# -*- coding: utf-8 -*-
import os
import networkx as nx
import webbrowser

def gerar_relatorio_html_pdf():
    print("=== PROCESSANDO DADOS DO GRAFO E GERANDO RELATÓRIO ===")
    
    # 1. BASE DE DADOS (Estrutura de Conexões)
    conexoes = [
        ("Porto Alegre", "Caxias do Sul", 120),
        ("Porto Alegre", "Osorio", 100),
        ("Porto Alegre", "Pelotas", 260),
        ("Porto Alegre", "Santa Maria", 290),
        ("Caxias do Sul", "Passo Fundo", 170),
        ("Passo Fundo", "Erechim", 80),
        ("Passo Fundo", "Santa Maria", 290),
        ("Santa Maria", "Uruguaiana", 360),
        ("Santa Maria", "Pelotas", 290),
        ("Pelotas", "Rio Grande", 60),
        ("Osorio", "Torres", 90),
        ("Passo Fundo", "Cruz Alta", 130),
        ("Cruz Alta", "Santa Maria", 130),
        ("Uruguaiana", "Itai", 110),
        ("Itai", "Sao Borja", 80),
        ("Sao Borja", "Sao Luiz Gonzaga", 70),
        ("Sao Luiz Gonzaga", "Santo Angelo", 70),
        ("Santo Angelo", "Cruz Alta", 110)
    ]

    G = nx.Graph()
    for c1, c2, dist in conexoes:
        G.add_edge(c1, c2, weight=dist)

    # 2. CALCULAR MENOR CAMINHO (Exemplo Padrão: Rio Grande -> Caxias do Sul)
    origem = "Rio Grande"
    destino = "Caxias do Sul"
    caminho = nx.dijkstra_path(G, source=origem, target=destino, weight='weight')
    distancia = nx.dijkstra_path_length(G, source=origem, target=destino, weight='weight')

    # 3. CÁLCULO DO GRAU MÁXIMO DE SEPARAÇÃO (Diâmetro por Saltos)
    comprimentos_saltos = dict(nx.all_pairs_shortest_path_length(G))
    
    diametro_saltos = 0
    par_mais_distante = (None, None)
    
    for u in comprimentos_saltos:
        for v in comprimentos_saltos[u]:
            if comprimentos_saltos[u][v] > diametro_saltos:
                diametro_saltos = comprimentos_saltos[u][v]
                par_mais_distante = (u, v)
                
    caminho_extremo = nx.shortest_path(G, source=par_mais_distante[0], target=par_mais_distante[1])

    # 4. ESTRUTURAÇÃO DO DOCUMENTO (HTML formatado para Impressão A4)
    html_print_content = f'''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Relatório Estatístico do Grafo RS</title>
<style>
    @media print {{
        body {{ -webkit-print-color-adjust: exact; }}
    }}
    body {{
        font-family: Arial, sans-serif;
        color: #2c3e50;
        line-height: 1.6;
        max-width: 800px;
        margin: 0 auto;
        padding: 40px 20px;
    }}
    .header {{
        background-color: #2c3e50;
        color: white;
        padding: 30px;
        border-radius: 6px;
        margin-bottom: 30px;
    }}
    .header h1 {{ margin: 0; font-size: 24pt; color: #f39c12; }}
    .header p {{ margin: 5px 0 0 0; font-size: 12pt; opacity: 0.9; }}
    
    h2 {{
        color: #2980b9;
        font-size: 16pt;
        border-bottom: 2px solid #3498db;
        padding-bottom: 5px;
        margin-top: 35px;
    }}
    .painel {{
        background-color: #f8f9fa;
        border-left: 6px solid #e67e22;
        padding: 18px;
        margin: 20px 0;
        font-size: 11pt;
        border-radius: 4px;
    }}
    .destaque-box {{
        background-color: #fdfaf2;
        border-left: 6px solid #f1c40f;
        padding: 18px;
        margin: 20px 0;
        font-size: 11pt;
        border-radius: 4px;
    }}
    .caminho-box {{
        font-size: 13pt;
        color: #d35400;
        font-weight: bold;
        margin: 12px 0;
        font-family: "Courier New", Courier, monospace;
    }}
    table {{
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }}
    th {{
        background-color: #34495e;
        color: white;
        padding: 12px;
        font-size: 10pt;
        text-align: left;
    }}
    td {{
        padding: 10px;
        border-bottom: 1px solid #bdc3c7;
        font-size: 10pt;
    }}
    tr:nth-child(even) {{ background-color: #fdfdfd; }}
    
    .esquema-grafo {{
        background-color: #fafbfc;
        border: 1px dashed #7f8c8d;
        padding: 15px;
        margin-top: 20px;
        border-radius: 4px;
    }}
</style>
</head>
<body>

<div class="header">
    <h1>GPS Virtual do Rio Grande do Sul</h1>
    <p>Algoritmo de Dijkstra & Análise de Topologia Estrutural</p>
</div>

<h2>1. Definição do Problema (2 pts)</h2>
<p>O projeto aborda a modelagem de malhas rodoviárias intermunicipais por meio de grafos não direcionados e ponderados. O objetivo central consiste em computar rotas ótimas de custo mínimo e determinar métricas topológicas globais cruciais para a eficiência do sistema logístico.</p>

<h2>2. Coleta e Base de Dados do Grafo (4 pts)</h2>
<p>Abaixo estão as conexões e distâncias computadas diretamente na estrutura de dados do algoritmo:</p>

<table>
    <thead>
        <tr>
            <th>Cidade de Origem</th>
            <th>Cidade de Destino</th>
            <th>Distância Regulamentar (Peso)</th>
        </tr>
    </thead>
    <tbody>
'''
    for u, v, data in G.edges(data=True):
        html_print_content += f"        <tr><td>{u}</td><td>{v}</td><td>{data['weight']} km</td></tr>\n"

    html_print_content += f'''    </tbody>
</table>

<h2>3. Cálculo de Menor Caminho (4 pts)</h2>
<div class="painel">
    <strong>Origem da Rota:</strong> {origem}<br>
    <strong>Destino Final:</strong> {destino}<br>
    <div class="caminho-box">Trajeto Otimizado: {" &rarr; ".join(caminho)}</div>
    <strong>Distância Mínima Acumulada (Dijkstra):</strong> {distancia} km
</div>

<h2>4. Análise Estrutural: Grau Máximo de Separação</h2>
<p>O <strong>Grau Máximo de Separação</strong> (academicamente tratado como o <em>Diâmetro Geodésico do Grafo</em>) define o limite superior de passos necessários para transitar entre quaisquer dois pontos isolados na rede viária calculada.</p>

<div class="destaque-box">
    <strong>Grau Máximo de Separação Encontrado:</strong> {diametro_saltos} saltos (arestas)<br>
    <strong>Vértices Extremos (Maior Afastamento Lógico):</strong> {par_mais_distante[0]} &harr; {par_mais_distante[1]}<br>
    <div class="caminho-box" style="color: #2980b9;">Caminho Crítico Encontrado:<br> 
    {" &rarr; ".join(caminho_extremo)}</div>
    <p style="margin: 8px 0 0 0; font-size: 10pt; color: #7f8c8d; line-height: 1.4;">
        <em>Significado Prático: Sob a ótica de conectividade, nenhuma cidade mapeada dista mais de {diametro_saltos} conexões intermediárias de qualquer outro ponto geométrico da rede viária do estado.</em>
    </p>
</div>

<h2>5. Validação de Consistência</h2>
<div class="esquema-grafo">
    <strong>Nós Processados Corretamente ({len(G.nodes())} Vértices Ativos):</strong><br>
    <span style="font-size: 9.5pt; color: #555; font-family: monospace;">{", ".join(sorted(list(G.nodes())))}</span>
</div>

</body>
</html>
'''
    
    # Salva o arquivo HTML estático localmente
    nome_arquivo = "relatorio_grafo_rs.html"
    with open(nome_arquivo, "w", encoding="utf-8") as f:
        f.write(html_print_content)
        
    print(f"\n[+] Arquivo '{nome_arquivo}' gerado com sucesso na pasta!")
    print("[+] Abrindo no navegador para salvar em PDF...")
    
    # Abre o navegador automaticamente
    caminho_absoluto = os.path.abspath(nome_arquivo)
    webbrowser.open("file://" + caminho_absoluto)

if __name__ == "__main__":
    gerar_relatorio_html_pdf()