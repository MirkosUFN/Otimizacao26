"""
Problema escolhido: OTIMIZACAO DE ROTAS DE ENTREGA
---------------------------------------------------
Uma distribuidora de vinhos & queijos sediada em Tupancireta (RS) precisa
entregar pedidos em cidades da regiao. Modelamos a malha rodoviaria como um
GRAFO PONDERADO (cidades = nos, estradas = arestas, distancia em km = peso) e
aplicamos o algoritmo de DIJKSTRA para encontrar o MENOR CAMINHO do centro de
distribuicao ate cada cidade atendida.

Base de dados: distancias rodoviarias APROXIMADAS entre municipios do noroeste
do Rio Grande do Sul (coletadas/estimadas a partir de mapas rodoviarios; os
valores servem ao exercicio academico e nao a navegacao real).
"""
from models.cidade import Cidade
from models.rede_entregas import RedeEntregas
from exporters.json_exporter import JSONExporter
import os

def main():
    rede = RedeEntregas()

    # (id, nome, populacao_aprox, x, y, hub)  -- x/y para layout (long/lat aprox)
    cidades = [
        ("c1",  "Tupancireta",        22000, -53.83, -29.08, True),
        ("c2",  "Julio de Castilhos", 20000, -53.68, -29.23, False),
        ("c3",  "Santa Maria",       280000, -53.81, -29.68, False),
        ("c4",  "Cruz Alta",          62000, -53.60, -28.64, False),
        ("c5",  "Ijui",               83000, -53.91, -28.39, False),
        ("c6",  "Panambi",            45000, -53.50, -28.29, False),
        ("c7",  "Santo Angelo",       77000, -54.26, -28.30, False),
        ("c8",  "Santa Rosa",         69000, -54.48, -27.87, False),
        ("c9",  "Carazinho",          62000, -52.79, -28.28, False),
        ("c10", "Passo Fundo",       205000, -52.41, -28.26, False),
        ("c11", "Santiago",           50000, -54.87, -29.19, False),
        ("c12", "Sao Borja",          61000, -56.00, -28.66, False),
    ]
    print("--- Cadastrando cidades ---")
    for cid, nome, pop, x, y, hub in cidades:
        rede.add_cidade(Cidade(cid, nome, pop, x, y, hub))
        print(f"  {nome}{' (HUB)' if hub else ''}")

    # (cidade_a, cidade_b, distancia_km aproximada por rodovia)
    trechos = [
        ("c1", "c2", 55),    # Tupancireta - Julio de Castilhos
        ("c1", "c4", 58),    # Tupancireta - Cruz Alta
        ("c1", "c11", 95),   # Tupancireta - Santiago
        ("c2", "c3", 50),    # Julio de Castilhos - Santa Maria
        ("c4", "c5", 70),    # Cruz Alta - Ijui
        ("c4", "c6", 50),    # Cruz Alta - Panambi
        ("c4", "c9", 95),    # Cruz Alta - Carazinho
        ("c5", "c6", 35),    # Ijui - Panambi
        ("c5", "c7", 58),    # Ijui - Santo Angelo
        ("c7", "c8", 60),    # Santo Angelo - Santa Rosa
        ("c9", "c10", 60),   # Carazinho - Passo Fundo
        ("c11", "c12", 95),  # Santiago - Sao Borja
        ("c11", "c3", 160),  # Santiago - Santa Maria
        ("c7", "c12", 110),  # Santo Angelo - Sao Borja
    ]
    print("\n--- Cadastrando trechos rodoviarios ---")
    for a, b, km in trechos:
        rede.add_trecho(a, b, km)
        print(f"  {a} <-> {b} : {km} km")

    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out = os.path.join(base_dir, "data", "grafo_entregas.json")

    print("\n--- Exportando grafo + menores caminhos (Dijkstra) ---")
    exporter = JSONExporter(out)
    data = exporter.export(rede)

    nomes = {n["id"]: n["nome"] for n in data["nodes"]}
    print("\n--- Menores caminhos a partir do HUB (Tupancireta) ---")
    for cid, info in sorted(data["menores_caminhos"].items(),
                            key=lambda kv: kv[1]["distancia_km"]):
        rota = " -> ".join(nomes[r] for r in info["rota"])
        print(f"  {nomes[cid]:<20} {info['distancia_km']:>6.1f} km   [{rota}]")

    m = data["metrics"]
    print("\n--- GRAU DE SEPARACAO (em saltos / arestas) ---")
    print(f"  Grau MAXIMO de separacao (diametro): {m['grau_max_separacao']} saltos")
    print(f"  Grau MEDIO de separacao            : {m['grau_medio_separacao']} saltos")
    print(f"  Cidades perifericas: {', '.join(nomes[n] for n in m['nos_perifericos'])}")
    print("  Pares que atingem o grau maximo:")
    for p in m["pares_max_separacao"]:
        cam = " -> ".join(nomes[c] for c in p["caminho"])
        print(f"    {nomes[p['de']]} <-> {nomes[p['para']]} ({p['saltos']} saltos): {cam}")

if __name__ == "__main__":
    main()
