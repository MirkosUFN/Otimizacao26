import networkx as nx
from .cidade import Cidade


class RedeEntregas:
    """
    Grafo ponderado e nao-direcionado.
      - nos  = cidades
      - aresta = trecho rodoviario; peso = distancia em km
    Resolve o problema do MENOR CAMINHO (Dijkstra) a partir do hub.
    """

    def __init__(self):
        self.grafo = nx.Graph()
        self.hub_id = None

    def add_cidade(self, cidade: Cidade):
        self.grafo.add_node(cidade.cidade_id, **cidade.to_dict())
        if cidade.hub:
            self.hub_id = cidade.cidade_id

    def add_trecho(self, id_a: str, id_b: str, distancia_km: float):
        if not (self.grafo.has_node(id_a) and self.grafo.has_node(id_b)):
            raise ValueError(f"Cidades {id_a} e {id_b} precisam existir antes de ligar.")
        self.grafo.add_edge(id_a, id_b, distancia=distancia_km)

    # ---------- consultas ----------
    def get_nos(self) -> list[dict]:
        return [data for _, data in self.grafo.nodes(data=True)]

    def get_arestas(self) -> list[dict]:
        return [{"origem": u, "destino": v, "distancia": d["distancia"]}
                for u, v, d in self.grafo.edges(data=True)]

    def menores_caminhos(self) -> dict:
        """Dijkstra do hub para todas as cidades."""
        if self.hub_id is None:
            raise ValueError("Nenhum hub definido.")
        dist = nx.single_source_dijkstra_path_length(self.grafo, self.hub_id, weight="distancia")
        rotas = nx.single_source_dijkstra_path(self.grafo, self.hub_id, weight="distancia")
        resultado = {}
        for cid in self.grafo.nodes():
            resultado[cid] = {
                "distancia_km": round(dist[cid], 1),
                "rota": rotas[cid],
            }
        return resultado

    def grau_separacao(self) -> dict:
        """
        Grau de separacao = numero de SALTOS (arestas) do menor caminho entre
        dois nos, ignorando a distancia em km (conceito dos 'graus de separacao').
          - grau_max_separacao  = diametro do grafo (maior separacao possivel)
          - grau_medio          = media das separacoes entre todos os pares
          - pares_max           = pares de cidades que atingem o diametro
          - nos_perifericos     = nos cuja excentricidade == diametro
        """
        if not nx.is_connected(self.grafo):
            comp = max(nx.connected_components(self.grafo), key=len)
            g = self.grafo.subgraph(comp)
        else:
            g = self.grafo

        diametro = nx.diameter(g)
        medio = nx.average_shortest_path_length(g)
        ecc = nx.eccentricity(g)
        perifericos = [n for n, e in ecc.items() if e == diametro]

        spl = dict(nx.all_pairs_shortest_path_length(g))
        pares = []
        for u in g.nodes():
            for v in g.nodes():
                if u < v and spl[u][v] == diametro:
                    caminho = nx.shortest_path(g, u, v)
                    pares.append({"de": u, "para": v, "saltos": diametro, "caminho": caminho})

        return {
            "grau_max_separacao": diametro,
            "grau_medio_separacao": round(medio, 2),
            "nos_perifericos": perifericos,
            "pares_max_separacao": pares,
        }

    def get_metricas(self) -> dict:
        cam = self.menores_caminhos()
        distancias = [v["distancia_km"] for k, v in cam.items() if k != self.hub_id]
        sep = self.grau_separacao()
        return {
            "n_cidades": self.grafo.number_of_nodes(),
            "n_trechos": self.grafo.number_of_edges(),
            "hub": self.grafo.nodes[self.hub_id]["nome"],
            "cidade_mais_distante": max(cam.items(), key=lambda kv: kv[1]["distancia_km"])[0],
            "dist_media_km": round(sum(distancias) / len(distancias), 1) if distancias else 0,
            "dist_max_km": max(distancias) if distancias else 0,
            **sep,
        }
