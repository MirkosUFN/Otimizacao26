# Otimização de Rotas de Entrega — Grafos 🍷🧀

Projeto acadêmico (Otimização Computacional). Modela a malha rodoviária do
noroeste do RS como um **grafo ponderado** e resolve o **menor caminho**
(algoritmo de **Dijkstra**) de um centro de distribuição (HUB em Tupanciretã)
até cada cidade atendida por uma distribuidora de vinhos & queijos.

- **Nós** = cidades  ·  **Arestas** = trechos rodoviários  ·  **Peso** = distância (km)
- **Back-end** Python (`networkx`) calcula as rotas e exporta um JSON.
- **Front-end** HTML/JS (`vis-network`) mostra o grafo interativo (clique numa
  cidade para ver a rota ótima; alterna modo claro/escuro).
- **PDF** (`matplotlib`) com a visualização estática do grafo + tabela de rotas.

## Estrutura
```
grafo-Romeo/
├── src/
│   ├── main.py                  # base de dados + execução
│   ├── models/cidade.py         # nó do grafo
│   ├── models/rede_entregas.py  # grafo + Dijkstra (networkx)
│   └── exporters/json_exporter.py
├── data/grafo_entregas.json     # dados exportados
├── frontend/                    # index.html, app.js, style.css (visualização)
├── gerar_grafo_pdf.py           # gera o PDF
├── grafo_entregas.pdf           # visualização em PDF
└── requirements.txt
```

## Como executar
```bash
python3 -m venv venv && source venv/bin/activate   # opcional
pip install -r requirements.txt
cd src && python main.py            # gera data/grafo_entregas.json
python ../gerar_grafo_pdf.py        # gera o PDF (opcional)
```
Visualização interativa: basta abrir `frontend/index.html` no navegador
(os dados já vêm embutidos, não precisa de servidor local).

## Problema, dados e resultado
- **Problema:** menor caminho em grafo ponderado (roteirização de entregas).
- **Dados:** 12 cidades e 14 trechos rodoviários do noroeste do RS, com
  distâncias rodoviárias **aproximadas** (uso acadêmico).
- **Resultado:** rotas ótimas do HUB para todas as cidades (ex.: Santa Rosa é a
  mais distante, 246 km, via Cruz Alta → Ijuí → Santo Ângelo).

## Grau de separação (atividade complementar)
Determina o **grau máximo de separação** entre os nós = **diâmetro do grafo**,
medido em **número de saltos (arestas)**, conceito análogo aos "graus de
separação" (independe da distância em km). Calculado com `networkx`
(`nx.diameter`, `nx.eccentricity`).

- **Grau máximo de separação (diâmetro): 5 saltos**
- Grau médio de separação: 2,59 saltos
- Cidades periféricas: Júlio de Castilhos, Santa Maria, Santa Rosa, Passo Fundo, São Borja
- Pares que atingem o máximo (5 saltos), ex.: Júlio de Castilhos ↔ Santa Rosa
  (Júlio de Castilhos → Tupanciretã → Cruz Alta → Ijuí → Santo Ângelo → Santa Rosa)

No frontend, o cabeçalho mostra os graus máximo/médio e o painel lateral lista
os pares mais distantes (clique destaca o caminho no grafo). No PDF, as páginas
3 e 4 trazem a visualização e a tabela desses pares.
