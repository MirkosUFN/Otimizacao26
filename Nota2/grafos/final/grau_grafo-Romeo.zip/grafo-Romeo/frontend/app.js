document.addEventListener('DOMContentLoaded', () => {

  // ----- alternar tema -----
  const themeBtn = document.getElementById('theme-toggle');
  themeBtn.addEventListener('click', () => {
    const root = document.documentElement;
    root.classList.toggle('light-theme');
    const isLight = root.classList.contains('light-theme');
    themeBtn.innerText = isLight ? '🌙 Modo Escuro' : '☀️ Modo Claro';
    if (window.networkInstance) {
      const c = getComputedStyle(document.body).getPropertyValue('--txt');
      window.networkInstance.setOptions({ nodes: { font: { color: c } } });
    }
  });

  // ----- carregar dados (arquivo externo OU embutido) -----
  async function carregar() {
    try {
      const resp = await fetch('../data/grafo_entregas.json');
      if (!resp.ok) throw new Error('sem servidor');
      return await resp.json();
    } catch (e) {
      if (window.GRAFO_DATA) return window.GRAFO_DATA;  // fallback embutido
      throw e;
    }
  }

  carregar().then(initGraph).catch(err => {
    document.getElementById('network-stats').innerHTML =
      `<span style="color:#ef4444">Erro ao carregar dados: ${err.message}</span>`;
  });

  function initGraph(data) {
    // estatisticas
    const m = data.metrics;
    document.getElementById('network-stats').innerHTML = `
      <div class="stat"><div class="v">${m.n_cidades}</div><div class="l">Cidades</div></div>
      <div class="stat"><div class="v">${m.n_trechos}</div><div class="l">Trechos</div></div>
      <div class="stat hl"><div class="v">${m.grau_max_separacao}</div><div class="l">Grau máx. separação</div></div>
      <div class="stat"><div class="v">${m.grau_medio_separacao}</div><div class="l">Grau médio separação</div></div>
      <div class="stat"><div class="v">${m.dist_media_km} km</div><div class="l">Dist. média</div></div>`;

    const nomes = {};
    data.nodes.forEach(n => nomes[n.id] = n.nome);

    // nos
    const nodes = data.nodes.map(n => {
      const d = data.menores_caminhos[n.id].distancia_km;
      return {
        id: n.id,
        label: `${n.nome}\n${d} km`,
        x: n.x * 120, y: -n.y * 120,
        value: Math.sqrt(n.populacao),
        color: n.hub
          ? { background: '#f59e0b', border: '#b45309' }
          : { background: '#b91c1c', border: '#7f1d1d' },
        font: { color: getComputedStyle(document.body).getPropertyValue('--txt'), size: 16 },
      };
    });

    // arestas
    const edges = data.edges.map(e => ({
      from: e.origem, to: e.destino,
      label: `${e.distancia} km`,
      font: { size: 11, color: '#94a3b8', strokeWidth: 0 },
      color: { color: '#64748b', highlight: '#f59e0b' },
      width: 1.5,
    }));

    const container = document.getElementById('mynetwork');
    const visData = { nodes: new vis.DataSet(nodes), edges: new vis.DataSet(edges) };
    const options = {
      physics: false,
      nodes: { shape: 'dot', scaling: { min: 12, max: 36 }, borderWidth: 2 },
      edges: { smooth: { type: 'continuous' } },
      interaction: { hover: true, tooltipDelay: 100 },
    };
    window.networkInstance = new vis.Network(container, visData, options);

    // funcao reutilizavel: destaca um caminho (lista de ids) no grafo
    function destacarCaminho(caminho, cor) {
      const idsRota = new Set();
      for (let i = 0; i < caminho.length - 1; i++) {
        edges.forEach(ed => {
          if ((ed.from === caminho[i] && ed.to === caminho[i+1]) ||
              (ed.to === caminho[i] && ed.from === caminho[i+1]))
            idsRota.add(`${ed.from}-${ed.to}`);
        });
      }
      visData.edges.forEach(ed => {
        const onPath = idsRota.has(`${ed.from}-${ed.to}`);
        visData.edges.update({ id: ed.id,
          color: { color: onPath ? cor : '#64748b' },
          width: onPath ? 4 : 1.5 });
      });
    }

    // ----- painel: grau maximo de separacao -----
    const pares = m.pares_max_separacao;
    let painel = `<h2>Grau de separação</h2>
      <div class="detail-card">
        <div class="row"><span>Grau MÁXIMO (diâmetro)</span><span class="badge">${m.grau_max_separacao} saltos</span></div>
        <div class="row"><span>Grau médio</span><span>${m.grau_medio_separacao} saltos</span></div>
        <div class="route"><b>Pares mais distantes</b> (clique para destacar):</div>`;
    pares.forEach((p, i) => {
      painel += `<button class="pair-btn" data-i="${i}">${nomes[p.de]} ↔ ${nomes[p.para]}</button>`;
    });
    painel += `</div>`;
    document.getElementById('user-details').innerHTML = painel;

    document.querySelectorAll('.pair-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const p = pares[btn.dataset.i];
        destacarCaminho(p.caminho, '#22c55e');
        const cam = p.caminho.map(c => nomes[c]).join(' → ');
        let info = document.getElementById('pair-info');
        if (!info) {
          info = document.createElement('div');
          info.id = 'pair-info'; info.className = 'route';
          document.querySelector('#user-details .detail-card').appendChild(info);
        }
        info.innerHTML = `<br><b>${p.saltos} saltos:</b><br>${cam}`;
      });
    });

    // clique numa cidade -> mostra rota otima do HUB (Dijkstra), em laranja
    window.networkInstance.on('click', params => {
      if (!params.nodes.length) return;
      const id = params.nodes[0];
      const node = data.nodes.find(n => n.id === id);
      const rotaInfo = data.menores_caminhos[id];
      const rota = rotaInfo.rota.map(r => nomes[r]).join(' → ');
      document.getElementById('user-details').innerHTML = `
        <h2>Detalhes da cidade</h2>
        <div class="detail-card">
          <div class="name">${node.nome}${node.hub ? ' ⭐ (HUB)' : ''}</div>
          <div class="row"><span>População</span><span>${node.populacao.toLocaleString('pt-BR')}</span></div>
          <div class="row"><span>Distância do HUB (km)</span><span class="badge">${rotaInfo.distancia_km} km</span></div>
          <div class="row"><span>Separação do HUB (saltos)</span><span>${rotaInfo.rota.length - 1}</span></div>
          <div class="route"><b>Rota ótima (Dijkstra):</b><br>${rota}</div>
        </div>`;
      destacarCaminho(rotaInfo.rota, '#f59e0b');
    });
  }
});
