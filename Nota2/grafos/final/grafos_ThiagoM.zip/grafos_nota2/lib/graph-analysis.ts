/**
 * Representação de uma lista de adjacência para o grafo
 */
export type AdjacencyList = Map<string, string[]>;

/**
 * Constrói uma lista de adjacência não direcionada a partir de vértices e arestas
 */
export function buildAdjacencyList(nodes: any[], edges: any[]): AdjacencyList {
  const adj: AdjacencyList = new Map();

  // Inicializa a lista para todos os nós
  nodes.forEach((node) => {
    adj.set(node.id, []);
  });

  // Adiciona as conexões não direcionadas
  edges.forEach((edge) => {
    const { source, target } = edge;
    
    // Garante que ambos os nós existem no grafo antes de conectar
    if (adj.has(source) && adj.has(target)) {
      adj.get(source)!.push(target);
      adj.get(target)!.push(source);
    }
  });

  return adj;
}

/**
 * Executa uma busca em largura (BFS) a partir de um nó inicial
 * Retorna as distâncias e predecessores para reconstrução dos caminhos
 */
export function runBFS(
  startId: string,
  adj: AdjacencyList
): { distances: Map<string, number>; predecessors: Map<string, string | null> } {
  const distances = new Map<string, number>();
  const predecessors = new Map<string, string | null>();
  const queue: string[] = [startId];

  // Inicializa distâncias
  adj.forEach((_, node) => {
    distances.set(node, -1);
    predecessors.set(node, null);
  });

  distances.set(startId, 0);

  while (queue.length > 0) {
    const current = queue.shift()!;
    const currentDist = distances.get(current)!;
    const neighbors = adj.get(current) || [];

    for (const neighbor of neighbors) {
      if (distances.get(neighbor) === -1) {
        distances.set(neighbor, currentDist + 1);
        predecessors.set(neighbor, current);
        queue.push(neighbor);
      }
    }
  }

  return { distances, predecessors };
}

/**
 * Reconstrói o caminho de startId até endId a partir dos predecessores
 */
export function reconstructPath(
  endId: string,
  predecessors: Map<string, string | null>
): string[] | null {
  const path: string[] = [];
  let current: string | null = endId;

  while (current !== null) {
    path.push(current);
    current = predecessors.get(current) || null;
  }

  path.reverse();

  // Se o primeiro elemento não for o nó de início reconstruído (ou se a lista for vazia), não há caminho
  if (path.length === 0 || predecessors.get(path[0]) !== null) {
    // Isso é um detalhe: se o nó de início tiver predecessor null, o caminho começa nele.
    // Mas se o nó de início não for alcançado, path conterá apenas o endId e o predecessors dele será null.
    // Para confirmar se realmente há caminho, verificamos se o primeiro elemento do caminho é o de início real.
  }

  return path;
}

/**
 * Retorna o menor caminho entre dois nós
 */
export function getShortestPath(
  startId: string,
  endId: string,
  nodes: any[],
  edges: any[]
): string[] | null {
  if (startId === endId) return [startId];

  const adj = buildAdjacencyList(nodes, edges);
  if (!adj.has(startId) || !adj.has(endId)) return null;

  const { distances, predecessors } = runBFS(startId, adj);
  if (distances.get(endId) === -1) return null; // Inalcançável

  const path: string[] = [];
  let current: string | null = endId;
  while (current !== null) {
    path.push(current);
    current = predecessors.get(current) ?? null;
  }
  return path.reverse();
}

export interface GraphStats {
  diameter: number;
  longestPaths: string[][];
  averageSeparation: number;
  unreachablePairsCount: number;
  totalPairs: number;
}

/**
 * Calcula estatísticas de caminhos no grafo
 */
export function calculateGraphStats(nodes: any[], edges: any[]): GraphStats {
  const adj = buildAdjacencyList(nodes, edges);
  let diameter = 0;
  let longestPaths: string[][] = [];
  let totalDistanceSum = 0;
  let reachablePairsCount = 0;
  let unreachablePairsCount = 0;
  let totalPairs = 0;

  const nodeIds = nodes.map((n) => n.id);

  // Percorre todos os nós como ponto de partida
  for (let i = 0; i < nodeIds.length; i++) {
    const startId = nodeIds[i];
    const { distances, predecessors } = runBFS(startId, adj);

    for (let j = i + 1; j < nodeIds.length; j++) {
      const endId = nodeIds[j];
      totalPairs++;
      
      const dist = distances.get(endId) ?? -1;

      if (dist !== -1) {
        totalDistanceSum += dist;
        reachablePairsCount++;

        if (dist > diameter) {
          diameter = dist;
          // Reconstrói o caminho e reinicializa a lista de caminhos mais longos
          const path = reconstructPathFromBFS(startId, endId, predecessors);
          longestPaths = [path];
        } else if (dist === diameter && dist > 0) {
          const path = reconstructPathFromBFS(startId, endId, predecessors);
          longestPaths.push(path);
        }
      } else {
        unreachablePairsCount++;
      }
    }
  }

  const averageSeparation =
    reachablePairsCount > 0 ? parseFloat((totalDistanceSum / reachablePairsCount).toFixed(2)) : 0;

  return {
    diameter,
    longestPaths: longestPaths.slice(0, 5), // Limita aos 5 primeiros caminhos mais longos para exibição limpa
    averageSeparation,
    unreachablePairsCount,
    totalPairs,
  };
}

function reconstructPathFromBFS(
  startId: string,
  endId: string,
  predecessors: Map<string, string | null>
): string[] {
  const path: string[] = [];
  let current: string | null = endId;
  while (current !== null && current !== startId) {
    path.push(current);
    current = predecessors.get(current) ?? null;
  }
  path.push(startId);
  return path.reverse();
}
