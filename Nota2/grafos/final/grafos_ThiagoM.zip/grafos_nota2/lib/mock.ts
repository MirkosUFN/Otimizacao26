export const mockDatasets: Record<string, { nodes: any[]; edges: any[] }> = {
  eminem: generateMockGraph("Eminem", [
    "Dr. Dre",
    "50 Cent",
    "Snoop Dogg",
    "Ice Cube",
    "Kendrick Lamar",
    "Jay-Z",
    "Nas",
    "Tupac",
    "The Notorious B.I.G.",
    "J. Cole",
    "Drake",
    "Lil Wayne",
    "Kanye West",
    "Rihanna",
    "Nicki Minaj",
  ]),
  anitta: generateMockGraph("Anitta", [
    "Ludmilla",
    "Pabllo Vittar",
    "Luísa Sonza",
    "Lexa",
    "Gloria Groove",
    "Pedro Sampaio",
    "Kevinho",
    "MC Rebecca",
    "J Balvin",
    "Maluma",
    "Becky G",
    "Natti Natasha",
    "Karol G",
    "Rosalía",
    "MC Kevin o Chris",
  ]),
  soad: generateMockGraph("System of a Down", [
    "Korn",
    "Slipknot",
    "Deftones",
    "Disturbed",
    "Avenged Sevenfold",
    "Linkin Park",
    "Limp Bizkit",
    "Papa Roach",
    "Godsmack",
    "Mudvayne",
    "Rammstein",
    "Tool",
    "Nine Inch Nails",
    "Marilyn Manson",
    "Rob Zombie",
  ]),
}

function generateMockGraph(centralName: string, relatedNames: string[]) {
  const nodesMap = new Map<string, any>()
  const edges: any[] = []

  // Add central node
  nodesMap.set(centralName, {
    id: centralName,
    data: { label: centralName, isCentral: true, image: null },
  })

  // Distribute relatedNames into levels
  // Level 1: 3 nodes connected directly to Central
  // Level 2: 4 nodes connected to Level 1 nodes
  // Level 3: 4 nodes connected to Level 2 nodes
  // Level 4: remaining nodes connected to Level 3 nodes
  const levels: string[][] = [[centralName]];
  const levelSizes = [3, 4, 4, 4];
  let nameIndex = 0;

  for (const size of levelSizes) {
    if (nameIndex >= relatedNames.length) break;
    const levelNodes: string[] = [];
    const limit = Math.min(nameIndex + size, relatedNames.length);
    for (let i = nameIndex; i < limit; i++) {
      levelNodes.push(relatedNames[i]);
    }
    levels.push(levelNodes);
    nameIndex = limit;
  }

  // Add remaining nodes to the last level if any
  if (nameIndex < relatedNames.length) {
    levels[levels.length - 1].push(...relatedNames.slice(nameIndex));
  }

  // Create nodes in map
  for (let l = 1; l < levels.length; l++) {
    levels[l].forEach((name) => {
      nodesMap.set(name, {
        id: name,
        data: { label: name, isCentral: false, image: null },
      })
    })
  }

  // Connect Level L nodes to Level L-1 nodes
  for (let l = 1; l < levels.length; l++) {
    const parentLevel = levels[l - 1];
    const currentLevelNodes = levels[l];

    currentLevelNodes.forEach((name, idx) => {
      // Deterministically select a parent from the previous level
      const parentIdx = (name.charCodeAt(0) + idx) % parentLevel.length;
      const parentName = parentLevel[parentIdx];

      edges.push({
        id: `${parentName}-${name}`,
        source: parentName,
        target: name,
      })
    })
  }

  // Add some horizontal/cross connections between nodes in the same level
  // to form communities without collapsing the diameter too much
  for (let l = 1; l < levels.length; l++) {
    const levelNodes = levels[l];
    for (let i = 0; i < levelNodes.length; i++) {
      for (let j = i + 1; j < levelNodes.length; j++) {
        // Deterministic pseudo-random
        const hash = (levelNodes[i].charCodeAt(0) + levelNodes[j].charCodeAt(0)) % 10;
        if (hash < 2) { // 20% chance
          edges.push({
            id: `${levelNodes[i]}-${levelNodes[j]}`,
            source: levelNodes[i],
            target: levelNodes[j],
          })
        }
      }
    }
  }

  return {
    nodes: Array.from(nodesMap.values()),
    edges,
  }
}

export function getMockNetwork(query: string) {
  const normalizedQuery = query.toLowerCase().trim()

  if (normalizedQuery.includes("eminem")) return mockDatasets.eminem
  if (normalizedQuery.includes("anitta")) return mockDatasets.anitta
  if (normalizedQuery.includes("system") || normalizedQuery.includes("soad"))
    return mockDatasets.soad

  // Fallback: Generate a random graph using the query as the central node
  const randomNames = Array.from({ length: 15 }).map(
    (_, i) => `Artist ${i + 1}`
  )
  return generateMockGraph(query, randomNames)
}
