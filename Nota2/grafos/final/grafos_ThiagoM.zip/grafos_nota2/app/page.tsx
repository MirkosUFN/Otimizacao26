"use client"

import { useState } from "react"
import { SearchArtist } from "@/components/graph/SearchArtist"
import { SpotifyNetworkGraph } from "@/components/graph/SpotifyNetworkGraph"
import { GraphAnalysis } from "@/components/graph/GraphAnalysis"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

export default function Page() {
  const [networkData, setNetworkData] = useState<{
    nodes: any[]
    edges: any[]
  } | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [highlightedPath, setHighlightedPath] = useState<string[] | null>(null)

  const handleSearch = async (artist: string) => {
    setLoading(true)
    setError(null)
    setNetworkData(null)
    setHighlightedPath(null)

    try {
      const res = await fetch(
        `/api/mock/network?artist=${encodeURIComponent(artist)}`
      )

      if (!res.ok) {
        let errorMsg = "Failed to fetch network"
        try {
          const errorData = await res.json()
          errorMsg = errorData.error || errorMsg
        } catch {
          errorMsg = `Server error: ${res.status} ${res.statusText}`
        }
        throw new Error(errorMsg)
      }

      const data = await res.json()
      setNetworkData(data)
    } catch (err: any) {
      console.error(err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="mx-auto flex min-h-svh max-w-6xl flex-col gap-6 p-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">
          Spotify Communities
        </h1>
        <p className="text-muted-foreground">
          Descubra comunidades musicais. Procure por um artista central para
          visualizar sua rede de artistas relacionados.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Procurar por Artista</CardTitle>
          <CardDescription>
            Digite o nome de um artista para gerar sua rede de colaboradores.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <SearchArtist onSearch={handleSearch} loading={loading} />
          {error && (
            <div className="mt-4 rounded-md border border-red-200 bg-red-100 p-3 text-sm text-red-600">
              {error}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex flex-col gap-6 flex-1">
        {networkData ? (
          <>
            <div className="min-h-[600px] flex-1">
              <SpotifyNetworkGraph
                initialNodes={networkData.nodes}
                initialEdges={networkData.edges}
                highlightedPath={highlightedPath}
              />
            </div>
            <GraphAnalysis
              nodes={networkData.nodes}
              edges={networkData.edges}
              onHighlightPath={setHighlightedPath}
              currentHighlight={highlightedPath}
            />
          </>
        ) : (
          <div className="min-h-[400px] flex h-full w-full items-center justify-center rounded-lg border border-dashed bg-neutral-50/50 text-muted-foreground dark:bg-neutral-900/20">
            {loading ? (
              <div className="flex flex-col items-center gap-4">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-green-500 border-t-transparent"></div>
                <p>
                  Analisando a rede de artistas (isso leva alguns segundos)...
                </p>
              </div>
            ) : (
              <p>Nenhuma rede gerada ainda. Procure por um artista acima.</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
