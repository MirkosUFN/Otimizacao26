import { getAccessToken, searchArtist, getRelatedArtists } from './lib/spotify.ts';

async function test() {
  try {
    const artist = await searchArtist('Eminem');
    console.log('Found artist:', artist.name, artist.id);
    
    const related = await getRelatedArtists(artist.id);
    console.log('Found related artists:', related);
  } catch (err: any) {
    console.error('Test Failed:', err.message);
  }
}

test();
