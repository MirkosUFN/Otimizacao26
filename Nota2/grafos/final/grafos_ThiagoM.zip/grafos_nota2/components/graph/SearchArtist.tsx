"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function SearchArtist({
  onSearch,
  loading,
}: {
  onSearch: (artist: string) => void
  loading: boolean
}) {
  const [query, setQuery] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      onSearch(query.trim())
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="flex w-full max-w-sm items-center space-x-2"
    >
      <Input
        type="text"
        placeholder="Digite o nome do artista (ex: Eminem)..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        disabled={loading}
      />
      <Button type="submit" disabled={loading || !query.trim()}>
        {loading ? (
          "Buscando..."
        ) : (
          <>
            <Search className="mr-2 h-4 w-4" /> Buscar
          </>
        )}
      </Button>
    </form>
  )
}
