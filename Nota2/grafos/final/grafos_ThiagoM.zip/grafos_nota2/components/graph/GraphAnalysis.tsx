"use client"

import { useState, useMemo, useEffect } from "react"
import { calculateGraphStats, getShortestPath } from "@/lib/graph-analysis"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Network,
  ArrowRight,
  Maximize2,
  Activity,
  RefreshCw,
} from "lucide-react"

interface GraphAnalysisProps {
  nodes: any[]
  edges: any[]
  onHighlightPath: (path: string[] | null) => void
  currentHighlight: string[] | null
}

export function GraphAnalysis({
  nodes,
  edges,
  onHighlightPath,
  currentHighlight,
}: GraphAnalysisProps) {
  const [startArtist, setStartArtist] = useState<string>("")
  const [endArtist, setEndArtist] = useState<string>("")

  // Ordena os artistas alfabeticamente para os seletores
  const artistList = useMemo(() => {
    return nodes.map((n) => n.id).sort((a, b) => a.localeCompare(b))
  }, [nodes])

  // Define os artistas iniciais quando os dados mudam
  useEffect(() => {
    if (artistList.length >= 2) {
      setStartArtist(artistList[0])
      setEndArtist(artistList[artistList.length - 1])
    } else {
      setStartArtist("")
      setEndArtist("")
    }
  }, [artistList])

  // Calcula estatísticas
  const stats = useMemo(() => {
    return calculateGraphStats(nodes, edges)
  }, [nodes, edges])

  // Calcula o caminho interativo selecionado
  const interactivePath = useMemo(() => {
    if (!startArtist || !endArtist) return null
    return getShortestPath(startArtist, endArtist, nodes, edges)
  }, [startArtist, endArtist, nodes, edges])

  const handleHighlightInteractive = () => {
    if (interactivePath) {
      onHighlightPath(interactivePath)
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-3">
      {/* CARD 1: Estatísticas de Separação */}
      <Card className="border-neutral-200 md:col-span-1 dark:border-neutral-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg font-bold">
            <Network className="h-5 w-5 text-green-500" />
            Métricas de Separação
          </CardTitle>
          <CardDescription>
            Análise de conectividade e caminhos do grafo.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-6">
          {/* Grau Máximo de Separação (Diâmetro) */}
          <div className="flex items-start gap-4 rounded-lg bg-neutral-100/50 p-4 dark:bg-neutral-900/50">
            <div className="rounded-full bg-green-500/10 p-2.5 text-green-500">
              <Maximize2 className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">
                Grau Máximo de Separação
              </p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-50">
                  {stats.diameter}
                </span>
                <span className="text-sm text-neutral-500 dark:text-neutral-400">
                  saltos (hops)
                </span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                A maior distância (caminho mínimo) entre qualquer par de
                artistas conectados no grafo.
              </p>
            </div>
          </div>

          {/* Grau Médio de Separação */}
          <div className="flex items-start gap-4 rounded-lg bg-neutral-100/50 p-4 dark:bg-neutral-900/50">
            <div className="rounded-full bg-blue-500/10 p-2.5 text-blue-500">
              <Activity className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">
                Grau Médio de Separação
              </p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-50">
                  {stats.averageSeparation}
                </span>
                <span className="text-sm text-neutral-500 dark:text-neutral-400">
                  saltos médios
                </span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                Distância média que separa dois artistas quaisquer escolhidos
                aleatoriamente.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* CARD 2: Caminhos mais Longos (Diâmetro) */}
      <Card className="border-neutral-200 md:col-span-1 dark:border-neutral-800">
        <CardHeader>
          <CardTitle className="text-lg font-bold">
            Caminhos Críticos (Grau Máximo)
          </CardTitle>
          <CardDescription>
            Exemplos de pares de artistas que exigem o maior número de saltos (
            {stats.diameter}) para se conectarem.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          {stats.longestPaths.length === 0 ? (
            <p className="text-sm text-muted-foreground italic">
              Não há caminhos críticos identificados.
            </p>
          ) : (
            stats.longestPaths.map((path, idx) => {
              const start = path[0]
              const end = path[path.length - 1]
              const isCurrent =
                currentHighlight &&
                currentHighlight.length === path.length &&
                currentHighlight[0] === start &&
                currentHighlight[currentHighlight.length - 1] === end

              return (
                <div
                  key={idx}
                  className={`flex flex-col gap-2 rounded-lg border p-3 text-sm transition-all ${
                    isCurrent
                      ? "border-amber-500 bg-amber-500/5 dark:bg-amber-500/10"
                      : "border-neutral-100 bg-neutral-50/50 hover:bg-neutral-50 dark:border-neutral-800 dark:bg-neutral-900/30 dark:hover:bg-neutral-900/50"
                  }`}
                >
                  <div className="flex items-center justify-between font-medium">
                    <span>
                      {start} ➔ {end}
                    </span>
                    <Button
                      size="sm"
                      variant={isCurrent ? "secondary" : "outline"}
                      className="h-7 px-2 text-xs"
                      onClick={() => onHighlightPath(path)}
                    >
                      {isCurrent ? "Destacado" : "Destacar"}
                    </Button>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400">
                    {path.map((nodeId, nodeIdx) => (
                      <span key={nodeIdx} className="flex items-center gap-1">
                        <span
                          className={`rounded px-1.5 py-0.5 ${
                            nodeIdx === 0 || nodeIdx === path.length - 1
                              ? "bg-neutral-200 font-semibold text-neutral-800 dark:bg-neutral-800 dark:text-neutral-200"
                              : "bg-green-500/10 text-green-600 dark:text-green-400"
                          }`}
                        >
                          {nodeId}
                        </span>
                        {nodeIdx < path.length - 1 && (
                          <ArrowRight className="h-3 w-3 text-neutral-400" />
                        )}
                      </span>
                    ))}
                  </div>
                </div>
              )
            })
          )}
        </CardContent>
      </Card>

      {/* CARD 3: Localizador de Menor Caminho Interativo */}
      <Card className="border-neutral-200 md:col-span-1 dark:border-neutral-800">
        <CardHeader>
          <CardTitle className="text-lg font-bold">
            Simulador de Grau de Separação
          </CardTitle>
          <CardDescription>
            Escolha dois artistas para descobrir o caminho mais curto e o número
            de conexões entre eles.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-neutral-500">
                De (Origem)
              </label>
              <select
                value={startArtist}
                onChange={(e) => setStartArtist(e.target.value)}
                className="w-full rounded-md border border-neutral-200 bg-white px-2 py-1.5 text-sm outline-none dark:border-neutral-800 dark:bg-neutral-900"
              >
                {artistList.map((artist) => (
                  <option key={artist} value={artist}>
                    {artist}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-neutral-500">
                Para (Destino)
              </label>
              <select
                value={endArtist}
                onChange={(e) => setEndArtist(e.target.value)}
                className="w-full rounded-md border border-neutral-200 bg-white px-2 py-1.5 text-sm outline-none dark:border-neutral-800 dark:bg-neutral-900"
              >
                {artistList.map((artist) => (
                  <option key={artist} value={artist}>
                    {artist}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {interactivePath ? (
            <div className="rounded-lg border border-neutral-200 bg-neutral-50 p-3 dark:border-neutral-800 dark:bg-neutral-900/30">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs font-semibold tracking-wider text-neutral-500 uppercase">
                  Menor Caminho Encontrado
                </span>
                <span className="rounded-full bg-amber-500/10 px-2 py-0.5 text-xs font-semibold text-amber-600 dark:text-amber-400">
                  Separados por {interactivePath.length - 1} salto(s)
                </span>
              </div>
              <div className="mb-3 flex flex-wrap items-center gap-1 text-xs">
                {interactivePath.map((nodeId, nodeIdx) => (
                  <span key={nodeIdx} className="flex items-center gap-1">
                    <span
                      className={`rounded px-1.5 py-0.5 ${
                        nodeIdx === 0 || nodeIdx === interactivePath.length - 1
                          ? "bg-neutral-200 font-semibold text-neutral-800 dark:bg-neutral-800 dark:text-neutral-200"
                          : "bg-amber-500/15 text-amber-700 dark:text-amber-400"
                      }`}
                    >
                      {nodeId}
                    </span>
                    {nodeIdx < interactivePath.length - 1 && (
                      <ArrowRight className="h-3 w-3 text-neutral-400" />
                    )}
                  </span>
                ))}
              </div>

              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="flex-1 border-none bg-amber-500 text-xs text-white hover:bg-amber-600 dark:bg-amber-600 dark:hover:bg-amber-700"
                  onClick={handleHighlightInteractive}
                >
                  Destacar no Gráfico
                </Button>
                {currentHighlight && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="px-2"
                    title="Limpar Destaques"
                    onClick={() => onHighlightPath(null)}
                  >
                    <RefreshCw className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <div className="rounded-lg border border-dashed border-neutral-200 p-4 text-center text-xs text-muted-foreground dark:border-neutral-800">
              Nenhum caminho possível entre esses dois artistas.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
