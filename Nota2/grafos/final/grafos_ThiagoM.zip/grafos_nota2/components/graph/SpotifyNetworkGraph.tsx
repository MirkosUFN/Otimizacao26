"use client"

import { useEffect, useMemo, useState } from "react"
import {
  ReactFlow,
  useNodesState,
  useEdgesState,
  Background,
  Controls,
  Handle,
  Position,
  NodeProps,
  Node,
  Edge,
} from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import * as d3 from "d3-force"

// Custom Node to display Artist Image and Name
function ArtistNode({ data }: NodeProps) {
  const isCentral = data.isCentral as boolean
  const isHighlighted = data.isHighlighted as boolean
  const isDimmed = data.isDimmed as boolean

  let borderStyle = isCentral
    ? "border-green-500 shadow-green-500/50"
    : "border-neutral-200 dark:border-neutral-800"

  if (isHighlighted) {
    borderStyle =
      "border-amber-500 shadow-amber-500/70 ring-2 ring-amber-500/50 bg-amber-500/10"
  }

  return (
    <div
      className={`flex flex-col items-center justify-center rounded-xl border bg-white/5 p-2 shadow-lg backdrop-blur-md transition-all duration-300 ${borderStyle} ${isDimmed ? "scale-95 opacity-30" : "scale-100 opacity-100"}`}
    >
      <Handle type="target" position={Position.Top} className="invisible" />
      {data.image ? (
        <img
          src={data.image as string}
          alt={data.label as string}
          className={`rounded-full object-cover transition-all duration-300 ${isCentral ? "h-20 w-20" : "h-12 w-12"} ${isHighlighted ? "ring-2 ring-amber-400" : ""}`}
        />
      ) : (
        <div
          className={`flex items-center justify-center rounded-full bg-neutral-200 transition-all duration-300 dark:bg-neutral-800 ${isCentral ? "h-20 w-20" : "h-12 w-12"} ${isHighlighted ? "ring-2 ring-amber-400" : ""}`}
        >
          <span className="text-[10px] text-neutral-500">No Img</span>
        </div>
      )}
      <div
        className={`mt-2 max-w-[120px] truncate text-center font-semibold transition-colors duration-300 ${isCentral ? "text-sm" : "text-xs"} ${isHighlighted ? "font-bold text-amber-500 dark:text-amber-400" : ""}`}
        title={data.label as string}
      >
        {data.label as string}
      </div>
      <Handle type="source" position={Position.Bottom} className="invisible" />
    </div>
  )
}

const nodeTypes = {
  artist: ArtistNode,
}

type SimulationNode = d3.SimulationNodeDatum & Node
type SimulationLink = d3.SimulationLinkDatum<SimulationNode> & Edge

export function SpotifyNetworkGraph({
  initialNodes,
  initialEdges,
  highlightedPath = null,
}: {
  initialNodes: any[]
  initialEdges: any[]
  highlightedPath?: string[] | null
}) {
  const [nodes, setNodes, onNodesChange] = useNodesState<Node>([])
  const [edges, setEdges, onEdgesChange] = useEdgesState<Edge>([])

  useEffect(() => {
    if (initialNodes.length === 0) return

    const hasHighlight = highlightedPath && highlightedPath.length > 0
    const pathSet = new Set(highlightedPath || [])
    const pathEdgesSet = new Set<string>()
    if (highlightedPath && highlightedPath.length > 1) {
      for (let i = 0; i < highlightedPath.length - 1; i++) {
        const u = highlightedPath[i]
        const v = highlightedPath[i + 1]
        pathEdgesSet.add(`${u}-${v}`)
        pathEdgesSet.add(`${v}-${u}`)
      }
    }

    // Build adjacency list for positioning
    const adj: Record<string, string[]> = {}
    initialNodes.forEach((n) => {
      adj[n.id] = []
    })
    initialEdges.forEach((e) => {
      if (adj[e.source] && adj[e.target]) {
        adj[e.source].push(e.target)
        adj[e.target].push(e.source)
      }
    })

    // Find central node
    const centralNode = initialNodes.find((n) => n.data.isCentral)
    const centralId = centralNode ? centralNode.id : initialNodes[0]?.id || ""

    // BFS to find levels
    const levels: Record<string, number> = {}
    initialNodes.forEach((n) => {
      levels[n.id] = -1
    })

    if (centralId) {
      const queue: string[] = [centralId]
      levels[centralId] = 0
      while (queue.length > 0) {
        const curr = queue.shift()!
        const currLevel = levels[curr]
        const neighbors = adj[curr] || []
        for (const neighbor of neighbors) {
          if (levels[neighbor] === -1) {
            levels[neighbor] = currLevel + 1
            queue.push(neighbor)
          }
        }
      }
    }

    // Group nodes by level
    const nodesByLevel: Record<number, any[]> = {}
    initialNodes.forEach((node) => {
      const lvl = levels[node.id] !== -1 ? levels[node.id] : 4 // Default level if unreachable
      if (!nodesByLevel[lvl]) {
        nodesByLevel[lvl] = []
      }
      nodesByLevel[lvl].push(node)
    })

    const centerX = 400
    const centerY = 300
    const levelRadiusStep = 135

    const positionedNodes = initialNodes.map((node) => {
      const lvl = levels[node.id] !== -1 ? levels[node.id] : 4

      let x = centerX
      let y = centerY

      if (lvl > 0) {
        const levelNodes = nodesByLevel[lvl] || []
        const nodeIdx = levelNodes.findIndex((n) => n.id === node.id)
        const radius = lvl * levelRadiusStep
        const count = levelNodes.length

        // Distribute evenly around the circle, adding an offset angle per level
        const offsetAngle = lvl * 0.4
        const angle = ((2 * Math.PI) / count) * nodeIdx + offsetAngle

        x = centerX + radius * Math.cos(angle)
        y = centerY + radius * Math.sin(angle)
      }

      const isHighlighted = hasHighlight && pathSet.has(node.id)
      const isDimmed = hasHighlight && !pathSet.has(node.id)

      return {
        ...node,
        type: "artist",
        position: { x, y },
        data: {
          ...node.data,
          isHighlighted,
          isDimmed,
        },
      }
    })

    setNodes(positionedNodes)

    const styledEdges = initialEdges.map((e) => {
      const isHighlighted =
        hasHighlight && pathEdgesSet.has(`${e.source}-${e.target}`)
      const isDimmed = hasHighlight && !isHighlighted

      return {
        ...e,
        animated: isHighlighted || !hasHighlight,
        style: isHighlighted
          ? { stroke: "#f59e0b", strokeWidth: 3.5, opacity: 1 }
          : isDimmed
            ? { stroke: "#e5e7eb", strokeWidth: 1, opacity: 0.15 }
            : { stroke: "#22c55e", strokeWidth: 1.5, opacity: 0.6 },
      }
    })
    setEdges(styledEdges)
  }, [initialNodes, initialEdges, highlightedPath, setNodes, setEdges])

  return (
    <div className="relative h-[600px] w-full overflow-hidden rounded-lg border bg-neutral-50 dark:bg-neutral-900/50">
      <div className="absolute top-2 left-2 z-10 rounded bg-white p-1 font-mono text-xs text-black shadow dark:bg-neutral-800 dark:text-neutral-200">
        Debug: {nodes.length} nodes, {edges.length} edges
      </div>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        nodeTypes={nodeTypes}
        fitView
        minZoom={0.2}
        maxZoom={4}
        attributionPosition="bottom-right"
        style={{ width: "100%", height: "100%" }}
      >
        <Background color="#ccc" gap={16} />
        <Controls />
      </ReactFlow>
    </div>
  )
}
