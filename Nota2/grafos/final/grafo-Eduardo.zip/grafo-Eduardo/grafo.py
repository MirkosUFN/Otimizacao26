import pandas as pd
import networkx as nx
from pyvis.network import Network

def main():
    dados_voos = {
        'origem': [
            'São Paulo (GRU)', 'São Paulo (GRU)', 'São Paulo (GRU)', 'São Paulo (GRU)',
            'Brasília (BSB)', 'Brasília (BSB)', 'Salvador (SSA)', 'Recife (REC)',
            'Belo Horizonte (CNF)', 'Curitiba (CWB)', 'Porto Alegre (POA)',
            'Belém (BEL)', 'Rio de Janeiro (GIG)', 'Manaus (MAO)'
        ],
        'destino': [
            'Rio de Janeiro (GIG)', 'Brasília (BSB)', 'Belo Horizonte (CNF)', 'Curitiba (CWB)',
            'Salvador (SSA)', 'Belém (BEL)', 'Recife (REC)', 'Fortaleza (FOR)',
            'Vitória (VIX)', 'Porto Alegre (POA)', 'Buenos Aires (EZE)',
            'Manaus (MAO)', 'Vitória (VIX)', 'Boa Vista (BVB)'
        ]
    }
    
    df_voos = pd.DataFrame(dados_voos)
    df_voos.to_csv('dados.csv', index=False)
    print("Arquivo 'dados.csv' gerado com dados de rotas aéreas!\n")

    df = pd.read_csv('dados.csv')
    
    G = nx.from_pandas_edgelist(df, source='origem', target='destino')
    
    print(f"Grafo montado com {G.number_of_nodes()} aeroportos e {G.number_of_edges()} rotas.\n")

    if nx.is_connected(G):
        diametro = nx.diameter(G)
        print(f"=> RESULTADO: O grau máximo de separação é {diametro}.")
        print(f"Isso significa que, na pior das hipóteses, um passageiro precisará pegar {diametro} voos (fazer {diametro-1} conexões) para cruzar a rede de ponta a ponta.\n")
    else:
        print("Atenção: Existem aeroportos isolados que não se conectam com o resto da malha.")
        componentes = [G.subgraph(c).copy() for c in nx.connected_components(G)]
        for i, comp in enumerate(componentes, 1):
            print(f"   - Sub-malha {i} ({comp.number_of_nodes()} aeroportos) -> Separação máxima: {nx.diameter(comp)}")

    print("Aeroportos e quantidade de rotas diretas (Grau do nodo):")
    hubs = sorted(G.degree(), key=lambda x: x[1], reverse=True)
    for nodo, grau in hubs:
        print(f" - {nodo}: {grau} rota(s)")

    print("\nGerando visualização HTML...")
    
    net = Network(height="800px", width="100%", bgcolor="#1a1a1a", font_color="white", select_menu=True)
    
    for node in G.nodes():
        grau = G.degree(node)
        net.add_node(node, label=node, title=f"{node} (Rotas: {grau})", size=15 + (grau * 5))
        
    for edge in G.edges():
        net.add_edge(edge[0], edge[1])
    
    net.toggle_physics(True)
    
    arquivo_html = "malha_aerea.html"
    net.write_html(arquivo_html)
    
    print(f"Visualização gerada com sucesso! Abra '{arquivo_html}' no seu navegador para interagir com o mapa de voos.")

if __name__ == "__main__":
    main()