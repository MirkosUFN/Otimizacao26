# 📊 Análise de Teoria dos Grafos — Telecell Mobile (Drift DB)

> **Engenharia de Dados & Ciência da Computação aplicadas ao projeto Flutter/Drift**

---

## 1. Definição Formal do Grafo $G = (V, E)$

A partir do esquema do banco de dados Drift em [`app_database.dart`](file:///c:/Users/laboratorio/Project/lib/database/app_database.dart), extraímos o grafo relacional:

| Elemento Matemático | Mapeamento no Código Drift |
|---|---|
| **Grafo** $G = (V, E)$ | O banco de dados `gestor_os.db` completo |
| **Conjunto de Vértices** $V$ | $V = V_C \cup V_{OS}$ (Clientes ∪ OrdensServico) |
| **Conjunto de Arestas** $E$ | `OrdensServico.clienteId` → `Clientes.id` (FK) |
| **Tipo de Grafo** | **Não-dirigido, não-ponderado, desconexo** |

### Definição dos Vértices

```dart
// Vértice tipo C (Cliente) — definido em Clientes (linha 12)
class Clientes extends Table {
  IntColumn get id => integer().autoIncrement()(); // ← ID do vértice
  TextColumn get nome => text()();
  TextColumn get telefone => text()();
  TextColumn get cpf => text()();
}

// Vértice tipo OS — definido em OrdensServico (linha 23)
class OrdensServico extends Table {
  IntColumn get id => integer().autoIncrement()(); // ← ID do vértice
  IntColumn get clienteId => integer().references(Clientes, #id)(); // ← ARESTA!
  // ... demais atributos
}
```

**Conclusão:** Cada registro nas duas tabelas é um **vértice** do grafo.

---

## 2. Mapeamento das Arestas

A **única aresta** do grafo é a **Chave Estrangeira**:

```
OrdensServico.clienteId  ──────►  Clientes.id
```

Formalmente:
$$E = \{ (v_{OS}, v_C) \mid v_{OS}.clienteId = v_C.id \}$$

Isso é comprovado pela query JOIN usada em [`listarOrdensComCliente()`](file:///c:/Users/laboratorio/Project/lib/database/app_database.dart#L104-L117):

```dart
final query = select(ordensServico).join([
  innerJoin(clientes, clientes.id.equalsExp(ordensServico.clienteId)), // ← ARESTA
]);
```

> [!IMPORTANT]
> **Toda aresta** do grafo passa **obrigatoriamente** por um nó do tipo Cliente. Isso define a topologia estrutural do grafo.

---

## 3. Topologia: Floresta de Estrelas

A estrutura que emerge do relacionamento **1:N** (um Cliente → N OrdensServico) é matematicamente chamada de **Floresta de Estrelas** (Forest of Stars):

```
         [Cliente A]                [Cliente B]
        /     |      \                 |    \
      [OS1] [OS2]  [OS3]           [OS4]  [OS5]
      
   ←── Componente Conexa 1 ──→   ←─ Comp. Conexa 2 ─→
```

- Cada **Cliente é o hub** (centro) de uma estrela.
- Cada **OS é uma folha** (leaf node) — grau = 1.
- Cada **estrela é uma componente conexa** isolada.

---

## 4. Graus de Separação (Distância do Caminho Mais Curto)

### 🟢 Distância = 1 (1 Grau de Separação)

**Quem?** Um Cliente e qualquer uma de suas Ordens de Serviço.

$$d(v_C,\, v_{OS}) = 1 \quad \text{se e somente se}\quad v_{OS}.clienteId = v_C.id$$

**Caminho:**
```
[Cliente A] ─── 1 aresta ───► [OS #1]
```

**No código:** É o resultado de `listarOrdensPorCliente(clienteId)`:
```dart
// linha 148 — distância = 1 direto no banco
Future<List<OrdemDeServico>> listarOrdensPorCliente(int clienteId) =>
    (select(ordensServico)
          ..where((t) => t.clienteId.equals(clienteId)))
        .get();
```

---

### 🟡 Distância = 2 (2 Graus de Separação)

**Quem?** Duas Ordens de Serviço **do mesmo cliente**.

$$d(v_{OS_A},\, v_{OS_B}) = 2 \quad \text{se}\quad v_{OS_A}.clienteId = v_{OS_B}.clienteId$$

**Caminho:**
```
[OS A] ─── aresta 1 ───► [Cliente Hub] ─── aresta 2 ───► [OS B]
```

**No código:** É o que a query JOIN calcula implicitamente:
```dart
// linha 105 — o JOIN atravessa as 2 arestas
final query = select(ordensServico).join([
  innerJoin(clientes, clientes.id.equalsExp(ordensServico.clienteId)),
]);
```
Para encontrar "irmãs" de uma OS, seria necessário um self-join via o hub Cliente.

---

### 🔴 Distância = ∞ (Grafo Desconexo)

**Quem?** Dois Clientes diferentes, **ou** duas OSs de clientes diferentes.

$$d(v_{C_A},\, v_{C_B}) = \infty \quad \forall\; C_A \neq C_B$$

$$d(v_{OS_A},\, v_{OS_B}) = \infty \quad \text{se}\quad v_{OS_A}.clienteId \neq v_{OS_B}.clienteId$$

**Por quê?** Não existe nenhuma aresta entre Clientes. O grafo é **desconexo** — formado por **ilhas (componentes conexas)** isoladas, uma por cliente.

> [!NOTE]
> A ausência de arestas entre clientes é uma **decisão de modelagem intencional**: no domínio da assistência técnica, não há relacionamento estrutural entre clientes distintos.

---

## 5. Propriedades Matemáticas Formais

| Propriedade | Valor / Descrição |
|---|---|
| **Tipo** | Grafo não-dirigido, não-ponderado |
| **Topologia** | Floresta de Estrelas (*Forest of Stars*) |
| **Conectividade** | Desconexo (múltiplas componentes) |
| **Número de componentes** | $= \|V_C\|$ (1 por cliente) |
| **Grau do nó Cliente** | $= $ número de OSs desse cliente |
| **Grau do nó OS** | $= 1$ (sempre — leaf node) |
| **Diâmetro de cada componente** | $= 2$ (máximo entre duas OSs do mesmo cliente) |
| **Diâmetro do grafo total** | $= \infty$ (grafo desconexo) |
| **Algoritmo de menor caminho** | BFS (Busca em Largura) — grafo não-ponderado |

---

## 6. Tabela Resumo dos Graus de Separação

| Par de Nós | Distância | Caminho | Operação SQL equivalente |
|---|---|---|---|
| Cliente → sua própria OS | **1** | `Cliente ─ OS` | `WHERE clienteId = ?` |
| OS A → OS B (mesmo dono) | **2** | `OS A ─ Cliente ─ OS B` | `JOIN` com self-join via clienteId |
| Cliente A → Cliente B | **∞** | *(sem caminho)* | *(consulta retorna vazio)* |
| OS de C_A → OS de C_B | **∞** | *(sem caminho)* | *(componentes distintas)* |

---

## 7. Impacto Arquitetural: A Tela de Inteligência de Estoque

A função [`obterVolumePorModelo()`](file:///c:/Users/laboratorio/Project/lib/database/app_database.dart#L159-L173) em `InteligenciaEstoquePage` opera sobre os **vértices OS**, agregando por atributo (`marcaModelo`), **sem traversar arestas**. Isso é uma análise de **atributo de vértice**, não de grafo — um ponto interessante a destacar na apresentação.

```dart
// Agrupamento por atributo de vértice (NÃO traversal de grafo)
final query = selectOnly(ordensServico)
  ..addColumns([ordensServico.marcaModelo, countExpr])
  ..groupBy([ordensServico.marcaModelo]);
```

---

## 8. Diagrama Visual do Grafo $G$

```
COMPONENTE 1              COMPONENTE 2              COMPONENTE k
(Cliente: João)           (Cliente: Maria)           (Cliente: ...)

    [C₁]                      [C₂]                      [Cₖ]
   / | \                       |  \                      /   \
[OS₁][OS₂][OS₃]           [OS₄][OS₅]              [OSₙ₋₁][OSₙ]

d(OS₁,OS₂) = 2         d(OS₄,OS₅) = 2         d(OS₁,OS₄) = ∞
d(C₁, OS₁) = 1         d(C₂, OS₄) = 1         d(C₁, C₂)  = ∞
```

---

## 9. Conclusão para a Apresentação Acadêmica

O banco de dados Drift do Telecell Mobile implementa naturalmente uma **Floresta de Estrelas** — uma das topologias mais elegantes da Teoria dos Grafos — onde:

1. **A FK `clienteId`** é a única aresta do grafo, tornando o modelo minimal e matematicamente puro.
2. **O grau de separação** demonstra concretamente como a distância BFS emerge de uma relação 1:N.
3. **As componentes conexas isoladas** provam que o grafo é desconexo por design — cada cliente é uma "ilha" autônoma no espaço de dados.
4. **O diâmetro máximo de 2** dentro de cada componente é a manifestação matemática do JOIN do Drift.
