export const mockDatasets: Record<string, { nodes: any[]; edges: any[] }> = {
  eminem: generateMockGraph("Eminem", [
    "Dr. Dre",
    "50 Cent",
    "Snoop Dogg",
    "Ice Cube",
    "Kendrick Lamar",
    "Jay-Z",
    "Nas",
    "Tupac",
    "The Notorious B.I.G.",
    "J. Cole",
    "Drake",
    "Lil Wayne",
    "Kanye West",
    "Rihanna",
    "Nicki Minaj",
  ]),
  anitta: generateMockGraph("Anitta", [
    "Ludmilla",
    "Pabllo Vittar",
    "Luísa Sonza",
    "Lexa",
    "Gloria Groove",
    "Pedro Sampaio",
    "Kevinho",
    "MC Rebecca",
    "J Balvin",
    "Maluma",
    "Becky G",
    "Natti Natasha",
    "Karol G",
    "Rosalía",
    "MC Kevin o Chris",
  ]),
  soad: generateMockGraph("System of a Down", [
    "Korn",
    "Slipknot",
    "Deftones",
    "Disturbed",
    "Avenged Sevenfold",
    "Linkin Park",
    "Limp Bizkit",
    "Papa Roach",
    "Godsmack",
    "Mudvayne",
    "Rammstein",
    "Tool",
    "Nine Inch Nails",
    "Marilyn Manson",
    "Rob Zombie",
  ]),
}

function generateMockGraph(centralName: string, relatedNames: string[]) {
  const nodesMap = new Map<string, any>()
  const edges: any[] = []

  // Add central node
  nodesMap.set(centralName, {
    id: centralName,
    data: { label: centralName, isCentral: true, image: null },
  })

  // Add Level 1 nodes and connect to central
  relatedNames.forEach((name) => {
    nodesMap.set(name, {
      id: name,
      data: { label: name, isCentral: false, image: null },
    })
    edges.push({
      id: `${centralName}-${name}`,
      source: centralName,
      target: name,
    })
  })

  // Create connections between Level 1 nodes (Level 2 BFS logic restricted to existing nodes)
  // We'll randomly connect about 30% of the possible pairs to simulate communities
  for (let i = 0; i < relatedNames.length; i++) {
    for (let j = i + 1; j < relatedNames.length; j++) {
      // Deterministic pseudo-random based on names
      const hash =
        (relatedNames[i].charCodeAt(0) + relatedNames[j].charCodeAt(0)) % 10
      if (hash < 3) {
        // 30% chance
        edges.push({
          id: `${relatedNames[i]}-${relatedNames[j]}`,
          source: relatedNames[i],
          target: relatedNames[j],
        })
      }
    }
  }

  return {
    nodes: Array.from(nodesMap.values()),
    edges,
  }
}

export function getMockNetwork(query: string) {
  const normalizedQuery = query.toLowerCase().trim()

  if (normalizedQuery.includes("eminem")) return mockDatasets.eminem
  if (normalizedQuery.includes("anitta")) return mockDatasets.anitta
  if (normalizedQuery.includes("system") || normalizedQuery.includes("soad"))
    return mockDatasets.soad

  // Fallback: Generate a random graph using the query as the central node
  const randomNames = Array.from({ length: 15 }).map(
    (_, i) => `Artist ${i + 1}`
  )
  return generateMockGraph(query, randomNames)
}
