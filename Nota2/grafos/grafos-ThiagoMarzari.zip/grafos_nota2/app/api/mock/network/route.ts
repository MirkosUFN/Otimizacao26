import { NextResponse } from 'next/server';
import { getMockNetwork } from '@/lib/mock';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const artist = searchParams.get('artist');

  if (!artist) {
    return NextResponse.json({ error: 'Artist parameter is required' }, { status: 400 });
  }

  // Simulate a bit of network delay for effect
  await new Promise((resolve) => setTimeout(resolve, 800));

  try {
    const network = getMockNetwork(artist);
    return NextResponse.json(network);
  } catch (error: any) {
    console.error('Error building network:', error);
    return NextResponse.json({ error: error.message || 'Failed to build network' }, { status: 500 });
  }
}
