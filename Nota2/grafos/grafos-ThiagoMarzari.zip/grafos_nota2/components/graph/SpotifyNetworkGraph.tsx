"use client"

import { useEffect, useMemo, useState } from "react"
import {
  ReactFlow,
  useNodesState,
  useEdgesState,
  Background,
  Controls,
  Handle,
  Position,
  NodeProps,
  Node,
  Edge,
} from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import * as d3 from "d3-force"

// Custom Node to display Artist Image and Name
function ArtistNode({ data }: NodeProps) {
  const isCentral = data.isCentral as boolean
  return (
    <div
      className={`flex flex-col items-center justify-center rounded-xl border bg-white/5 p-2 shadow-lg backdrop-blur-md ${isCentral ? "border-green-500 shadow-green-500/50" : "border-neutral-200 dark:border-neutral-800"}`}
    >
      <Handle type="target" position={Position.Top} className="invisible" />
      {data.image ? (
        <img
          src={data.image as string}
          alt={data.label as string}
          className={`rounded-full object-cover ${isCentral ? "h-20 w-20" : "h-12 w-12"}`}
        />
      ) : (
        <div
          className={`flex items-center justify-center rounded-full bg-neutral-200 dark:bg-neutral-800 ${isCentral ? "h-20 w-20" : "h-12 w-12"}`}
        >
          <span className="text-[10px] text-neutral-500">No Img</span>
        </div>
      )}
      <div
        className={`mt-2 max-w-[120px] truncate text-center font-semibold ${isCentral ? "text-sm" : "text-xs"}`}
        title={data.label as string}
      >
        {data.label as string}
      </div>
      <Handle type="source" position={Position.Bottom} className="invisible" />
    </div>
  )
}

const nodeTypes = {
  artist: ArtistNode,
}

type SimulationNode = d3.SimulationNodeDatum & Node
type SimulationLink = d3.SimulationLinkDatum<SimulationNode> & Edge

export function SpotifyNetworkGraph({
  initialNodes,
  initialEdges,
}: {
  initialNodes: any[]
  initialEdges: any[]
}) {
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])

  useEffect(() => {
    if (initialNodes.length === 0) return

    // Arrange nodes in a simple circle to bypass d3
    const radius = 250
    const centerX = 400
    const centerY = 300
    const angleStep = (2 * Math.PI) / (initialNodes.length - 1)

    const positionedNodes = initialNodes.map((node, index) => {
      let x, y
      if (node.data.isCentral) {
        x = centerX
        y = centerY
      } else {
        // Find which index it is among non-central
        const nonCentralIndex = initialNodes
          .filter((n) => !n.data.isCentral)
          .findIndex((n) => n.id === node.id)
        const angle = nonCentralIndex * angleStep
        x = centerX + radius * Math.cos(angle)
        y = centerY + radius * Math.sin(angle)
      }

      return {
        ...node,
        type: "artist",
        position: { x, y },
      }
    })

    setNodes(positionedNodes)

    const styledEdges = initialEdges.map((e) => ({
      ...e,
      animated: true,
      style: { stroke: "#22c55e", strokeWidth: 1.5, opacity: 0.6 },
    }))
    setEdges(styledEdges)
  }, [initialNodes, initialEdges, setNodes, setEdges])

  return (
    <div className="w-full h-[600px] border rounded-lg bg-neutral-50 dark:bg-neutral-900/50 overflow-hidden relative">
      <div className="absolute top-2 left-2 z-10 text-xs font-mono bg-white p-1 rounded shadow text-black">
        Debug: {nodes.length} nodes, {edges.length} edges
      </div>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        nodeTypes={nodeTypes}
        fitView
        minZoom={0.2}
        maxZoom={4}
        attributionPosition="bottom-right"
        style={{ width: "100%", height: "100%" }}
      >
        <Background color="#ccc" gap={16} />
        <Controls />
      </ReactFlow>
    </div>
  )
}
