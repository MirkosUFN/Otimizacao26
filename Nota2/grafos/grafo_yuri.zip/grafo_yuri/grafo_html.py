from pyvis.network import Network
import csv

net = Network(
    height="750px",
    width="100%",
    bgcolor="#ffffff",
    font_color="black",
    directed=True
)

with open("dados.csv", encoding="utf-8") as arquivo:
    leitor = csv.DictReader(arquivo)

    for linha in leitor:
        net.add_node(linha["origem"], color="#4CAF50")
        net.add_node(linha["destino"], color="#2196F3")
        net.add_edge(linha["origem"], linha["destino"])

net.show("grafo.html", notebook=False)