# -*- coding: utf-8 -*-
import os
import networkx as nx

def gerar_pdf_direto():
    print("=== GERANDO O RELATÓRIO PDF DIRETO DO GRAFO ===")
    
    # 1. BASE DE DADOS (Coleta de Dados - 4 pts)
    conexoes = [
        ("Porto Alegre", "Caxias do Sul", 120),
        ("Porto Alegre", "Osorio", 100),
        ("Porto Alegre", "Pelotas", 260),
        ("Porto Alegre", "Santa Maria", 290),
        ("Caxias do Sul", "Passo Fundo", 170),
        ("Passo Fundo", "Erechim", 80),
        ("Passo Fundo", "Santa Maria", 290),
        ("Santa Maria", "Uruguaiana", 360),
        ("Santa Maria", "Pelotas", 290),
        ("Pelotas", "Rio Grande", 60),
        ("Osorio", "Torres", 90),
        ("Passo Fundo", "Cruz Alta", 130),
        ("Cruz Alta", "Santa Maria", 130),
        ("Uruguaiana", "Itai", 110),
        ("Itai", "Sao Borja", 80),
        ("Sao Borja", "Sao Luiz Gonzaga", 70),
        ("Sao Luiz Gonzaga", "Santo Angelo", 70),
        ("Santo Angelo", "Cruz Alta", 110)
    ]

    G = nx.Graph()
    for c1, c2, dist in conexoes:
        G.add_edge(c1, c2, weight=dist)

    # 2. RESOLUÇÃO DO MENOR CAMINHO (2 pts)
    origem = "Rio Grande"
    destino = "Caxias do Sul"
    caminho = nx.dijkstra_path(G, source=origem, target=destino, weight='weight')
    distancia = nx.dijkstra_path_length(G, source=origem, target=destino, weight='weight')

    # 3. CONSTRÓI O RELATÓRIO EM HTML PARA TRANSFORMAR EM PDF VIA WEASYPRINT
    html_print_content = f'''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
    @page {{
        size: A4;
        margin: 20mm 15mm;
        @bottom-right {{
            content: "Página " counter(page);
            font-size: 9pt;
            color: #7f8c8d;
        }}
    }}
    body {{
        font-family: Arial, sans-serif;
        color: #2c3e50;
        line-height: 1.5;
        margin: 0;
        padding: 0;
    }}
    .header {{
        background-color: #2c3e50;
        color: white;
        padding: 25px;
        border-radius: 6px;
        margin-bottom: 30px;
    }}
    .header h1 {{ margin: 0; font-size: 22pt; color: #f39c12; }}
    .header p {{ margin: 5px 0 0 0; font-size: 11pt; opacity: 0.9; }}
    
    h2 {{
        color: #2980b9;
        font-size: 14pt;
        border-bottom: 2px solid #3498db;
        padding-bottom: 5px;
        margin-top: 30px;
        page-break-after: avoid;
    }}
    .painel {{
        background-color: #ecf0f1;
        border-left: 6px solid #e67e22;
        padding: 15px;
        margin: 20px 0;
        font-size: 11pt;
    }}
    .caminho-box {{
        font-size: 13pt;
        color: #d35400;
        font-weight: bold;
        margin: 10px 0;
    }}
    table {{
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }}
    th {{
        background-color: #34495e;
        color: white;
        padding: 10px;
        font-size: 10pt;
        text-align: left;
    }}
    td {{
        padding: 10px;
        border-bottom: 1px solid #bdc3c7;
        font-size: 10pt;
    }}
    tr:nth-child(even) {{ background-color: #f9f9f9; }}
    
    .esquema-grafo {{
        background-color: #fdfefe;
        border: 1px dashed #7f8c8d;
        padding: 15px;
        margin-top: 20px;
        border-radius: 4px;
    }}
    .node-lin {{
        margin: 5px 0;
        font-size: 10pt;
    }}
</style>
</head>
<body>

<div class="header">
    <h1>GPS Virtual do Rio Grande do Sul</h1>
    <p>Algoritmo de Dijkstra aplicado à Roteirização de Menor Caminho</p>
</div>

<h2>1. Definição do Problema (2 pts)</h2>
<p>O presente projeto resolve o problema de determinar a rota rodoviária mais curta entre municípios do Estado do Rio Grande do Sul utilizando a Modelagem por Grafos Ponderados. As cidades atuam como vértices e os trechos de estradas como arestas ponderadas pela quilometragem real de distância.</p>

<h2>2. Coleta e Base de Dados do Grafo (4 pts)</h2>
<p>Abaixo estão mapeadas as conexões reais inseridas diretamente na estrutura de dados do programa:</p>

<table>
    <thead>
        <tr>
            <th>Cidade de Origem</th>
            <th>Cidade de Destino</th>
            <th>Distância (Peso)</th>
        </tr>
    </thead>
    <tbody>
'''
    for u, v, data in G.edges(data=True):
        html_print_content += f"        <tr><td>{u}</td><td>{v}</td><td>{data['weight']} km</td></tr>\n"

    html_print_content += f'''    </tbody>
</table>

<h2>3. Menor Caminho Calculado e Visualização do Grafo (4 pts)</h2>
<div class="painel">
    <strong>Ponto de Partida:</strong> {origem}<br>
    <strong>Ponto de Destino:</strong> {destino}<br>
    <div class="caminho-box">Rota Otimizada: {" &rarr; ".join(caminho)}</div>
    <strong>Distância Mínima Total obtida por Dijkstra:</strong> {distancia} km
</div>

<p>Abaixo consta a representação lógica estrutural dos nós e arestas adjacentes processados pela aplicação:</p>
<div class="esquema-grafo">
    <strong>Lista de Vértices Ativos no Sistema:</strong><br>
    <span style="font-size: 9pt; color: #555;">{", ".join(list(G.nodes()))}</span>
</div>

</body>
</html>
'''
    
    # Escreve o HTML temporário
    with open("temp_print.html", "w", encoding="utf-8") as f:
        f.write(html_print_content)
        
    # Converte o HTML diretamente para PDF usando weasyprint em background
    try:
        from weasyprint import HTML
        HTML("temp_print.html").write_pdf("grafo_rio_grande_do_sul.pdf")
        print("-> SUCESSO ABSOLUTO: O arquivo 'grafo_rio_grande_do_sul.pdf' foi criado fisicamente no disco!")
    except Exception as e:
        print(f"Erro ao gerar o PDF diretamente: {e}")

if __name__ == "__main__":
    gerar_pdf_direto()
