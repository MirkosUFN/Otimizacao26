import customtkinter as ctk
from scipy.optimize import linprog

ctk.set_appearance_mode("System")  
ctk.set_default_color_theme("blue") 

class SimplexApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Solucionador de Programação Linear - Simplex UI")
        self.geometry("800px;850px")
        
        self.entries_objetivo = []
        self.entries_restricoes = []
        self.opcoes_sinais = []
        self.entries_b = []
        
        self.main_frame = ctk.CTkScrollableFrame(self, width=750, height=800)
        self.main_frame.pack(padx=15, pady=15, fill="both", expand=True)
        
        self.lbl_titulo = ctk.CTkLabel(self.main_frame, text="Otimização Linear: Método Simplex", font=ctk.CTkFont(size=22, weight="bold"))
        self.lbl_titulo.pack(pady=15)
        
        self.frame_config = ctk.CTkFrame(self.main_frame)
        self.frame_config.pack(padx=10, pady=10, fill="x")
        
        self.lbl_tipo = ctk.CTkLabel(self.frame_config, text="Objetivo:", font=ctk.CTkFont(weight="bold"))
        self.lbl_tipo.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        self.opt_tipo = ctk.CTkOptionMenu(self.frame_config, values=["Maximizar", "Minimizar"])
        self.opt_tipo.grid(row=0, column=1, padx=10, pady=10)
        
        self.lbl_vars = ctk.CTkLabel(self.frame_config, text="Nº de Variáveis (x):", font=ctk.CTkFont(weight="bold"))
        self.lbl_vars.grid(row=1, column=0, padx=10, pady=10, sticky="w")
        self.spn_vars = ctk.CTkComboBox(self.frame_config, values=["2", "3", "4", "5"])
        self.spn_vars.set("3")
        self.spn_vars.grid(row=1, column=1, padx=10, pady=10)
        
        self.lbl_restr = ctk.CTkLabel(self.frame_config, text="Nº de Restrições:", font=ctk.CTkFont(weight="bold"))
        self.lbl_restr.grid(row=2, column=0, padx=10, pady=10, sticky="w")
        self.spn_restr = ctk.CTkComboBox(self.frame_config, values=["2", "3", "4", "5", "6"])
        self.spn_restr.set("2")
        self.spn_restr.grid(row=2, column=1, padx=10, pady=10)
        
        self.btn_gerar = ctk.CTkButton(self.frame_config, text="Gerar Campos do Problema", command=self.gerar_interface_matriz)
        self.btn_gerar.grid(row=3, column=0, columnspan=2, padx=10, pady=15, sticky="ew") # Corrigido o erro do fill aqui
        
        self.frame_dinamico = ctk.CTkFrame(self.main_frame)
        self.frame_resultado = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.txt_resultado = ctk.CTkTextbox(self.frame_resultado, height=180, font=ctk.CTkFont(size=13))

    def gerar_interface_matriz(self):
        for widget in self.frame_dinamico.winfo_children():
            widget.destroy()
        self.frame_resultado.pack_forget()
        
        num_vars = int(self.spn_vars.get())
        num_restr = int(self.spn_restr.get())
        
        self.frame_dinamico.pack(padx=10, pady=10, fill="x")
        
        lbl_fo = ctk.CTkLabel(self.frame_dinamico, text="Coeficientes da Função Objetivo (Z):", font=ctk.CTkFont(size=14, weight="bold"))
        lbl_fo.pack(anchor="w", padx=10, pady=5)
        
        frame_fo_campos = ctk.CTkFrame(self.frame_dinamico)
        frame_fo_campos.pack(padx=10, pady=5, fill="x")
        
        self.entries_objetivo = []
        for j in range(num_vars):
            lbl_x = ctk.CTkLabel(frame_fo_campos, text=f"x{j+1}:")
            lbl_x.grid(row=0, column=j*2, padx=5, pady=5)
            ent = ctk.CTkEntry(frame_fo_campos, width=60)
            ent.insert(0, "0")
            ent.grid(row=0, column=j*2 + 1, padx=5, pady=5)
            self.entries_objetivo.append(ent)
            
        lbl_res_titulo = ctk.CTkLabel(self.frame_dinamico, text="Restrições (Escolha o sinal de igualdade/desigualdade):", font=ctk.CTkFont(size=14, weight="bold"))
        lbl_res_titulo.pack(anchor="w", padx=10, pady=10)
        
        frame_res_campos = ctk.CTkFrame(self.frame_dinamico)
        frame_res_campos.pack(padx=10, pady=5, fill="x")
        
        self.entries_restricoes = []
        self.opcoes_sinais = []
        self.entries_b = []
        
        for i in range(num_restr):
            linha_entries = []
            lbl_num = ctk.CTkLabel(frame_res_campos, text=f"Restr. {i+1}:")
            lbl_num.grid(row=i, column=0, padx=5, pady=5)
            
            col_idx = 1
            for j in range(num_vars):
                ent = ctk.CTkEntry(frame_res_campos, width=50)
                ent.insert(0, "0")
                ent.grid(row=i, column=col_idx, padx=2, pady=5)
                linha_entries.append(ent)
                col_idx += 1
                
                lbl_var_venc = ctk.CTkLabel(frame_res_campos, text=f"x{j+1} + " if j < num_vars-1 else f"x{j+1}")
                lbl_var_venc.grid(row=i, column=col_idx, padx=2, pady=5)
                col_idx += 1
                
            opt_sinal = ctk.CTkOptionMenu(frame_res_campos, values=["<=", ">=", "="], width=60)
            opt_sinal.set("<=")
            opt_sinal.grid(row=i, column=col_idx, padx=5, pady=5)
            self.opcoes_sinais.append(opt_sinal)
            col_idx += 1
            
            ent_b = ctk.CTkEntry(frame_res_campos, width=60)
            ent_b.insert(0, "0")
            ent_b.grid(row=i, column=col_idx, padx=5, pady=5)
            self.entries_b.append(ent_b)
            
            self.entries_restricoes.append(linha_entries)
            
        btn_calcular = ctk.CTkButton(self.frame_dinamico, text="Calcular Solução Simplex", fg_color="#27ae60", hover_color="#219653", command=self.resolver_simplex)
        btn_calcular.pack(padx=10, pady=15, fill="x")

    def resolver_simplex(self):
        try:
            tipo = self.opt_tipo.get()
            
            c = [float(ent.get()) for ent in self.entries_objetivo]
            if tipo == "Maximizar":
                c = [-x for x in c]
                
            A_ub = []
            b_ub = []
            A_eq = []
            b_eq = []
            
            for i, linha in enumerate(self.entries_restricoes):
                coeficientes = [float(ent.get()) for ent in linha]
                b_val = float(self.entries_b[i].get())
                sinal = self.opcoes_sinais[i].get()
                
                if sinal == "<=":
                    A_ub.append(coeficientes)
                    b_ub.append(b_val)
                elif sinal == ">=":
                    A_ub.append([-coef for coef in coeficientes])
                    b_ub.append(-b_val)
                elif sinal == "=":
                    A_eq.append(coeficientes)
                    b_eq.append(b_val)
            
            A_ub = A_ub if len(A_ub) > 0 else None
            b_ub = b_ub if len(b_ub) > 0 else None
            A_eq = A_eq if len(A_eq) > 0 else None
            b_eq = b_eq if len(b_eq) > 0 else None
            
            res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, method='highs')
            
            self.frame_resultado.pack(padx=10, pady=10, fill="x")
            self.txt_resultado.pack(fill="x", padx=5, pady=5)
            self.txt_resultado.delete("1.0", ctk.END)
            
            if res.success:
                valor_z = -res.fun if tipo == "Maximizar" else res.fun
                texto_out = f"STATUS: Otimização concluída com sucesso!\n\n"
                texto_out += f"Valor Ótimo de Z = {valor_z:.4f}\n"
                texto_out += "---------------------------------------\n"
                texto_out += "Valores das Variáveis de Decisão:\n"
                for idx, val in enumerate(res.x):
                    val_corrigido = 0.0 if abs(val) < 1e-10 else val
                    texto_out += f" X{idx+1} = {val_corrigido:.4f}\n"
            else:
                texto_out = f"STATUS: Erro na execução.\nMotivo: {res.message}\n(Possivelmente o problema é impossível ou ilimitado)"
                
            self.txt_resultado.insert(ctk.END, texto_out)
            
        except ValueError:
            self.frame_resultado.pack(padx=10, pady=10, fill="x")
            self.txt_resultado.pack(fill="x", padx=5, pady=5)
            self.txt_resultado.delete("1.0", ctk.END)
            self.txt_resultado.insert(ctk.END, "ERRO: Certifique-se de preencher todos os campos apenas com valores numéricos válidos.")

if __name__ == "__main__":
    app = SimplexApp()
    app.mainloop()