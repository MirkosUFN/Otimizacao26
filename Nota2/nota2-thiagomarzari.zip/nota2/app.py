import numpy as np
from flask import Flask, jsonify, request
from flask_cors import CORS

# Importa a função simplex exata do professor do arquivo original
from simplex import simplex

app = Flask(__name__)
# Habilitar CORS para permitir que o frontend Vue consuma os endpoints
CORS(app)

@app.route('/solve', methods=['POST'])
def solve():
    """
    API REST que consome a função simplex original do professor.
    Faz a ponte de comunicação com o frontend Vue estritamente para Maximização.
    """
    try:
        dados = request.get_json()
        if not dados:
            return jsonify({"sucesso": False, "erro": "Nenhum dado fornecido."}), 400
            
        raw_c = dados.get("c")
        raw_A = dados.get("A")
        raw_b = dados.get("b")
        
        if raw_c is None or raw_A is None or raw_b is None:
            return jsonify({"sucesso": False, "erro": "Dados da função objetivo (c) ou restrições (A, b) incompletos."}), 400
            
        c = np.array([float(x) for x in raw_c])
        A = np.array([[float(val) for val in linha] for linha in raw_A])
        b = np.array([float(x) for x in raw_b])
        
        # Validar dimensões antes de chamar o motor matemático
        if len(A.shape) != 2 or A.shape[0] != len(b) or A.shape[1] != len(c):
            return jsonify({"sucesso": False, "erro": "Dimensões incorretas das restrições ou variáveis."}), 400
            
        # Chama diretamente a função simplex original do seu professor (apenas maximização)
        solucao_array, valor_otimo, iteracao = simplex(c, A, b)
        
        # Formatar a solução em um dicionário estruturado para o frontend: {"x_1": val, "x_2": val}
        solucao_dict = {f"x_{i+1}": float(val) for i, val in enumerate(solucao_array)}
        
        return jsonify({
            "sucesso": True,
            "solucao": solucao_dict,
            "valor_otimo": float(valor_otimo),
            "iteracoes": int(iteracao - 1) # O algoritmo do professor inicia iteracao em 1, então subtraímos 1
        })
        
    except ValueError as math_err:
        # Captura erros matemáticos lançados pelo simplex original (ex: Solução Ilimitada)
        return jsonify({"sucesso": False, "erro": str(math_err)}), 400
    except Exception as e:
        return jsonify({"sucesso": False, "erro": f"Erro interno do servidor: {str(e)}"}), 500

if __name__ == '__main__':
    # Roda a API local na porta 5000
    app.run(host="127.0.0.1", port=5000, debug=True)
