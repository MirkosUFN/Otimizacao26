<script setup lang="ts">
import { ref, reactive, nextTick } from 'vue'
import ConfigStep from '../components/ConfigStep.vue'
import MatrixInputStep from '../components/MatrixInputStep.vue'
import ResultsStep from '../components/ResultsStep.vue'

const step = ref<number>(1)
const numVars = ref<number>(2)
const numConstraints = ref<number>(2)

const objective = reactive<number[]>([])
const A = reactive<number[][]>([])
const b = reactive<number[]>([])

const isLoading = ref<boolean>(false)
const apiError = ref<string | null>(null)
const solution = ref<any>(null)

const animatedZ = ref<number>(0)

function handleSetupSubmit() {
  objective.length = 0
  for (let i = 0; i < numVars.value; i++) {
    objective.push(0)
  }

  A.length = 0
  b.length = 0
  for (let j = 0; j < numConstraints.value; j++) {
    const row: number[] = []
    for (let i = 0; i < numVars.value; i++) {
      row.push(0)
    }
    A.push(row)
    b.push(0)
  }

  step.value = 2
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

function backToConfig() {
  step.value = 1
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

async function handleSolveSubmit() {
  isLoading.value = true
  apiError.value = null
  solution.value = null

  const payload = {
    c: objective,
    A: A,
    b: b,
  }

  try {
    const response = await fetch('http://127.0.0.1:5000/solve', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    })

    const data = await response.json()

    if (!response.ok || !data.sucesso) {
      apiError.value = data.erro || 'Falha ao resolver o problema.'
      step.value = 3
      isLoading.value = false
      nextTick(() => {
        document.getElementById('results-section')?.scrollIntoView({ behavior: 'smooth' })
      })
      return
    }

    solution.value = data
    step.value = 3

    animateValue(data.valor_otimo || 0)

    nextTick(() => {
      document.getElementById('results-section')?.scrollIntoView({ behavior: 'smooth' })
    })
  } catch (err: any) {
    apiError.value = `Erro de conexão com o servidor backend: ${err.message}`
    step.value = 3
  } finally {
    isLoading.value = false
  }
}

function animateValue(targetValue: number) {
  animatedZ.value = 0
  const duration = 800
  const range = targetValue
  const increment = range * 0.05
  const stepTime = Math.abs(Math.floor(duration / (range / (increment || 1))))

  if (!isFinite(stepTime) || stepTime < 10 || isNaN(stepTime)) {
    animatedZ.value = targetValue
    return
  }

  const timer = setInterval(() => {
    animatedZ.value += increment
    if (
      (targetValue > 0 && animatedZ.value >= targetValue) ||
      (targetValue < 0 && animatedZ.value <= targetValue)
    ) {
      animatedZ.value = targetValue
      clearInterval(timer)
    }
  }, stepTime)
}
</script>

<template>
  <div class="app-container">
    <!-- Header -->
    <header class="app-header">
      <div class="logo">
        <i class="fa-solid fa-chart-line logo-icon"></i>
        <h1>Método Simplex</h1>
      </div>
      <p class="subtitle">Thiago Marzari Rossato - Ciência da Computação</p>
    </header>

    <main class="app-main">
      <ConfigStep
        v-if="step === 1"
        v-model:numVars="numVars"
        v-model:numConstraints="numConstraints"
        @submit="handleSetupSubmit"
      />

      <MatrixInputStep
        v-if="step === 2"
        :num-vars="numVars"
        :num-constraints="numConstraints"
        :objective="objective"
        :A="A"
        :b="b"
        :is-loading="isLoading"
        @back="backToConfig"
        @solve="handleSolveSubmit"
      />

      <ResultsStep
        v-if="step === 3"
        :solution="solution"
        :animated-z="animatedZ"
        :api-error="apiError"
        @back="backToConfig"
      />
    </main>

    <footer class="app-footer">
      <p>Otimização Computacional &copy; 2026</p>
    </footer>
  </div>
</template>
