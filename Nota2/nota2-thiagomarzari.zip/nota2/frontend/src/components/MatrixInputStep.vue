<script setup lang="ts">
const props = defineProps<{
  numVars: number
  numConstraints: number
  objective: number[]
  A: number[][]
  b: number[]
  isLoading: boolean
}>()

const emit = defineEmits<{
  (e: 'back'): void
  (e: 'solve'): void
}>()

const subscripts = ['₀', '₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉', '₁₀']
function getSubscript(num: number): string {
  if (num <= 10) return subscripts[num] || ''
  return num
    .toString()
    .split('')
    .map((digit) => subscripts[parseInt(digit)] || '')
    .join('')
}
</script>

<template>
  <section class="card input-card" id="matrix-section">
    <div class="card-header">
      <div class="card-icon"><i class="fa-solid fa-pen-to-square"></i></div>
      <h2>2. Coeficientes do Modelo</h2>
    </div>
    <div class="card-body">
      <form @submit.prevent="emit('solve')">
        <!-- Objective Function -->
        <div class="math-section">
          <h3>Função Objetivo (Maximização)</h3>
          <div class="math-expression-container">
            <div class="math-row">
              <span class="math-operator">Z =</span>
              <template v-for="(val, i) in numVars" :key="'obj-' + i">
                <div class="math-input-wrapper">
                  <input type="number" step="any" v-model.number="objective[i]" required />
                </div>
                <span class="math-var">x{{ getSubscript(i + 1) }}</span>
                <span v-if="i < numVars - 1" class="math-operator">+</span>
              </template>
            </div>
          </div>
        </div>

        <!-- Constraints -->
        <div class="math-section">
          <h3>Restrições Sujeitas a:</h3>
          <div class="constraints-container">
            <div v-for="(row, j) in numConstraints" :key="'row-' + j" class="math-row">
              <span class="constraint-label">Restrição {{ j + 1 }}:</span>
              <template v-for="(val, i) in numVars" :key="'const-' + j + '-' + i">
                <div class="math-input-wrapper">
                  <input type="number" step="any" v-model.number="A[j]![i]" required />
                </div>
                <span class="math-var">x{{ getSubscript(i + 1) }}</span>
                <span v-if="i < numVars - 1" class="math-operator">+</span>
              </template>

              <span class="math-relator">&le;</span>

              <div class="math-input-wrapper">
                <input type="number" step="any" v-model.number="b[j]" required />
              </div>
            </div>
          </div>
        </div>

        <!-- Action buttons -->
        <div class="action-buttons">
          <button type="button" class="btn btn-secondary" @click="emit('back')">
            <i class="fa-solid fa-arrow-left"></i> Voltar
          </button>
          <button type="submit" class="btn btn-success" :disabled="isLoading">
            <span v-if="isLoading">Processando... <i class="fa-solid fa-spinner fa-spin"></i></span>
            <span v-else>Calcular Solução <i class="fa-solid fa-calculator"></i></span>
          </button>
        </div>
      </form>
    </div>
  </section>
</template>
