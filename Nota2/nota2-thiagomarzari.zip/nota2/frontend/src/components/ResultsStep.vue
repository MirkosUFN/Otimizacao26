<script setup lang="ts">
const props = defineProps<{
  solution: any
  animatedZ: number
  apiError: string | null
}>()

const emit = defineEmits<{
  (e: 'back'): void
}>()

// --- Subscripts for variable names (x1 -> x₁) ---
const subscripts = ['₀', '₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉', '₁₀']
function getSubscript(num: number): string {
  if (num <= 10) return subscripts[num] || ''
  return num
    .toString()
    .split('')
    .map((digit) => subscripts[parseInt(digit)] || '')
    .join('')
}

function getVarIndex(varName: string | number): number {
  const parts = varName.toString().split('_')
  return parts.length > 1 ? parseInt(parts[1]!) : 0
}

function formatNumber(val: any): string {
  if (val === null || val === undefined) return ''
  const num = parseFloat(val)
  if (isNaN(num)) return val.toString()
  if (Math.abs(num) < 1e-9) return '0'
  if (Number.isInteger(num)) return num.toString()

  const formatted = num.toFixed(4).replace(/\.?0+$/, '')
  return formatted === '-0' ? '0' : formatted
}
</script>

<template>
  <section class="card results-card" id="results-section">
    <div class="card-header">
      <div class="card-icon">
        <i
          v-if="apiError"
          class="fa-solid fa-triangle-exclamation"
          style="color: var(--color-danger)"
        ></i>
        <i v-else class="fa-solid fa-circle-check"></i>
      </div>
      <h2>3. Solução e Análise</h2>
    </div>
    <div class="card-body">
      <!-- Error alert -->
      <div v-if="apiError" class="alert alert-danger">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <span>{{ apiError }}</span>
      </div>

      <!-- Results Container -->
      <div v-if="solution">
        <!-- Success banner -->
        <div v-if="solution.sucesso" class="optimum-banner">
          <div class="opt-badge">Solução Ótima Encontrada</div>
          <div class="opt-val-container">
            <span class="opt-label">Valor Ótimo de Z:</span>
            <span class="opt-value">{{ formatNumber(animatedZ) }}</span>
          </div>
          <p class="iterations-count">
            Resolvido com sucesso em {{ solution.iteracoes }} iterações
          </p>
        </div>

        <!-- Unbounded error banner -->
        <div v-else class="alert alert-danger">
          <i class="fa-solid fa-triangle-exclamation"></i>
          <span>{{ solution.erro }}</span>
        </div>

        <!-- Variable Grid (Only on success) -->
        <template v-if="solution.sucesso">
          <h3 class="section-title">
            <i class="fa-solid fa-cube"></i> Valores das Variáveis de Decisão
          </h3>
          <div class="variables-grid">
            <div v-for="(val, varName) in solution.solucao" :key="varName" class="var-card">
              <div class="var-name">x{{ getSubscript(getVarIndex(varName)) }}</div>
              <div class="var-val">{{ formatNumber(val) }}</div>
            </div>
          </div>
        </template>
      </div>

      <!-- Solve screen back button -->
      <div class="action-buttons" style="margin-top: 2rem">
        <button type="button" class="btn btn-secondary" @click="emit('back')">
          <i class="fa-solid fa-arrow-left"></i> Configurar Novo Problema
        </button>
      </div>
    </div>
  </section>
</template>
