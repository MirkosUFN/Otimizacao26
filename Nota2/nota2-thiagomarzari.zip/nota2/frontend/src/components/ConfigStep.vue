<script setup lang="ts">
const numVars = defineModel<number>('numVars', { required: true })
const numConstraints = defineModel<number>('numConstraints', { required: true })

const emit = defineEmits<{
  (e: 'submit'): void
}>()

function adjustNumber(field: 'vars' | 'constraints', direction: number) {
  if (field === 'vars') {
    const val = numVars.value + direction
    if (val >= 2 && val <= 10) numVars.value = val
  } else {
    const val = numConstraints.value + direction
    if (val >= 1 && val <= 10) numConstraints.value = val
  }
}
</script>

<template>
  <section class="card config-card" id="config-section">
    <div class="card-header">
      <div class="card-icon"><i class="fa-solid fa-sliders"></i></div>
      <h2>1. Configuração do Problema</h2>
    </div>
    <div class="card-body">
      <form @submit.prevent="emit('submit')">
        <div class="form-row">
          <div class="form-group">
            <label>Variáveis de Decisão (x)</label>
            <div class="number-input-wrapper">
              <button type="button" class="btn-step" @click="adjustNumber('vars', -1)">
                <i class="fa-solid fa-minus"></i>
              </button>
              <input type="number" :value="numVars" min="2" max="10" readonly required>
              <button type="button" class="btn-step" @click="adjustNumber('vars', 1)">
                <i class="fa-solid fa-plus"></i>
              </button>
            </div>
            <span class="help-text">Entre 2 e 10 variáveis</span>
          </div>
          
          <div class="form-group">
            <label>Restrições (&le;)</label>
            <div class="number-input-wrapper">
              <button type="button" class="btn-step" @click="adjustNumber('constraints', -1)">
                <i class="fa-solid fa-minus"></i>
              </button>
              <input type="number" :value="numConstraints" min="1" max="10" readonly required>
              <button type="button" class="btn-step" @click="adjustNumber('constraints', 1)">
                <i class="fa-solid fa-plus"></i>
              </button>
            </div>
            <span class="help-text">Entre 1 e 10 restrições</span>
          </div>
        </div>

        <button type="submit" class="btn btn-primary btn-block">
          <span>Gerar Modelo Matemático</span> <i class="fa-solid fa-arrow-right"></i>
        </button>
      </form>
    </div>
  </section>
</template>
