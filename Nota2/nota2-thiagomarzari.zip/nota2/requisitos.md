# Requisitos e Guia de Execução do Projeto

Este projeto consiste em um resolvedor interativo do algoritmo **Simplex** para problemas de Programação Linear (PL), composto por uma API de cálculo em Python e uma interface web feita com vue.`

---

## Requisitos do Projeto

1. **Interface do Usuário:** Construir uma interface gráfica para o usuário inserir coeficientes e restrições de um problema de PL e resolvê-lo interativamente.
2. **Exibição do Resultado:** Retornar o resultado final ótimo (valor de Z e variáveis de decisão) em formato visual.
3. **Não-CLI:** A interface do usuário **não pode** ser executada na linha de comando (CLI).

---

## Tecnologias e Pré-requisitos

### Backend (API):

- **Python 3+**
- **Bibliotecas Python:**
  - `numpy` (cálculos matriciais)
  - `flask` (servidor web e rotas REST)
  - `flask-cors` (liberação de requisições Cross-Origin para o Vue)

### Frontend (Interface Web):

- **Node.js 18+**
- Gerenciador de pacotes **pnpm** (ou npm/yarn)
- **Frameworks:**
  - `Vue 3` (Composition API + Script Setup)
  - `TypeScript` (tipagem estática rigorosa)
  - `Vite` (servidor de build e desenvolvimento ultra veloz)

---

## Como Executar o Projeto

A execução do ecossistema é feita em duas partes (servidor de cálculo e servidor de interface).

### Passo 1: Executar a API Backend (Python)

No diretório raiz do projeto (onde está o arquivo `app.py`), execute:

```bash
# 1. Instalar as dependências necessárias (se não possuir)
python3 -m pip install flask flask-cors numpy

# 2. Iniciar o servidor de desenvolvimento da API
python3 app.py
```

_O backend estará rodando localmente no endereço:_ **`http://127.0.0.1:5000`**

---

### Passo 2: Executar a Interface Web (Vue 3)

Em um novo terminal, entre na pasta do frontend e inicie o Vite:

```bash
# 1. Entrar na pasta do frontend
cd frontend

# 2. Instalar as dependências do Vue (se necessário)
pnpm install

# 3. Iniciar o servidor de desenvolvimento do frontend
pnpm dev
```

_O frontend estará rodando no endereço:_ **`http://localhost:5173`**

---

## Informações de Uso

1. Abra o navegador em `http://localhost:5173`.
2. Configure a quantidade de variáveis e restrições e escolha o tipo de objetivo (**Maximizar** ou **Minimizar**).
3. Preencha as matrizes geradas dinamicamente e clique em **Calcular Solução**.
4. Visualize os valores das variáveis ótimas e o histórico completo de **Tableaus**, contendo indicações exatas dos pivôs selecionados em cada passo interativo!
