import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

print("--- Exercício 3 ---")
print("Objetivo: Maximizar Impacto Z = 4*x1 + 3*x2")
print("Restrições:")
print("  3*x1 + 1*x2 <= 18 (Tempo de GPU)")
print("  1*x1 + 2*x2 <= 16 (Armazenamento)")
print("  x1, x2 >= 0")

c = [-4, -3]
A_ub = [[3, 1], [1, 2]]
b_ub = [18, 16]

res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=[(0, None), (0, None)], method='highs')
print(f"Solução ideal: x1 = {res.x[0]:.2f}, x2 = {res.x[1]:.2f}")
print(f"Impacto máximo: {-res.fun:.2f}")

x = np.linspace(0, 10, 400)
y1 = 18 - 3*x
y2 = (16 - x) / 2

plt.figure()
plt.plot(x, y1, label=r'$3x_1 + x_2 \leq 18$')
plt.plot(x, y2, label=r'$x_1 + 2x_2 \leq 16$')

y_max = np.minimum(y1, y2)
plt.fill_between(x, 0, y_max, where=(y_max >= 0), color='gray', alpha=0.3, label='Região Viável')

plt.plot(res.x[0], res.x[1], 'ro', label='Solução Ótima')
plt.xlim(0, 10)
plt.ylim(0, 20)
plt.xlabel('x1 (Modelos NLP)')
plt.ylabel('x2 (Modelos de Visão)')
plt.legend()
plt.title('Exercício 3: Modelos de Deep Learning')
plt.grid(True)
plt.savefig('exercicio3.png')
print("Gráfico salvo como exercicio3.png\n")
