import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

print("--- Exercício 4 ---")
print("Objetivo: Maximizar Eficiência Z = 5*x1 + 4*x2")
print("Restrições:")
print("  2*x1 + 3*x2 <= 18 (Área de Silício)")
print("  2*x1 + 1*x2 <= 12 (Dissipação Térmica)")
print("  x1, x2 >= 0")

c = [-5, -4]
A_ub = [[2, 3], [2, 1]]
b_ub = [18, 12]

res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=[(0, None), (0, None)], method='highs')
print(f"Solução ideal: x1 = {res.x[0]:.2f}, x2 = {res.x[1]:.2f}")
print(f"Eficiência máxima: {-res.fun:.2f}")

x = np.linspace(0, 10, 400)
y1 = (18 - 2*x) / 3
y2 = 12 - 2*x

plt.figure()
plt.plot(x, y1, label=r'$2x_1 + 3x_2 \leq 18$')
plt.plot(x, y2, label=r'$2x_1 + x_2 \leq 12$')

y_max = np.minimum(y1, y2)
plt.fill_between(x, 0, y_max, where=(y_max >= 0), color='gray', alpha=0.3, label='Região Viável')

plt.plot(res.x[0], res.x[1], 'ro', label='Solução Ótima')
plt.xlim(0, 10)
plt.ylim(0, 15)
plt.xlabel('x1 (Blocos de Cache)')
plt.ylabel('x2 (ALUs)')
plt.legend()
plt.title('Exercício 4: Design de Hardware')
plt.grid(True)
plt.savefig('exercicio4.png')
print("Gráfico salvo como exercicio4.png\n")
