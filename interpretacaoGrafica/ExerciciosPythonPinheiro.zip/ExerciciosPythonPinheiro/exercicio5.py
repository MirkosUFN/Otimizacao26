import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

print("--- Exercício 5 ---")
print("Objetivo: Maximizar Valor Z = 8*x1 + 5*x2")
print("Restrições:")
print("  4*x1 + 4*x2 <= 32 (Desenvolvimento)")
print("  2*x1 + 1*x2 <= 12 (Testes QA)")
print("  x1, x2 >= 0")

c = [-8, -5]
A_ub = [[4, 4], [2, 1]]
b_ub = [32, 12]

res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=[(0, None), (0, None)], method='highs')
print(f"Solução ideal: x1 = {res.x[0]:.2f}, x2 = {res.x[1]:.2f}")
print(f"Valor entregue máximo: {-res.fun:.2f}")

print("\nDiscussão sobre valores inteiros:")
# Tratamento de precisão de float
is_integer_x1 = abs(res.x[0] - round(res.x[0])) < 1e-5
is_integer_x2 = abs(res.x[1] - round(res.x[1])) < 1e-5

if is_integer_x1 and is_integer_x2:
    print("A solução possui valores inteiros. Isso é importante pois não podemos ter frações de tarefas/User Stories entregues na Sprint.")
else:
    print("A solução NÃO possui valores inteiros.")
    print("Na prática de engenharia de software, não podemos entregar 'meia' funcionalidade ou refatoração.")
    print("Portanto, seria necessário procurar a solução inteira viável ótima.")

x = np.linspace(0, 10, 400)
y1 = (32 - 4*x) / 4
y2 = 12 - 2*x

plt.figure()
plt.plot(x, y1, label=r'$4x_1 + 4x_2 \leq 32$')
plt.plot(x, y2, label=r'$2x_1 + x_2 \leq 12$')

y_max = np.minimum(y1, y2)
plt.fill_between(x, 0, y_max, where=(y_max >= 0), color='gray', alpha=0.3, label='Região Viável')

plt.plot(res.x[0], res.x[1], 'ro', label='Solução Ótima')
plt.xlim(0, 10)
plt.ylim(0, 15)
plt.xlabel('x1 (Funcionalidades)')
plt.ylabel('x2 (Refatorações)')
plt.legend()
plt.title('Exercício 5: Planejamento de Sprints')
plt.grid(True)
plt.savefig('exercicio5.png')
print("Gráfico salvo como exercicio5.png\n")
