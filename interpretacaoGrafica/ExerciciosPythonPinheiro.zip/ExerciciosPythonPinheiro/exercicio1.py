import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

print("--- Exercício 1 ---")
print("Objetivo: Minimizar Custo Z = 20*x1 + 50*x2")
print("Restrições:")
print("  4*x1 + 8*x2 >= 40  (vCPUs)")
print("  8*x1 + 32*x2 >= 96 (RAM)")
print("  x1 + x2 <= 12      (Limite de instâncias)")
print("  x1, x2 >= 0")

c = [20, 50]
A_ub = [[-4, -8], [-8, -32], [1, 1]]
b_ub = [-40, -96, 12]
bounds = [(0, None), (0, None)]

res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
print(f"Solução ideal: x1 = {res.x[0]:.2f}, x2 = {res.x[1]:.2f}")
print(f"Custo mínimo: ${res.fun:.2f}")

x = np.linspace(0, 15, 400)
y1 = (40 - 4*x) / 8
y2 = (96 - 8*x) / 32
y3 = 12 - x

plt.figure()
plt.plot(x, y1, label=r'$4x_1 + 8x_2 \geq 40$')
plt.plot(x, y2, label=r'$8x_1 + 32x_2 \geq 96$')
plt.plot(x, y3, label=r'$x_1 + x_2 \leq 12$')

y_min = np.maximum(y1, y2)
y_min = np.maximum(y_min, 0)
plt.fill_between(x, y_min, y3, where=(y3 >= y_min), color='gray', alpha=0.3, label='Região Viável')

plt.plot(res.x[0], res.x[1], 'ro', label='Solução Ótima')
plt.xlim(0, 15)
plt.ylim(0, 15)
plt.xlabel('x1 (Standard)')
plt.ylabel('x2 (High-Performance)')
plt.legend()
plt.title('Exercício 1: Infraestrutura em Nuvem')
plt.grid(True)
plt.savefig('exercicio1.png')
print("Gráfico salvo como exercicio1.png\n")
