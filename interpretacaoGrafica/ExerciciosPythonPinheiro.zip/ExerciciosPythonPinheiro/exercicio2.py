import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

print("--- Exercício 2 ---")
print("Objetivo: Maximizar QoS Z = 3*x1 + 5*x2")
print("Restrições:")
print("  2*x1 + 4*x2 <= 24 (Switch A)")
print("  3*x1 + 2*x2 <= 22 (Switch B)")
print("  x1, x2 >= 0")

c = [-3, -5]
A_ub = [[2, 4], [3, 2]]
b_ub = [24, 22]

res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=[(0, None), (0, None)], method='highs')
print(f"Solução ideal: x1 = {res.x[0]:.2f}, x2 = {res.x[1]:.2f}")
print(f"QoS máximo: {-res.fun:.2f}")

x = np.linspace(0, 15, 400)
y1 = (24 - 2*x) / 4
y2 = (22 - 3*x) / 2

plt.figure()
plt.plot(x, y1, label=r'$2x_1 + 4x_2 \leq 24$')
plt.plot(x, y2, label=r'$3x_1 + 2x_2 \leq 22$')

y_max = np.minimum(y1, y2)
plt.fill_between(x, 0, y_max, where=(y_max >= 0), color='gray', alpha=0.3, label='Região Viável')

plt.plot(res.x[0], res.x[1], 'ro', label='Solução Ótima')
plt.xlim(0, 15)
plt.ylim(0, 10)
plt.xlabel('x1 (Stream Básico)')
plt.ylabel('x2 (Stream Premium)')
plt.legend()
plt.title('Exercício 2: Alocação de Banda')
plt.grid(True)
plt.savefig('exercicio2.png')
print("Gráfico salvo como exercicio2.png\n")
