def print_matrix(matrix, variables, step_description=""):
    """
    Renderiza a matriz no terminal de forma formatada.
    """
    if step_description:
        print(f"\n--- {step_description} ---")
    
    header = " | ".join([f"{var:^6}" for var in variables]) + " || " + f"{'B':^6}"
    print(header)
    print("-" * len(header))
    
    for row in matrix:
        # Arredondamento para evitar -0.0 e lidar com imprecisão de float
        formatted_row = [0.0 if abs(val) < 1e-10 else val for val in row]
        row_str = " | ".join([f"{val:^6.2f}" for val in formatted_row[:-1]])
        row_str += f" || {formatted_row[-1]:^6.2f}"
        print(row_str)
    print()