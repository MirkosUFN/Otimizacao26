# Sistema de Diagonalização de Matrizes (Gauss-Jordan)

Este projeto resolve sistemas de equações lineares (onde o número de equações é igual ao número de variáveis) aplicando o método de eliminação de Gauss-Jordan para diagonalizar a matriz do sistema.

## Estrutura do Projeto

* `diag-Yuri.py`: Ponto de entrada principal da aplicação. Orquestra a leitura, processamento e exibição.
* `core/engine.py`: Motor matemático. Contém o algoritmo de eliminação de Gauss-Jordan.
* `core/parser.py`: Módulo de processamento de texto (Regex) para converter equações em formato string para matrizes numéricas.
* `utils/display.py`: Funções auxiliares para formatação e renderização passo a passo da matriz no terminal.

## Os Pontos "Mais Punks" (Desafios Técnicos Resolvidos)

1.  **Parsing de Equações Dinâmicas (O Regex):** Converter uma string humana como `2x - y + 3z = 5` em uma matriz matemática `[2, -1, 3, 5]` é complexo. O módulo `parser.py` utiliza Expressões Regulares (`re`) para identificar coeficientes implícitos (ex: `-y` se torna `-1`), isolar os termos independentes após o sinal de igual e mapear as variáveis para as colunas corretas dinamicamente, independentemente da ordem em que o usuário digita.

2.  **Pivotamento Parcial (Prevenção de Divisão por Zero):**
    Na diagonalização, o algoritmo tenta transformar a diagonal principal em `1` dividindo a linha pelo valor do pivô. Se o pivô for `0`, o programa crasha. O `engine.py` implementa *Pivotamento Parcial*: ele escaneia as linhas abaixo em busca de um valor não nulo e permuta as linhas da matriz, garantindo a estabilidade numérica do sistema.

3.  **Tratamento de Ponto Flutuante (O problema do `-0.0`):**
    Devido à forma como o Python lida com floats no padrão IEEE 754, operações matemáticas de zeramento podem resultar em valores como `-0.0` ou residuais minúsculos (ex: `1e-16`). O módulo de display aplica uma formatação rigorosa e arredondamentos inteligentes para garantir que a matriz exibida ao usuário seja limpa e exata.