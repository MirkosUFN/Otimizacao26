import sys
from core.parser import parse_system
from core.engine import gauss_jordan_solver

def main():
    print("==================================================")
    print("      SISTEMA DE DIAGONALIZAÇÃO DE MATRIZES       ")
    print("==================================================\n")
    print("Digite as equações do sistema (ex: '2x - y + 3z = 5').")
    print("Atenção: O número de equações deve ser igual ao número de variáveis.")
    print("Digite 'resolver' quando terminar de inserir as equações.\n")

    equations = []
    while True:
        try:
            line = input(f"Equação {len(equations) + 1} (ou 'resolver'): ").strip()
            if line.lower() == 'resolver':
                if len(equations) == 0:
                    print("Nenhuma equação inserida. Encerrando.")
                    return
                break
            if line:
                equations.append(line)
        except KeyboardInterrupt:
            print("\nOperação cancelada.")
            sys.exit(0)

    try:
        # 1. Parser
        matrix, variables = parse_system(equations)
        
        # 2. Solver & Display
        gauss_jordan_solver(matrix, variables)
        
        # 3. Resultado Final
        print("Solução Encontrada:")
        for i, var in enumerate(variables):
            val = matrix[i][-1]
            # Limpeza de formatação para zero absoluto
            val = 0.0 if abs(val) < 1e-10 else val
            print(f"{var} = {val:.4f}")
            
    except Exception as e:
        print(f"\n[ERRO FATAL]: {e}")

if __name__ == "__main__":
    main()