from utils.display import print_matrix

def gauss_jordan_solver(matrix, variables):
    """
    Aplica o método de Gauss-Jordan para diagonalizar a matriz.
    Muta a matriz in-place e imprime o passo a passo.
    """
    n = len(matrix)
    
    print_matrix(matrix, variables, "Matriz Inicial")
    
    for i in range(n):
        # 1. Pivotamento Parcial
        if matrix[i][i] == 0:
            for j in range(i + 1, n):
                if matrix[j][i] != 0:
                    matrix[i], matrix[j] = matrix[j], matrix[i]
                    print_matrix(matrix, variables, f"Permuta de Linhas (L{i+1} <-> L{j+1})")
                    break
            else:
                raise ValueError("Sistema não possui solução única (determinante zero).")
                
        # 2. Normalizar a linha do pivô (Tornar pivô = 1)
        pivot = matrix[i][i]
        if pivot != 1.0:
            for j in range(n + 1):
                matrix[i][j] /= pivot
            print_matrix(matrix, variables, f"Tornar Pivô 1 (L{i+1} / {pivot:.2f})")
            
        # 3. Zerar os elementos acima e abaixo do pivô
        for k in range(n):
            if k != i:
                factor = matrix[k][i]
                if factor != 0:
                    for j in range(n + 1):
                        matrix[k][j] -= factor * matrix[i][j]
                    print_matrix(matrix, variables, f"Zerar elemento (L{k+1} = L{k+1} - ({factor:.2f} * L{i+1}))")

    print_matrix(matrix, variables, "Matriz Final (Diagonalizada)")
    return matrix