import re

def parse_system(equations_list):
    """
    Converte uma lista de equações em string para uma matriz aumentada.
    """
    variables_set = set()
    parsed_equations = []
    
    # Regex para capturar (sinal/coeficiente) e (variável)
    # Exemplo de match: '-2x', '+ y', '3.5z'
    term_pattern = re.compile(r'([+-]?\s*\d*\.?\d*)\s*\*?\s*([a-zA-Z_]\w*)')
    
    for eq in equations_list:
        if '=' not in eq:
            raise ValueError(f"Equação mal formatada (falta o sinal de igual): {eq}")
            
        left_side, right_side = eq.split('=', 1)
        
        # Extrair constante do lado direito
        right_side = right_side.strip()
        try:
            constant = float(right_side)
        except ValueError:
            raise ValueError(f"O lado direito deve ser uma constante numérica: {right_side}")
            
        # Extrair termos do lado esquerdo
        terms = term_pattern.findall(left_side)
        eq_dict = {}
        
        for coef_str, var in terms:
            coef_str = coef_str.replace(" ", "")
            if coef_str == '' or coef_str == '+':
                coef = 1.0
            elif coef_str == '-':
                coef = -1.0
            else:
                coef = float(coef_str)
                
            eq_dict[var] = eq_dict.get(var, 0.0) + coef
            variables_set.add(var)
            
        parsed_equations.append({'terms': eq_dict, 'constant': constant})
        
    variables = sorted(list(variables_set))
    n_vars = len(variables)
    n_eqs = len(equations_list)
    
    if n_vars != n_eqs:
        raise ValueError(f"Regra violada: O número de variáveis ({n_vars}) deve ser igual ao número de equações ({n_eqs}).")
        
    # Construir matriz aumentada
    matrix = []
    for eq in parsed_equations:
        row = [eq['terms'].get(var, 0.0) for var in variables]
        row.append(eq['constant'])
        matrix.append(row)
        
    return matrix, variables